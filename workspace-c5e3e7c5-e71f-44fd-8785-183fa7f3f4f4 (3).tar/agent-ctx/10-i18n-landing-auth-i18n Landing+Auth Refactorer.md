# Task 10-i18n-landing-auth — i18n Landing+Auth Refactorer

## Task
Refactor 4 components (HeroSection, FeaturesSection, LoginView, SignupView) to use the new i18n translation system (`useTranslation` + `t()` calls) instead of hardcoded English strings, while preserving all existing styling, layout, animations, and logic.

## Files Modified
1. `src/components/landing/HeroSection.tsx` — moved `stats` array inside component; swapped all visible strings to `t("hero.*")` keys (badge, badgeNew, titlePre, titleHighlight, subtitle, ctaStart/ctaGetStarted, watchHow, statMatchScore/statRoadmap/statVoice, scrollHint). Gradient text + orbs + staggered motion preserved.
2. `src/components/landing/FeaturesSection.tsx` — moved `features` array inside component; swapped label/titlePre/titleHighlight/subtitle/resumeTitle+Desc/roadmapTitle+Desc/interviewTitle+Desc/learnMore to `t("features.*")`. Glass cards, gradient borders, decorative numbers, hover lift preserved.
3. `src/components/auth/LoginView.tsx` — added `useTranslation`; swapped title, subtitle, email/password labels, remember, forgot, submit/submitting, demo, noAccount, signupLink, and validation errors (emailRequired/passwordRequired) to `t("login.*")`. AuthLayout props now receive translated strings. Demo login, password toggle, framer-motion entrance preserved. Store error messages kept as-is (English, MVP).
4. `src/components/auth/SignupView.tsx` — added `useTranslation`; swapped title, subtitle, name/email/password labels, terms, submit/submitting, demo, haveAccount, loginLink to `t("signup.*")`. Refactored `evalPassword` to return a `kind` discriminator so the strength label is mapped via `t("signup.passwordStrength.{tooShort|weak|medium|strong}")` inside the component. Replaced the inline "Terms & Privacy Policy" link with the full translated `t("signup.terms")` sentence plus a small Info-icon button that preserves the terms toast (with preventDefault/stopPropagation so it doesn't toggle the checkbox). Strength indicator, terms checkbox, demo button, framer-motion entrance all preserved.

## Notes
- Placeholders that are format examples (`you@example.com`, `••••••••`, `Jane Doe`, `At least 6 characters`) and the `or` separator word were left as literal strings — no i18n keys exist for them and translating them to "Email"/"Password" words would hurt UX.
- Inline welcome toasts ("Welcome back!", "Account created! Welcome aboard.") kept as simple English welcome messages per task permission (no dedicated login/signup success toast keys; `form.toasts.success` = "Analysis complete!" which doesn't fit auth context).
- Inline validation messages without keys (valid-email, name-required, password-too-short, terms-required) kept as English literals — MVP acceptable.
- Store-returned `res.error` messages kept as-is per task guidance.

## Verification
- `cd /home/z/my-project && bun run lint` → exit 0, no errors/warnings.
- Dev server log shows repeated `✓ Compiled in …ms` with no errors after edits.

## Stage Summary
All 4 components now pull every user-facing label, button, title, subtitle, badge, stat, feature card, and validation error from the i18n dictionary via `useTranslation()`. Switching the language in the store (persisted to localStorage) immediately re-renders the landing hero, features, login, and signup views in EN/ES/FR/DE/HI/ZH. Design, layout, animations, and behavior are identical to before — only the string source changed.
