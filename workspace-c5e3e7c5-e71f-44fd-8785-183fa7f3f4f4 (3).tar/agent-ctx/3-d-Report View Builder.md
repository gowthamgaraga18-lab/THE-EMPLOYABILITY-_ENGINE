# Task ID: 3-d — Report View Builder

**Agent:** Report View Builder
**Scope:** Build the Report / Scorecard view shown after a voice mock interview completes.

## Files created
- `src/components/report/Scorecard.tsx` — the visual scorecard (verdict hero band, animated score bars, key takeaways, scrollable transcript).
- `src/components/report/ReportView.tsx` — orchestrator reading `report` from the Zustand store, with back button + primary actions row.

## Key design decisions
- **Verdict theming** via a `Record<Verdict, VerdictTheme>` config object: Strong Hire → emerald gradient + `Trophy`; Hire → lighter emerald + `Award`; Needs Work → amber gradient + `AlertTriangle`. Light tints (`bg-emerald-50` / `bg-amber-50`) used per spec, with `dark:` variants for theme parity. NO blue/indigo.
- **Animated score bars**: custom `motion.div` whose `width` animates from `0` → `${score * 20}%` on mount (duration 0.9s, ease-out, delay 0.15s). Chose a custom framer-motion bar over the shadcn `Progress` component because the shadcn indicator animates via `translateX` + CSS `transition-all`, which fights rapid framer-motion value updates; the custom bar gives precise, smooth width animation exactly as specified.
- **Star rows**: 5 `Star` icons, filled up to `score` using emerald (Technical Depth) / teal (Communication) accents, matching the score bars.
- **Qualitative labels**: `>=4` "Excellent" (emerald), `3` "Solid" (amber), `<=2` "Needs improvement" (rose) — under each score.
- **Staggered entrance**: a framer-motion `container` variant with `staggerChildren: 0.12` + `delayChildren: 0.05` orchestrates four `section` item variants (verdict band, score bars, takeaways, transcript). The verdict hero icon also springs in (`type: spring`).
- **Key takeaways**: two cards (Strengths with `ThumbsUp`/`Check` emerald; Areas to Improve with `AlertTriangle`/`Plus` amber). Each has a count `Badge`. Empty state shows italic "No specific takeaways."
- **Transcript**: `ScrollArea` (h-96) with chat bubbles — interviewer messages emerald (left), candidate messages slate (right). Each bubble shows a role label + `whitespace-pre-wrap` content. Bubble entrance is staggered with `delay: i * 0.035` (capped at 0.6s).
- **ReportView**: empty state ("No report available" with back-to-dashboard) when `report` is null. Top bar = Back ghost button + "Interview Scorecard" title with `Sparkles`. Bottom actions row = emerald "Start New Interview" (`resetInterview()` then route to `interview` if `analysis` exists else `landing`) + outline "Analyze a New Resume" (`setView('landing')`).
- All cards use `rounded-2xl p-6 gap-0` (gap overridden to 0 so manual margins control inner spacing). Max width `max-w-4xl`, centered.

## Verification
- `bun run lint` — passes (no ESLint errors).
- `bunx tsc --noEmit` — 0 errors in `report/Scorecard.tsx` and `report/ReportView.tsx`. (8 pre-existing errors live in `dashboard/DashboardView.tsx` from another agent's file — out of scope.)
- Dev server (`dev.log`) compiles cleanly; `GET /` returns 200.

## Notes for downstream agents
- The `Verdict`-keyed `verdictConfig` in `Scorecard.tsx` is the single source of truth for verdict colors/icons — reuse if verdict badges are needed elsewhere.
- To wire this view into the app shell, render `<ReportView />` when `useAppStore(s => s.view) === 'report'`.
- Used framer-motion `Variants` type annotation on the `container`/`section` objects — this provides contextual typing so `"easeOut"` literals are accepted (the un-annotated pattern triggers a `string`-not-assignable-to-`Easing` error that exists in `DashboardView.tsx`).
