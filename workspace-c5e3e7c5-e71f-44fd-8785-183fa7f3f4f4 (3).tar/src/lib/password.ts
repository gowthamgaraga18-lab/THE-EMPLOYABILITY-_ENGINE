// ============================================================================
// Password hashing utilities — using Node's built-in crypto (no bcrypt dep).
// scrypt is a modern, slow key-derivation function suitable for passwords.
// ============================================================================

import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

const KEY_LEN = 64;
const SCRYPT_N = 16384; // CPU/memory cost
const SCRYPT_R = 8;
const SCRYPT_P = 1;

/** Hash a password with a random salt using scrypt. Returns "salt:hash" (both hex). */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, KEY_LEN, {
    N: SCRYPT_N,
    r: SCRYPT_R,
    p: SCRYPT_P,
  }).toString("hex");
  return `${salt}:${hash}`;
}

/** Verify a password against a "salt:hash" string. Constant-time comparison. */
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  try {
    const testHash = scryptSync(password, salt, KEY_LEN, {
      N: SCRYPT_N,
      r: SCRYPT_R,
      p: SCRYPT_P,
    });
    const hashBuf = Buffer.from(hash, "hex");
    // Must be same length to compare with timingSafeEqual.
    if (testHash.length !== hashBuf.length) return false;
    return timingSafeEqual(testHash, hashBuf);
  } catch {
    return false;
  }
}
