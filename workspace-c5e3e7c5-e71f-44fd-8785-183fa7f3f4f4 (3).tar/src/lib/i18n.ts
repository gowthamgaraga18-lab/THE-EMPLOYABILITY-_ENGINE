// ============================================================================
// i18n — multilingual translations for The Employability Engine
// ----------------------------------------------------------------------------
// Supported languages: English, Español, Français, Deutsch, हिन्दी, 中文
// ============================================================================

export type Language = "en" | "es" | "fr" | "de" | "hi" | "zh";

export interface LanguageInfo {
  code: Language;
  label: string; // native name
  flag: string; // emoji flag
}

export const LANGUAGES: LanguageInfo[] = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "hi", label: "हिन्दी", flag: "🇮🇳" },
  { code: "zh", label: "中文", flag: "🇨🇳" },
];

// ---------------------------------------------------------------------------
// Translation keys — flat dot-notation for simplicity.
// ---------------------------------------------------------------------------

export type TranslationKey =
  // Nav
  | "nav.analyze"
  | "nav.dashboard"
  | "nav.interview"
  | "nav.history"
  | "nav.videoInterview"
  | "nav.report"
  | "nav.brand"
  | "nav.tagline"
  | "nav.login"
  | "nav.signup"
  | "nav.logout"
  | "nav.goDashboard"
  // Theme
  | "theme.switchToDark"
  | "theme.switchToLight"
  // Language
  | "language.label"
  // Hero
  | "hero.badge"
  | "hero.badgeNew"
  | "hero.titlePre"
  | "hero.titleHighlight"
  | "hero.subtitle"
  | "hero.ctaStart"
  | "hero.ctaGetStarted"
  | "hero.watchHow"
  | "hero.statMatchScore"
  | "hero.statRoadmap"
  | "hero.statVoice"
  | "hero.scrollHint"
  // Features
  | "features.label"
  | "features.titlePre"
  | "features.titleHighlight"
  | "features.subtitle"
  | "features.resumeTitle"
  | "features.resumeDesc"
  | "features.roadmapTitle"
  | "features.roadmapDesc"
  | "features.interviewTitle"
  | "features.interviewDesc"
  | "features.learnMore"
  // Analysis form
  | "form.heading"
  | "form.subheading"
  | "form.jdTabPaste"
  | "form.jdTabUrl"
  | "form.jdPlaceholder"
  | "form.jdUrlLabel"
  | "form.resumeTitle"
  | "form.resumeDropzone"
  | "form.resumeDropzoneHint"
  | "form.resumeOrPaste"
  | "form.resumePastePlaceholder"
  | "form.analyze"
  | "form.analyzing"
  | "form.fileRemoved"
  | "form.errors.noJd"
  | "form.errors.noResume"
  | "form.errors.shortResume"
  | "form.errors.shortJd"
  | "form.toasts.analyzing"
  | "form.toasts.success"
  | "form.toasts.error"
  // Auth
  | "auth.visualHeadline"
  | "auth.visualBody"
  | "auth.featureSecure"
  | "auth.featureSecureDesc"
  | "auth.featureAi"
  | "auth.featureAiDesc"
  | "auth.featureTrack"
  | "auth.featureTrackDesc"
  | "auth.quote"
  | "auth.quoteAuthor"
  | "auth.quoteRole"
  // Login
  | "login.title"
  | "login.subtitle"
  | "login.email"
  | "login.password"
  | "login.remember"
  | "login.forgot"
  | "login.submit"
  | "login.submitting"
  | "login.demo"
  | "login.noAccount"
  | "login.signupLink"
  | "login.errors.emailRequired"
  | "login.errors.passwordRequired"
  // Signup
  | "signup.title"
  | "signup.subtitle"
  | "signup.name"
  | "signup.email"
  | "signup.password"
  | "signup.terms"
  | "signup.submit"
  | "signup.submitting"
  | "signup.demo"
  | "signup.haveAccount"
  | "signup.loginLink"
  | "signup.passwordStrength.weak"
  | "signup.passwordStrength.medium"
  | "signup.passwordStrength.strong"
  | "signup.passwordStrength.tooShort"
  // Dashboard
  | "dash.noAnalysisTitle"
  | "dash.noAnalysisDesc"
  | "dash.backHome"
  | "dash.matchAnalysis"
  | "dash.skillGaps"
  | "dash.experienceGaps"
  | "dash.roadmap"
  | "dash.startInterview"
  | "dash.back"
  | "dash.filterAll"
  | "dash.noSkillsAtSeverity"
  | "dash.noGaps"
  | "dash.highSeverityCount"
  | "dash.noHighGaps"
  | "dash.keyConcepts"
  | "dash.practicalTask"
  | "dash.markComplete"
  | "dash.markIncomplete"
  | "dash.day"
  | "dash.daysCompleted"
  // Interview
  | "interview.title"
  | "interview.subtitle"
  | "interview.back"
  | "interview.interviewer"
  | "interview.question"
  | "interview.thinking"
  | "interview.record"
  | "interview.stop"
  | "interview.recordHint"
  | "interview.replay"
  | "interview.typeInstead"
  | "interview.typeAnswer"
  | "interview.cancel"
  | "interview.submit"
  | "interview.transcript"
  | "interview.noAnalysis"
  | "interview.noAnalysisDesc"
  | "interview.backToDashboard"
  | "interview.recording"
  | "interview.processing"
  | "interview.questionOf"
  | "interview.answersSubmitted"
  | "interview.buildingReport"
  | "interview.buildingReportDesc"
  | "interview.listening"
  | "interview.starting"
  | "interview.speaking"
  | "interview.browserNotSupported"
  // Report
  | "report.title"
  | "report.back"
  | "report.overallVerdict"
  | "report.technicalDepth"
  | "report.communication"
  | "report.strengths"
  | "report.areasToImprove"
  | "report.transcript"
  | "report.noReport"
  | "report.startNew"
  | "report.analyzeNew"
  | "report.excellent"
  | "report.solid"
  | "report.needsImprovement"
  // Footer
  | "footer.source"
  | "footer.builtWith";

// ---------------------------------------------------------------------------
// Translation dictionaries
// ---------------------------------------------------------------------------

type Dictionary = Record<TranslationKey, string>;

const en: Dictionary = {
  "nav.analyze": "Analyze",
  "nav.dashboard": "Dashboard",
  "nav.interview": "Interview",
  "nav.report": "Report",
  "nav.history": "History",
  "nav.videoInterview": "Video Interview",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "AI-powered career copilot",
  "nav.login": "Log in",
  "nav.signup": "Sign up",
  "nav.logout": "Log out",
  "nav.goDashboard": "Go to dashboard",

  "theme.switchToDark": "Switch to dark mode",
  "theme.switchToLight": "Switch to light mode",

  "language.label": "Language",

  "hero.badge": "AI Career Copilot",
  "hero.badgeNew": "New",
  "hero.titlePre": "The Employability",
  "hero.titleHighlight": "Engine",
  "hero.subtitle":
    "AI-powered resume analysis, a 7-day learning roadmap, and a voice mock interview with a Senior Engineering Manager — all in one place.",
  "hero.ctaStart": "Start Analyzing",
  "hero.ctaGetStarted": "Get Started",
  "hero.watchHow": "Watch how it works",
  "hero.statMatchScore": "Match Score",
  "hero.statRoadmap": "7-Day Roadmap",
  "hero.statVoice": "Voice Interview",
  "hero.scrollHint": "Scroll to analyze",

  "features.label": "FEATURES",
  "features.titlePre": "Three engines, one",
  "features.titleHighlight": "career copilot",
  "features.subtitle":
    "Everything you need to go from a job posting to interview-ready, powered by AI at every step.",
  "features.resumeTitle": "AI Resume Parsing",
  "features.resumeDesc":
    "Gemini-powered structured analysis of your resume vs the job description.",
  "features.roadmapTitle": "7-Day Learning Roadmap",
  "features.roadmapDesc":
    "A focused, day-by-day plan to close your critical skill gaps.",
  "features.interviewTitle": "Voice Mock Interview",
  "features.interviewDesc":
    "Practice with an AI Senior Engineering Manager that probes your weak spots.",
  "features.learnMore": "Learn more",

  "form.heading": "Analyze your fit, instantly",
  "form.subheading":
    "Paste a job description and your resume — get a match score, skill gaps, and a 7-day plan in seconds.",
  "form.jdTabPaste": "Paste JD",
  "form.jdTabUrl": "JD URL",
  "form.jdPlaceholder":
    "Paste the full job description here — responsibilities, required skills, qualifications…",
  "form.jdUrlLabel": "Job description URL",
  "form.resumeTitle": "Your Resume",
  "form.resumeDropzone": "Upload resume file",
  "form.resumeDropzoneHint": "Drag & drop or click to browse — .txt, .md, .pdf",
  "form.resumeOrPaste": "Or paste your resume text directly",
  "form.resumePastePlaceholder": "Paste your resume content here — experience, skills, education…",
  "form.analyze": "Analyze & Build Roadmap",
  "form.analyzing": "Analyzing…",
  "form.fileRemoved": "File removed",
  "form.errors.noJd": "Please enter a job description.",
  "form.errors.noResume": "Please enter your resume text.",
  "form.errors.shortResume": "Resume text is too short to analyze meaningfully.",
  "form.errors.shortJd": "Job description is too short to analyze meaningfully.",
  "form.toasts.analyzing": "Analyzing your resume…",
  "form.toasts.success": "Analysis complete!",
  "form.toasts.error": "Analysis failed. Please try again.",

  "auth.visualHeadline": "Land your next role with",
  "auth.visualBody":
    "Analyze your resume against any job description, get a personalized 7-day learning roadmap, and ace mock interviews with an AI Engineering Manager.",
  "auth.featureSecure": "Secure & private",
  "auth.featureSecureDesc": "Your data stays yours.",
  "auth.featureAi": "AI-powered analysis",
  "auth.featureAiDesc": "Deep resume vs. JD insights.",
  "auth.featureTrack": "Track your progress",
  "auth.featureTrackDesc": "7-day roadmaps & reports.",
  "auth.quote":
    "I went from getting ghosted to receiving two offers in three weeks. The mock interviews felt real and the roadmap was spot-on.",
  "auth.quoteAuthor": "Maya R.",
  "auth.quoteRole": "Senior Backend Engineer",

  "login.title": "Welcome back",
  "login.subtitle": "Log in to continue your career journey.",
  "login.email": "Email",
  "login.password": "Password",
  "login.remember": "Remember me",
  "login.forgot": "Forgot password?",
  "login.submit": "Log in",
  "login.submitting": "Logging in…",
  "login.demo": "Continue with demo account",
  "login.noAccount": "Don't have an account?",
  "login.signupLink": "Sign up",
  "login.errors.emailRequired": "Please enter your email.",
  "login.errors.passwordRequired": "Please enter your password.",

  "signup.title": "Create your account",
  "signup.subtitle": "Start your journey to interview-ready.",
  "signup.name": "Full name",
  "signup.email": "Email",
  "signup.password": "Password",
  "signup.terms": "I agree to the Terms & Privacy Policy",
  "signup.submit": "Create account",
  "signup.submitting": "Creating account…",
  "signup.demo": "Continue with demo account",
  "signup.haveAccount": "Already have an account?",
  "signup.loginLink": "Log in",
  "signup.passwordStrength.weak": "Weak password",
  "signup.passwordStrength.medium": "Medium strength",
  "signup.passwordStrength.strong": "Strong password",
  "signup.passwordStrength.tooShort": "Too short (min 6 chars)",

  "dash.noAnalysisTitle": "No analysis yet",
  "dash.noAnalysisDesc":
    "Run a resume-vs-JD analysis to see your personalized dashboard.",
  "dash.backHome": "Back to Home",
  "dash.matchAnalysis": "Match Analysis",
  "dash.skillGaps": "Skill Gaps Identified",
  "dash.experienceGaps": "Experience Gaps",
  "dash.roadmap": "7-Day Learning Roadmap",
  "dash.startInterview": "Start Voice Interview",
  "dash.back": "Back",
  "dash.filterAll": "All",
  "dash.noSkillsAtSeverity": "No skills at this severity.",
  "dash.noGaps": "No major experience gaps detected — great!",
  "dash.highSeverityCount": "high-severity gaps",
  "dash.noHighGaps": "No high-severity gaps — you're in good shape.",
  "dash.keyConcepts": "Key Concepts",
  "dash.practicalTask": "Practical Task",
  "dash.markComplete": "Mark Day as complete",
  "dash.markIncomplete": "Mark Day as incomplete",
  "dash.day": "Day",
  "dash.daysCompleted": "days completed",

  "interview.title": "Voice Mock Interview",
  "interview.subtitle": "Turn-based · AI Senior Engineering Manager",
  "interview.back": "Back",
  "interview.interviewer": "Interviewer",
  "interview.question": "Question",
  "interview.thinking": "Interviewer is thinking",
  "interview.record": "Record Answer",
  "interview.stop": "Stop & Submit",
  "interview.recordHint":
    "Click the mic and answer out loud. The interviewer will transcribe your answer and follow up.",
  "interview.replay": "Replay audio",
  "interview.typeInstead": "Type answer instead",
  "interview.typeAnswer": "Type your answer",
  "interview.cancel": "Cancel",
  "interview.submit": "Submit Answer",
  "interview.transcript": "Live Transcript",
  "interview.noAnalysis": "No analysis found",
  "interview.noAnalysisDesc":
    "Run a resume + JD analysis first. The interviewer needs the missing-skills list to ask targeted questions.",
  "interview.backToDashboard": "Back to Dashboard",
  "interview.recording": "recording",
  "interview.processing": "Processing…",
  "interview.questionOf": "of",
  "interview.answersSubmitted": "answers submitted",
  "interview.buildingReport": "Building your scorecard…",
  "interview.buildingReportDesc":
    "Analyzing your answers and generating your interview feedback.",
  "interview.listening": "Listening",
  "interview.starting": "Starting…",
  "interview.speaking": "Speaking",
  "interview.browserNotSupported":
    "Your browser does not support audio recording. Use the text input option.",

  "report.title": "Interview Scorecard",
  "report.back": "Back",
  "report.overallVerdict": "Overall Verdict",
  "report.technicalDepth": "Technical Depth",
  "report.communication": "Communication",
  "report.strengths": "Strengths",
  "report.areasToImprove": "Areas to Improve",
  "report.transcript": "Interview Transcript",
  "report.noReport": "No report available",
  "report.startNew": "Start New Interview",
  "report.analyzeNew": "Analyze a New Resume",
  "report.excellent": "Excellent",
  "report.solid": "Solid",
  "report.needsImprovement": "Needs improvement",

  "footer.source": "Source",
  "footer.builtWith": "Built with",
};

const es: Dictionary = {
  "nav.analyze": "Analizar",
  "nav.dashboard": "Panel",
  "nav.interview": "Entrevista",
  "nav.report": "Informe",
  "nav.history": "Historial",
  "nav.videoInterview": "Entrevista Video",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "Copiloto de carrera con IA",
  "nav.login": "Iniciar sesión",
  "nav.signup": "Registrarse",
  "nav.logout": "Cerrar sesión",
  "nav.goDashboard": "Ir al panel",

  "theme.switchToDark": "Cambiar a modo oscuro",
  "theme.switchToLight": "Cambiar a modo claro",

  "language.label": "Idioma",

  "hero.badge": "Copiloto de Carrera con IA",
  "hero.badgeNew": "Nuevo",
  "hero.titlePre": "El Motor de",
  "hero.titleHighlight": "Empleabilidad",
  "hero.subtitle":
    "Análisis de currículum con IA, una hoja de ruta de aprendizaje de 7 días y una entrevista simulada por voz con un Senior Engineering Manager — todo en un solo lugar.",
  "hero.ctaStart": "Empezar a Analizar",
  "hero.ctaGetStarted": "Comenzar",
  "hero.watchHow": "Ver cómo funciona",
  "hero.statMatchScore": "Puntuación",
  "hero.statRoadmap": "Plan de 7 Días",
  "hero.statVoice": "Entrevista Voz",
  "hero.scrollHint": "Desplázate para analizar",

  "features.label": "CARACTERÍSTICAS",
  "features.titlePre": "Tres motores, un",
  "features.titleHighlight": "copiloto de carrera",
  "features.subtitle":
    "Todo lo que necesitas para pasar de una oferta de trabajo a estar listo para la entrevista, impulsado por IA en cada paso.",
  "features.resumeTitle": "Análisis de Currículum con IA",
  "features.resumeDesc":
    "Análisis estructurado de tu currículum vs la descripción del puesto.",
  "features.roadmapTitle": "Hoja de Ruta de 7 Días",
  "features.roadmapDesc":
    "Un plan día a día para cerrar tus brechas de habilidades críticas.",
  "features.interviewTitle": "Entrevista Simulada por Voz",
  "features.interviewDesc":
    "Practica con un AI Senior Engineering Manager que explora tus puntos débiles.",
  "features.learnMore": "Saber más",

  "form.heading": "Analiza tu encaje, al instante",
  "form.subheading":
    "Pega una descripción de puesto y tu currículum — obtén puntuación, brechas y un plan de 7 días en segundos.",
  "form.jdTabPaste": "Pegar JD",
  "form.jdTabUrl": "URL del JD",
  "form.jdPlaceholder":
    "Pega la descripción completa del puesto aquí — responsabilidades, habilidades, cualificaciones…",
  "form.jdUrlLabel": "URL de la descripción del puesto",
  "form.resumeTitle": "Tu Currículum",
  "form.resumeDropzone": "Subir archivo de currículum",
  "form.resumeDropzoneHint": "Arrastra o haz clic para explorar — .txt, .md, .pdf",
  "form.resumeOrPaste": "O pega el texto de tu currículum directamente",
  "form.resumePastePlaceholder": "Pega el contenido de tu currículum aquí — experiencia, habilidades, educación…",
  "form.analyze": "Analizar y Crear Hoja de Ruta",
  "form.analyzing": "Analizando…",
  "form.fileRemoved": "Archivo eliminado",
  "form.errors.noJd": "Por favor, introduce una descripción del puesto.",
  "form.errors.noResume": "Por favor, introduce el texto de tu currículum.",
  "form.errors.shortResume": "El currículum es demasiado corto para analizar.",
  "form.errors.shortJd": "La descripción del puesto es demasiado corta.",
  "form.toasts.analyzing": "Analizando tu currículum…",
  "form.toasts.success": "¡Análisis completado!",
  "form.toasts.error": "El análisis falló. Inténtalo de nuevo.",

  "auth.visualHeadline": "Consigue tu próximo rol con",
  "auth.visualBody":
    "Analiza tu currículum contra cualquier descripción de puesto, obtén una hoja de ruta personalizada de 7 días y supera entrevistas simuladas con un AI Engineering Manager.",
  "auth.featureSecure": "Seguro y privado",
  "auth.featureSecureDesc": "Tus datos son tuyos.",
  "auth.featureAi": "Análisis con IA",
  "auth.featureAiDesc": "Insights profundos de currículum vs JD.",
  "auth.featureTrack": "Sigue tu progreso",
  "auth.featureTrackDesc": "Hojas de ruta de 7 días e informes.",
  "auth.quote":
    "Pasé de ser ignorado a recibir dos ofertas en tres semanas. Las entrevistas simuladas se sentían reales y la hoja de ruta fue precisa.",
  "auth.quoteAuthor": "Maya R.",
  "auth.quoteRole": "Senior Backend Engineer",

  "login.title": "Bienvenido de nuevo",
  "login.subtitle": "Inicia sesión para continuar tu viaje profesional.",
  "login.email": "Correo",
  "login.password": "Contraseña",
  "login.remember": "Recuérdame",
  "login.forgot": "¿Olvidaste tu contraseña?",
  "login.submit": "Iniciar sesión",
  "login.submitting": "Iniciando…",
  "login.demo": "Continuar con cuenta demo",
  "login.noAccount": "¿No tienes cuenta?",
  "login.signupLink": "Regístrate",
  "login.errors.emailRequired": "Por favor, introduce tu correo.",
  "login.errors.passwordRequired": "Por favor, introduce tu contraseña.",

  "signup.title": "Crea tu cuenta",
  "signup.subtitle": "Comienza tu viaje hacia estar listo para entrevistas.",
  "signup.name": "Nombre completo",
  "signup.email": "Correo",
  "signup.password": "Contraseña",
  "signup.terms": "Acepto los Términos y la Política de Privacidad",
  "signup.submit": "Crear cuenta",
  "signup.submitting": "Creando cuenta…",
  "signup.demo": "Continuar con cuenta demo",
  "signup.haveAccount": "¿Ya tienes cuenta?",
  "signup.loginLink": "Inicia sesión",
  "signup.passwordStrength.weak": "Contraseña débil",
  "signup.passwordStrength.medium": "Fortaleza media",
  "signup.passwordStrength.strong": "Contraseña fuerte",
  "signup.passwordStrength.tooShort": "Muy corta (mín 6 caracteres)",

  "dash.noAnalysisTitle": "Sin análisis aún",
  "dash.noAnalysisDesc":
    "Ejecuta un análisis de currículum vs JD para ver tu panel personalizado.",
  "dash.backHome": "Volver al Inicio",
  "dash.matchAnalysis": "Análisis de Encaje",
  "dash.skillGaps": "Brechas de Habilidades",
  "dash.experienceGaps": "Brechas de Experiencia",
  "dash.roadmap": "Hoja de Ruta de 7 Días",
  "dash.startInterview": "Iniciar Entrevista por Voz",
  "dash.back": "Atrás",
  "dash.filterAll": "Todos",
  "dash.noSkillsAtSeverity": "Sin habilidades en esta severidad.",
  "dash.noGaps": "Sin brechas importantes — ¡genial!",
  "dash.highSeverityCount": "brechas de alta severidad",
  "dash.noHighGaps": "Sin brechas altas — estás en buena forma.",
  "dash.keyConcepts": "Conceptos Clave",
  "dash.practicalTask": "Tarea Práctica",
  "dash.markComplete": "Marcar día como completado",
  "dash.markIncomplete": "Marcar día como incompleto",
  "dash.day": "Día",
  "dash.daysCompleted": "días completados",

  "interview.title": "Entrevista Simulada por Voz",
  "interview.subtitle": "Por turnos · AI Senior Engineering Manager",
  "interview.back": "Atrás",
  "interview.interviewer": "Entrevistador",
  "interview.question": "Pregunta",
  "interview.thinking": "El entrevistador está pensando",
  "interview.record": "Grabar Respuesta",
  "interview.stop": "Detener y Enviar",
  "interview.recordHint":
    "Haz clic en el micrófono y responde en voz alta. El entrevistador transcribirá tu respuesta.",
  "interview.replay": "Reproducir audio",
  "interview.typeInstead": "Escribir respuesta",
  "interview.typeAnswer": "Escribe tu respuesta",
  "interview.cancel": "Cancelar",
  "interview.submit": "Enviar Respuesta",
  "interview.transcript": "Transcripción en Vivo",
  "interview.noAnalysis": "Sin análisis encontrado",
  "interview.noAnalysisDesc":
    "Ejecuta un análisis primero. El entrevistador necesita la lista de habilidades faltantes.",
  "interview.backToDashboard": "Volver al Panel",
  "interview.recording": "grabando",
  "interview.processing": "Procesando…",
  "interview.questionOf": "de",
  "interview.answersSubmitted": "respuestas enviadas",
  "interview.buildingReport": "Creando tu evaluación…",
  "interview.buildingReportDesc":
    "Analizando tus respuestas y generando feedback.",
  "interview.listening": "Escuchando",
  "interview.starting": "Iniciando…",
  "interview.speaking": "Hablando",
  "interview.browserNotSupported":
    "Tu navegador no soporta grabación de audio. Usa la opción de texto.",

  "report.title": "Evaluación de Entrevista",
  "report.back": "Atrás",
  "report.overallVerdict": "Veredicto General",
  "report.technicalDepth": "Profundidad Técnica",
  "report.communication": "Comunicación",
  "report.strengths": "Fortalezas",
  "report.areasToImprove": "Áreas a Mejorar",
  "report.transcript": "Transcripción de Entrevista",
  "report.noReport": "Sin informe disponible",
  "report.startNew": "Nueva Entrevista",
  "report.analyzeNew": "Analizar Nuevo Currículum",
  "report.excellent": "Excelente",
  "report.solid": "Sólido",
  "report.needsImprovement": "Necesita mejorar",

  "footer.source": "Código",
  "footer.builtWith": "Hecho con",
};

const fr: Dictionary = {
  "nav.analyze": "Analyser",
  "nav.dashboard": "Tableau",
  "nav.interview": "Entretien",
  "nav.report": "Rapport",
  "nav.history": "Historique",
  "nav.videoInterview": "Entretien Vidéo",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "Copilote de carrière IA",
  "nav.login": "Connexion",
  "nav.signup": "S'inscrire",
  "nav.logout": "Déconnexion",
  "nav.goDashboard": "Aller au tableau",

  "theme.switchToDark": "Passer en mode sombre",
  "theme.switchToLight": "Passer en mode clair",

  "language.label": "Langue",

  "hero.badge": "Copilote de Carrière IA",
  "hero.badgeNew": "Nouveau",
  "hero.titlePre": "Le Moteur d'",
  "hero.titleHighlight": "Employabilité",
  "hero.subtitle":
    "Analyse de CV par IA, une feuille de route d'apprentissage de 7 jours et un entretien simulé vocal avec un Senior Engineering Manager — tout en un seul endroit.",
  "hero.ctaStart": "Commencer l'Analyse",
  "hero.ctaGetStarted": "Démarrer",
  "hero.watchHow": "Voir comment ça marche",
  "hero.statMatchScore": "Score",
  "hero.statRoadmap": "Plan 7 Jours",
  "hero.statVoice": "Entretien Vocal",
  "hero.scrollHint": "Faites défiler pour analyser",

  "features.label": "FONCTIONNALITÉS",
  "features.titlePre": "Trois moteurs, un",
  "features.titleHighlight": "copilote de carrière",
  "features.subtitle":
    "Tout ce dont vous avez besoin pour passer d'une offre d'emploi à prêt pour l'entretien, propulsé par IA à chaque étape.",
  "features.resumeTitle": "Analyse de CV par IA",
  "features.resumeDesc":
    "Analyse structurée de votre CV vs la description de poste.",
  "features.roadmapTitle": "Feuille de Route de 7 Jours",
  "features.roadmapDesc":
    "Un plan jour par jour pour combler vos lacunes critiques.",
  "features.interviewTitle": "Entretien Simulé Vocal",
  "features.interviewDesc":
    "Pratiquez avec un AI Senior Engineering Manager qui sonde vos points faibles.",
  "features.learnMore": "En savoir plus",

  "form.heading": "Analysez votre adéquation, instantanément",
  "form.subheading":
    "Collez une description de poste et votre CV — obtenez un score, des lacunes et un plan de 7 jours en secondes.",
  "form.jdTabPaste": "Coller JD",
  "form.jdTabUrl": "URL du JD",
  "form.jdPlaceholder":
    "Collez la description complète du poste ici — responsabilités, compétences requises, qualifications…",
  "form.jdUrlLabel": "URL de la description de poste",
  "form.resumeTitle": "Votre CV",
  "form.resumeDropzone": "Télécharger le fichier CV",
  "form.resumeDropzoneHint": "Glisser-déposer ou cliquer pour parcourir — .txt, .md, .pdf",
  "form.resumeOrPaste": "Ou collez le texte de votre CV directement",
  "form.resumePastePlaceholder": "Collez le contenu de votre CV ici — expérience, compétences, formation…",
  "form.analyze": "Analyser et Créer la Feuille de Route",
  "form.analyzing": "Analyse…",
  "form.fileRemoved": "Fichier supprimé",
  "form.errors.noJd": "Veuillez saisir une description de poste.",
  "form.errors.noResume": "Veuillez saisir le texte de votre CV.",
  "form.errors.shortResume": "Le CV est trop court pour être analysé.",
  "form.errors.shortJd": "La description de poste est trop courte.",
  "form.toasts.analyzing": "Analyse de votre CV…",
  "form.toasts.success": "Analyse terminée !",
  "form.toasts.error": "L'analyse a échoué. Réessayez.",

  "auth.visualHeadline": "Décrochez votre prochain rôle avec",
  "auth.visualBody":
    "Analysez votre CV contre n'importe quelle description de poste, obtenez une feuille de route personnalisée de 7 jours et réussissez des entretiens simulés avec un AI Engineering Manager.",
  "auth.featureSecure": "Sécurisé et privé",
  "auth.featureSecureDesc": "Vos données restent les vôtres.",
  "auth.featureAi": "Analyse par IA",
  "auth.featureAiDesc": "Insights profonds CV vs JD.",
  "auth.featureTrack": "Suivez votre progression",
  "auth.featureTrackDesc": "Feuilles de route de 7 jours & rapports.",
  "auth.quote":
    "Je suis passé de candidat ignoré à deux offres en trois semaines. Les entretiens simulés semblaient réels et la feuille de route était précise.",
  "auth.quoteAuthor": "Maya R.",
  "auth.quoteRole": "Senior Backend Engineer",

  "login.title": "Bon retour",
  "login.subtitle": "Connectez-vous pour continuer votre parcours.",
  "login.email": "Email",
  "login.password": "Mot de passe",
  "login.remember": "Se souvenir de moi",
  "login.forgot": "Mot de passe oublié ?",
  "login.submit": "Connexion",
  "login.submitting": "Connexion…",
  "login.demo": "Continuer avec un compte démo",
  "login.noAccount": "Pas de compte ?",
  "login.signupLink": "S'inscrire",
  "login.errors.emailRequired": "Veuillez saisir votre email.",
  "login.errors.passwordRequired": "Veuillez saisir votre mot de passe.",

  "signup.title": "Créez votre compte",
  "signup.subtitle": "Commencez votre voyage vers prêt pour l'entretien.",
  "signup.name": "Nom complet",
  "signup.email": "Email",
  "signup.password": "Mot de passe",
  "signup.terms": "J'accepte les Conditions et la Politique de Confidentialité",
  "signup.submit": "Créer le compte",
  "signup.submitting": "Création…",
  "signup.demo": "Continuer avec un compte démo",
  "signup.haveAccount": "Vous avez déjà un compte ?",
  "signup.loginLink": "Connexion",
  "signup.passwordStrength.weak": "Mot de passe faible",
  "signup.passwordStrength.medium": "Force moyenne",
  "signup.passwordStrength.strong": "Mot de passe fort",
  "signup.passwordStrength.tooShort": "Trop court (min 6 caractères)",

  "dash.noAnalysisTitle": "Pas encore d'analyse",
  "dash.noAnalysisDesc":
    "Lancez une analyse CV vs JD pour voir votre tableau personnalisé.",
  "dash.backHome": "Retour à l'Accueil",
  "dash.matchAnalysis": "Analyse d'Adéquation",
  "dash.skillGaps": "Lacunes de Compétences",
  "dash.experienceGaps": "Lacunes d'Expérience",
  "dash.roadmap": "Feuille de Route de 7 Jours",
  "dash.startInterview": "Démarrer l'Entretien Vocal",
  "dash.back": "Retour",
  "dash.filterAll": "Tous",
  "dash.noSkillsAtSeverity": "Aucune compétence à cette sévérité.",
  "dash.noGaps": "Aucune lacune majeure — super !",
  "dash.highSeverityCount": "lacunes de haute sévérité",
  "dash.noHighGaps": "Aucune lacune haute — vous êtes en bonne forme.",
  "dash.keyConcepts": "Concepts Clés",
  "dash.practicalTask": "Tâche Pratique",
  "dash.markComplete": "Marquer le jour comme terminé",
  "dash.markIncomplete": "Marquer le jour comme incomplet",
  "dash.day": "Jour",
  "dash.daysCompleted": "jours terminés",

  "interview.title": "Entretien Simulé Vocal",
  "interview.subtitle": "Par tours · AI Senior Engineering Manager",
  "interview.back": "Retour",
  "interview.interviewer": "Intervieweur",
  "interview.question": "Question",
  "interview.thinking": "L'intervieweur réfléchit",
  "interview.record": "Enregistrer la Réponse",
  "interview.stop": "Arrêter et Envoyer",
  "interview.recordHint":
    "Cliquez sur le micro et répondez à voix haute. L'intervieweur transcrira votre réponse.",
  "interview.replay": "Rejouer l'audio",
  "interview.typeInstead": "Taper la réponse",
  "interview.typeAnswer": "Tapez votre réponse",
  "interview.cancel": "Annuler",
  "interview.submit": "Envoyer la Réponse",
  "interview.transcript": "Transcription en Direct",
  "interview.noAnalysis": "Aucune analyse trouvée",
  "interview.noAnalysisDesc":
    "Lancez d'abord une analyse. L'intervieweur a besoin de la liste des compétences manquantes.",
  "interview.backToDashboard": "Retour au Tableau",
  "interview.recording": "enregistrement",
  "interview.processing": "Traitement…",
  "interview.questionOf": "sur",
  "interview.answersSubmitted": "réponses envoyées",
  "interview.buildingReport": "Création de votre évaluation…",
  "interview.buildingReportDesc":
    "Analyse de vos réponses et génération de feedback.",
  "interview.listening": "Écoute",
  "interview.starting": "Démarrage…",
  "interview.speaking": "Parle",
  "interview.browserNotSupported":
    "Votre navigateur ne supporte pas l'enregistrement audio. Utilisez l'option texte.",

  "report.title": "Évaluation d'Entretien",
  "report.back": "Retour",
  "report.overallVerdict": "Verdict Global",
  "report.technicalDepth": "Profondeur Technique",
  "report.communication": "Communication",
  "report.strengths": "Forces",
  "report.areasToImprove": "Axes d'Amélioration",
  "report.transcript": "Transcription de l'Entretien",
  "report.noReport": "Aucun rapport disponible",
  "report.startNew": "Nouvel Entretien",
  "report.analyzeNew": "Analyser un Nouveau CV",
  "report.excellent": "Excellent",
  "report.solid": "Solide",
  "report.needsImprovement": "À améliorer",

  "footer.source": "Source",
  "footer.builtWith": "Fait avec",
};

const de: Dictionary = {
  "nav.analyze": "Analysieren",
  "nav.dashboard": "Übersicht",
  "nav.interview": "Interview",
  "nav.report": "Bericht",
  "nav.history": "Verlauf",
  "nav.videoInterview": "Video-Interview",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "KI-Karriere-Copilot",
  "nav.login": "Anmelden",
  "nav.signup": "Registrieren",
  "nav.logout": "Abmelden",
  "nav.goDashboard": "Zur Übersicht",

  "theme.switchToDark": "Zum dunklen Modus wechseln",
  "theme.switchToLight": "Zum hellen Modus wechseln",

  "language.label": "Sprache",

  "hero.badge": "KI-Karriere-Copilot",
  "hero.badgeNew": "Neu",
  "hero.titlePre": "Die",
  "hero.titleHighlight": "Vermittelbarkeits-Maschine",
  "hero.subtitle":
    "KI-gestützte Lebenslauf-Analyse, ein 7-Tage-Lernplan und ein sprachgesteuertes Mock-Interview mit einem Senior Engineering Manager — alles an einem Ort.",
  "hero.ctaStart": "Analyse starten",
  "hero.ctaGetStarted": "Loslegen",
  "hero.watchHow": "So funktioniert's",
  "hero.statMatchScore": "Match-Score",
  "hero.statRoadmap": "7-Tage-Plan",
  "hero.statVoice": "Sprach-Interview",
  "hero.scrollHint": "Zum Analysieren scrollen",

  "features.label": "FUNKTIONEN",
  "features.titlePre": "Drei Motoren, ein",
  "features.titleHighlight": "Karriere-Copilot",
  "features.subtitle":
    "Alles, was Sie brauchen, um von der Stellenanzeige zum interviewbereiten Kandidaten zu werden — mit KI in jedem Schritt.",
  "features.resumeTitle": "KI-Lebenslauf-Analyse",
  "features.resumeDesc":
    "Strukturierte Analyse Ihres Lebenslaufs vs. der Stellenbeschreibung.",
  "features.roadmapTitle": "7-Tage-Lernplan",
  "features.roadmapDesc":
    "Ein täglicher Plan, um Ihre kritischen Kompetenzlücken zu schließen.",
  "features.interviewTitle": "Sprachgesteuertes Mock-Interview",
  "features.interviewDesc":
    "Üben Sie mit einem AI Senior Engineering Manager, der Ihre Schwächen prüft.",
  "features.learnMore": "Mehr erfahren",

  "form.heading": "Analysieren Sie Ihre Passung, sofort",
  "form.subheading":
    "Stellenbeschreibung und Lebenslauf einfügen — Match-Score, Lücken und 7-Tage-Plan in Sekunden.",
  "form.jdTabPaste": "JD einfügen",
  "form.jdTabUrl": "JD-URL",
  "form.jdPlaceholder":
    "Vollständige Stellenbeschreibung hier einfügen — Verantwortlichkeiten, Fähigkeiten, Qualifikationen…",
  "form.jdUrlLabel": "URL der Stellenbeschreibung",
  "form.resumeTitle": "Ihr Lebenslauf",
  "form.resumeDropzone": "Lebenslauf-Datei hochladen",
  "form.resumeDropzoneHint": "Drag & Drop oder Klick zum Durchsuchen — .txt, .md, .pdf",
  "form.resumeOrPaste": "Oder Lebenslauf-Text direkt einfügen",
  "form.resumePastePlaceholder": "Lebenslauf-Inhalt hier einfügen — Erfahrung, Fähigkeiten, Ausbildung…",
  "form.analyze": "Analysieren & Plan erstellen",
  "form.analyzing": "Analysiere…",
  "form.fileRemoved": "Datei entfernt",
  "form.errors.noJd": "Bitte Stellenbeschreibung eingeben.",
  "form.errors.noResume": "Bitte Lebenslauf-Text eingeben.",
  "form.errors.shortResume": "Lebenslauf zu kurz für Analyse.",
  "form.errors.shortJd": "Stellenbeschreibung zu kurz.",
  "form.toasts.analyzing": "Analysiere Ihren Lebenslauf…",
  "form.toasts.success": "Analyse abgeschlossen!",
  "form.toasts.error": "Analyse fehlgeschlagen. Bitte erneut versuchen.",

  "auth.visualHeadline": "Bekommen Sie Ihre nächste Rolle mit",
  "auth.visualBody":
    "Analysieren Sie Ihren Lebenslauf gegen jede Stellenbeschreibung, erhalten Sie einen personalisierten 7-Tage-Plan und bestehen Sie Mock-Interviews mit einem AI Engineering Manager.",
  "auth.featureSecure": "Sicher & privat",
  "auth.featureSecureDesc": "Ihre Daten bleiben Ihre.",
  "auth.featureAi": "KI-gestützte Analyse",
  "auth.featureAiDesc": "Tiefe Lebenslauf-vs-JD-Einblicke.",
  "auth.featureTrack": "Verfolgen Sie Ihren Fortschritt",
  "auth.featureTrackDesc": "7-Tage-Pläne & Berichte.",
  "auth.quote":
    "Ich ging von Ignoriert-Werden zu zwei Angeboten in drei Wochen. Die Mock-Interviews fühlten sich echt an und der Plan war treffend.",
  "auth.quoteAuthor": "Maya R.",
  "auth.quoteRole": "Senior Backend Engineer",

  "login.title": "Willkommen zurück",
  "login.subtitle": "Melden Sie sich an, um Ihre Karriere fortzusetzen.",
  "login.email": "E-Mail",
  "login.password": "Passwort",
  "login.remember": "Angemeldet bleiben",
  "login.forgot": "Passwort vergessen?",
  "login.submit": "Anmelden",
  "login.submitting": "Anmelden…",
  "login.demo": "Mit Demo-Konto fortfahren",
  "login.noAccount": "Kein Konto?",
  "login.signupLink": "Registrieren",
  "login.errors.emailRequired": "Bitte E-Mail eingeben.",
  "login.errors.passwordRequired": "Bitte Passwort eingeben.",

  "signup.title": "Konto erstellen",
  "signup.subtitle": "Starten Sie Ihre Reise zum interviewbereiten Kandidaten.",
  "signup.name": "Vollständiger Name",
  "signup.email": "E-Mail",
  "signup.password": "Passwort",
  "signup.terms": "Ich stimme den Bedingungen & der Datenschutzerklärung zu",
  "signup.submit": "Konto erstellen",
  "signup.submitting": "Wird erstellt…",
  "signup.demo": "Mit Demo-Konto fortfahren",
  "signup.haveAccount": "Schon ein Konto?",
  "signup.loginLink": "Anmelden",
  "signup.passwordStrength.weak": "Schwaches Passwort",
  "signup.passwordStrength.medium": "Mittlere Stärke",
  "signup.passwordStrength.strong": "Starkes Passwort",
  "signup.passwordStrength.tooShort": "Zu kurz (min 6 Zeichen)",

  "dash.noAnalysisTitle": "Noch keine Analyse",
  "dash.noAnalysisDesc":
    "Führen Sie eine Lebenslauf-vs-JD-Analyse aus, um Ihre Übersicht zu sehen.",
  "dash.backHome": "Zurück zur Startseite",
  "dash.matchAnalysis": "Match-Analyse",
  "dash.skillGaps": "Kompetenzlücken",
  "dash.experienceGaps": "Erfahrungslücken",
  "dash.roadmap": "7-Tage-Lernplan",
  "dash.startInterview": "Sprach-Interview starten",
  "dash.back": "Zurück",
  "dash.filterAll": "Alle",
  "dash.noSkillsAtSeverity": "Keine Fähigkeiten in diesem Schweregrad.",
  "dash.noGaps": "Keine größeren Erfahrungslücken — super!",
  "dash.highSeverityCount": "Lücken mit hoher Schwere",
  "dash.noHighGaps": "Keine hohen Lücken — Sie sind in guter Form.",
  "dash.keyConcepts": "Schlüsselkonzepte",
  "dash.practicalTask": "Praktische Aufgabe",
  "dash.markComplete": "Tag als erledigt markieren",
  "dash.markIncomplete": "Tag als unerledigt markieren",
  "dash.day": "Tag",
  "dash.daysCompleted": "Tage abgeschlossen",

  "interview.title": "Sprachgesteuertes Mock-Interview",
  "interview.subtitle": "Zugbasiert · AI Senior Engineering Manager",
  "interview.back": "Zurück",
  "interview.interviewer": "Interviewer",
  "interview.question": "Frage",
  "interview.thinking": "Interviewer denkt nach",
  "interview.record": "Antwort aufnehmen",
  "interview.stop": "Stopp & Senden",
  "interview.recordHint":
    "Klicken Sie auf das Mikro und antworten Sie laut. Der Interviewer transkribiert Ihre Antwort.",
  "interview.replay": "Audio wiederholen",
  "interview.typeInstead": "Antwort tippen",
  "interview.typeAnswer": "Tippen Sie Ihre Antwort",
  "interview.cancel": "Abbrechen",
  "interview.submit": "Antwort senden",
  "interview.transcript": "Live-Transkript",
  "interview.noAnalysis": "Keine Analyse gefunden",
  "interview.noAnalysisDesc":
    "Führen Sie zuerst eine Analyse aus. Der Interviewer braucht die Liste fehlender Fähigkeiten.",
  "interview.backToDashboard": "Zurück zur Übersicht",
  "interview.recording": "Aufnahme",
  "interview.processing": "Verarbeitung…",
  "interview.questionOf": "von",
  "interview.answersSubmitted": "Antworten gesendet",
  "interview.buildingReport": "Erstelle Ihre Bewertung…",
  "interview.buildingReportDesc":
    "Ihre Antworten werden analysiert und Feedback generiert.",
  "interview.listening": "Lauscht",
  "interview.starting": "Startet…",
  "interview.speaking": "Spricht",
  "interview.browserNotSupported":
    "Ihr Browser unterstützt keine Audioaufnahme. Verwenden Sie die Text-Option.",

  "report.title": "Interview-Bewertung",
  "report.back": "Zurück",
  "report.overallVerdict": "Gesamturteil",
  "report.technicalDepth": "Technische Tiefe",
  "report.communication": "Kommunikation",
  "report.strengths": "Stärken",
  "report.areasToImprove": "Verbesserungsbereiche",
  "report.transcript": "Interview-Transkript",
  "report.noReport": "Kein Bericht verfügbar",
  "report.startNew": "Neues Interview",
  "report.analyzeNew": "Neuen Lebenslauf analysieren",
  "report.excellent": "Ausgezeichnet",
  "report.solid": "Solide",
  "report.needsImprovement": "Verbesserungsbedarf",

  "footer.source": "Quelle",
  "footer.builtWith": "Gemacht mit",
};

const hi: Dictionary = {
  "nav.analyze": "विश्लेषण",
  "nav.dashboard": "डैशबोर्ड",
  "nav.interview": "साक्षात्कार",
  "nav.report": "रिपोर्ट",
  "nav.history": "इतिहास",
  "nav.videoInterview": "वीडियो इंटरव्यू",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "एआई-संचालित करियर सहायक",
  "nav.login": "लॉग इन",
  "nav.signup": "साइन अप",
  "nav.logout": "लॉग आउट",
  "nav.goDashboard": "डैशबोर्ड पर जाएं",

  "theme.switchToDark": "डार्क मोड पर स्विच करें",
  "theme.switchToLight": "लाइट मोड पर स्विच करें",

  "language.label": "भाषा",

  "hero.badge": "एआई करियर सहायक",
  "hero.badgeNew": "नया",
  "hero.titlePre": "द",
  "hero.titleHighlight": "एम्प्लॉयबिलिटी इंजन",
  "hero.subtitle":
    "एआई-संचालित रिज्यूमे विश्लेषण, 7-दिन की सीखने की रोडमैप, और एक सीनियर इंजीनियरिंग मैनेजर के साथ वॉइस मॉक इंटरव्यू — सब एक जगह।",
  "hero.ctaStart": "विश्लेषण शुरू करें",
  "hero.ctaGetStarted": "शुरू करें",
  "hero.watchHow": "देखें कैसे काम करता है",
  "hero.statMatchScore": "मैच स्कोर",
  "hero.statRoadmap": "7-दिन रोडमैप",
  "hero.statVoice": "वॉइस इंटरव्यू",
  "hero.scrollHint": "विश्लेषण के लिए स्क्रॉल करें",

  "features.label": "विशेषताएं",
  "features.titlePre": "तीन इंजन, एक",
  "features.titleHighlight": "करियर सहायक",
  "features.subtitle":
    "जॉब पोस्टिंग से इंटरव्यू-रेडी तक जाने के लिए सब कुछ, हर कदम पर एआई के साथ।",
  "features.resumeTitle": "एआई रिज्यूमे विश्लेषण",
  "features.resumeDesc": "आपके रिज्यूमे बनाम जॉब डिस्क्रिप्शन का संरचित विश्लेषण।",
  "features.roadmapTitle": "7-दिन सीखने की रोडमैप",
  "features.roadmapDesc": "अपनी महत्वपूर्ण स्किल गैप भरने के लिए दिन-वार योजना।",
  "features.interviewTitle": "वॉइस मॉक इंटरव्यू",
  "features.interviewDesc": "एआई सीनियर इंजीनियरिंग मैनेजर के साथ अभ्यास करें जो आपकी कमजोरियों को जांचता है।",
  "features.learnMore": "और जानें",

  "form.heading": "अपनी फिट विश्लेषण करें, तुरंत",
  "form.subheading": "जॉब डिस्क्रिप्शन और रिज्यूमे पेस्ट करें — सेकंडों में मैच स्कोर, गैप और 7-दिन योजना पाएं।",
  "form.jdTabPaste": "JD पेस्ट करें",
  "form.jdTabUrl": "JD URL",
  "form.jdPlaceholder": "पूरी जॉब डिस्क्रिप्शन यहां पेस्ट करें — जिम्मेदारियां, आवश्यक स्किल्स, योग्यताएं…",
  "form.jdUrlLabel": "जॉब डिस्क्रिप्शन URL",
  "form.resumeTitle": "आपका रिज्यूमे",
  "form.resumeDropzone": "रिज्यूमे फ़ाइल अपलोड करें",
  "form.resumeDropzoneHint": "ड्रैग और ड्रॉप या ब्राउज़ करने के लिए क्लिक करें — .txt, .md, .pdf",
  "form.resumeOrPaste": "या अपना रिज्यूमे टेक्स्ट सीधे पेस्ट करें",
  "form.resumePastePlaceholder": "अपना रिज्यूमे कंटेंट यहां पेस्ट करें — अनुभव, स्किल्स, शिक्षा…",
  "form.analyze": "विश्लेषण करें और रोडमैप बनाएं",
  "form.analyzing": "विश्लेषण हो रहा है…",
  "form.fileRemoved": "फ़ाइल हटाई गई",
  "form.errors.noJd": "कृपया जॉब डिस्क्रिप्शन दर्ज करें।",
  "form.errors.noResume": "कृपया अपना रिज्यूमे टेक्स्ट दर्ज करें।",
  "form.errors.shortResume": "रिज्यूमे विश्लेषण के लिए बहुत छोटा है।",
  "form.errors.shortJd": "जॉब डिस्क्रिप्शन बहुत छोटी है।",
  "form.toasts.analyzing": "आपका रिज्यूमे विश्लेषण हो रहा है…",
  "form.toasts.success": "विश्लेषण पूर्ण!",
  "form.toasts.error": "विश्लेषण विफल। कृपया पुनः प्रयास करें।",

  "auth.visualHeadline": "अपनी अगली भूमिका पाएं",
  "auth.visualBody": "किसी भी जॉब डिस्क्रिप्शन के विरुद्ध अपना रिज्यूमे विश्लेषण करें, व्यक्तिगत 7-दिन रोडमैप पाएं, और एआई इंजीनियरिंग मैनेजर के साथ मॉक इंटरव्यू में सफल हों।",
  "auth.featureSecure": "सुरक्षित और निजी",
  "auth.featureSecureDesc": "आपका डेटा आपका रहता है।",
  "auth.featureAi": "एआई-संचालित विश्लेषण",
  "auth.featureAiDesc": "रिज्यूमे बनाम JD की गहरी जानकारी।",
  "auth.featureTrack": "अपनी प्रगति ट्रैक करें",
  "auth.featureTrackDesc": "7-दिन रोडमैप और रिपोर्ट।",
  "auth.quote": "मैं अनदेखा होने से तीन हफ्तों में दो ऑफर मिले। मॉक इंटरव्यू असली लगे और रोडमैप सटीक था।",
  "auth.quoteAuthor": "माया आर.",
  "auth.quoteRole": "सीनियर बैकएंड इंजीनियर",

  "login.title": "वापसी पर स्वागत है",
  "login.subtitle": "अपनी करियर यात्रा जारी रखने के लिए लॉग इन करें।",
  "login.email": "ईमेल",
  "login.password": "पासवर्ड",
  "login.remember": "मुझे याद रखें",
  "login.forgot": "पासवर्ड भूल गए?",
  "login.submit": "लॉग इन",
  "login.submitting": "लॉग इन हो रहा है…",
  "login.demo": "डेमो खाते से जारी रखें",
  "login.noAccount": "खाता नहीं है?",
  "login.signupLink": "साइन अप",
  "login.errors.emailRequired": "कृपया अपना ईमेल दर्ज करें।",
  "login.errors.passwordRequired": "कृपया अपना पासवर्ड दर्ज करें।",

  "signup.title": "अपना खाता बनाएं",
  "signup.subtitle": "इंटरव्यू-रेडी बनने की अपनी यात्रा शुरू करें।",
  "signup.name": "पूरा नाम",
  "signup.email": "ईमेल",
  "signup.password": "पासवर्ड",
  "signup.terms": "मैं नियम और गोपनीयता नीति से सहमत हूं",
  "signup.submit": "खाता बनाएं",
  "signup.submitting": "खाता बन रहा है…",
  "signup.demo": "डेमो खाते से जारी रखें",
  "signup.haveAccount": "पहले से खाता है?",
  "signup.loginLink": "लॉग इन",
  "signup.passwordStrength.weak": "कमजोर पासवर्ड",
  "signup.passwordStrength.medium": "मध्यम शक्ति",
  "signup.passwordStrength.strong": "मजबूत पासवर्ड",
  "signup.passwordStrength.tooShort": "बहुत छोटा (न्यूनतम 6 अक्षर)",

  "dash.noAnalysisTitle": "अभी कोई विश्लेषण नहीं",
  "dash.noAnalysisDesc": "अपना व्यक्तिगत डैशबोर्ड देखने के लिए रिज्यूमे-बनाम-JD विश्लेषण चलाएं।",
  "dash.backHome": "होम पर वापस",
  "dash.matchAnalysis": "मैच विश्लेषण",
  "dash.skillGaps": "स्किल गैप की पहचान",
  "dash.experienceGaps": "अनुभव गैप",
  "dash.roadmap": "7-दिन सीखने की रोडमैप",
  "dash.startInterview": "वॉइस इंटरव्यू शुरू करें",
  "dash.back": "वापस",
  "dash.filterAll": "सभी",
  "dash.noSkillsAtSeverity": "इस गंभीरता पर कोई स्किल नहीं।",
  "dash.noGaps": "कोई बड़ा अनुभव गैप नहीं — बढ़िया!",
  "dash.highSeverityCount": "उच्च-गंभीरता गैप",
  "dash.noHighGaps": "कोई उच्च गैप नहीं — आप अच्छी स्थिति में हैं।",
  "dash.keyConcepts": "मुख्य अवधारणाएं",
  "dash.practicalTask": "व्यावहारिक कार्य",
  "dash.markComplete": "दिन पूर्ण चिह्नित करें",
  "dash.markIncomplete": "दिन अपूर्ण चिह्नित करें",
  "dash.day": "दिन",
  "dash.daysCompleted": "दिन पूर्ण",

  "interview.title": "वॉइस मॉक इंटरव्यू",
  "interview.subtitle": "टर्न-आधारित · एआई सीनियर इंजीनियरिंग मैनेजर",
  "interview.back": "वापस",
  "interview.interviewer": "साक्षात्कारकर्ता",
  "interview.question": "प्रश्न",
  "interview.thinking": "साक्षात्कारकर्ता सोच रहा है",
  "interview.record": "उत्तर रिकॉर्ड करें",
  "interview.stop": "रोकें और भेजें",
  "interview.recordHint": "माइक पर क्लिक करें और जोर से उत्तर दें। साक्षात्कारकर्ता आपका उत्तर ट्रांसक्राइब करेगा।",
  "interview.replay": "ऑडियो रिप्ले करें",
  "interview.typeInstead": "उत्तर टाइप करें",
  "interview.typeAnswer": "अपना उत्तर टाइप करें",
  "interview.cancel": "रद्द करें",
  "interview.submit": "उत्तर भेजें",
  "interview.transcript": "लाइव ट्रांसक्रिप्ट",
  "interview.noAnalysis": "कोई विश्लेषण नहीं मिला",
  "interview.noAnalysisDesc": "पहले विश्लेषण चलाएं। साक्षात्कारकर्ता को गायब स्किल्स की सूची चाहिए।",
  "interview.backToDashboard": "डैशबोर्ड पर वापस",
  "interview.recording": "रिकॉर्डिंग",
  "interview.processing": "प्रोसेसिंग…",
  "interview.questionOf": "में से",
  "interview.answersSubmitted": "उत्तर भेजे गए",
  "interview.buildingReport": "आपका स्कोरकार्ड बन रहा है…",
  "interview.buildingReportDesc": "आपके उत्तरों का विश्लेषण और फीडबैक बन रहा है।",
  "interview.listening": "सुन रहा है",
  "interview.starting": "शुरू हो रहा है…",
  "interview.speaking": "बोल रहा है",
  "interview.browserNotSupported": "आपका ब्राउज़र ऑडियो रिकॉर्डिंग समर्थित नहीं करता। टेक्स्ट विकल्प उपयोग करें।",

  "report.title": "इंटरव्यू स्कोरकार्ड",
  "report.back": "वापस",
  "report.overallVerdict": "समग्र निर्णय",
  "report.technicalDepth": "तकनीकी गहराई",
  "report.communication": "संचार",
  "report.strengths": "शक्तियां",
  "report.areasToImprove": "सुधार के क्षेत्र",
  "report.transcript": "इंटरव्यू ट्रांसक्रिप्ट",
  "report.noReport": "कोई रिपोर्ट उपलब्ध नहीं",
  "report.startNew": "नया इंटरव्यू शुरू करें",
  "report.analyzeNew": "नया रिज्यूमे विश्लेषण करें",
  "report.excellent": "उत्कृष्ट",
  "report.solid": "ठोस",
  "report.needsImprovement": "सुधार की आवश्यकता",

  "footer.source": "स्रोत",
  "footer.builtWith": "के साथ बनाया गया",
};

const zh: Dictionary = {
  "nav.analyze": "分析",
  "nav.dashboard": "仪表板",
  "nav.interview": "面试",
  "nav.report": "报告",
  "nav.history": "历史",
  "nav.videoInterview": "视频面试",
  "nav.brand": "The Employability Engine",
  "nav.tagline": "AI 驱动的职业助手",
  "nav.login": "登录",
  "nav.signup": "注册",
  "nav.logout": "退出",
  "nav.goDashboard": "前往仪表板",

  "theme.switchToDark": "切换到深色模式",
  "theme.switchToLight": "切换到浅色模式",

  "language.label": "语言",

  "hero.badge": "AI 职业助手",
  "hero.badgeNew": "新",
  "hero.titlePre": "就业能力",
  "hero.titleHighlight": "引擎",
  "hero.subtitle": "AI 驱动的简历分析、7 天学习路线图，以及与资深工程经理的语音模拟面试 — 一站式。",
  "hero.ctaStart": "开始分析",
  "hero.ctaGetStarted": "开始使用",
  "hero.watchHow": "查看工作原理",
  "hero.statMatchScore": "匹配分数",
  "hero.statRoadmap": "7 天路线图",
  "hero.statVoice": "语音面试",
  "hero.scrollHint": "滚动以分析",

  "features.label": "功能",
  "features.titlePre": "三个引擎，一个",
  "features.titleHighlight": "职业助手",
  "features.subtitle": "从职位发布到面试准备所需的一切，每一步都有 AI 支持。",
  "features.resumeTitle": "AI 简历解析",
  "features.resumeDesc": "对您的简历与职位描述进行结构化分析。",
  "features.roadmapTitle": "7 天学习路线图",
  "features.roadmapDesc": "填补关键技能差距的每日计划。",
  "features.interviewTitle": "语音模拟面试",
  "features.interviewDesc": "与 AI 资深工程经理练习，探测您的薄弱环节。",
  "features.learnMore": "了解更多",

  "form.heading": "即时分析您的匹配度",
  "form.subheading": "粘贴职位描述和简历 — 几秒钟内获得匹配分数、技能差距和 7 天计划。",
  "form.jdTabPaste": "粘贴 JD",
  "form.jdTabUrl": "JD 链接",
  "form.jdPlaceholder": "在此粘贴完整的职位描述 — 职责、所需技能、资格…",
  "form.jdUrlLabel": "职位描述链接",
  "form.resumeTitle": "您的简历",
  "form.resumeDropzone": "上传简历文件",
  "form.resumeDropzoneHint": "拖放或点击浏览 — .txt、.md、.pdf",
  "form.resumeOrPaste": "或直接粘贴您的简历文本",
  "form.resumePastePlaceholder": "在此粘贴您的简历内容 — 经验、技能、教育…",
  "form.analyze": "分析并生成路线图",
  "form.analyzing": "分析中…",
  "form.fileRemoved": "文件已移除",
  "form.errors.noJd": "请输入职位描述。",
  "form.errors.noResume": "请输入您的简历文本。",
  "form.errors.shortResume": "简历文本太短，无法进行有意义的分析。",
  "form.errors.shortJd": "职位描述太短。",
  "form.toasts.analyzing": "正在分析您的简历…",
  "form.toasts.success": "分析完成！",
  "form.toasts.error": "分析失败。请重试。",

  "auth.visualHeadline": "用清晰获得下一份工作",
  "auth.visualBody": "针对任何职位描述分析您的简历，获取个性化 7 天学习路线图，并通过 AI 工程经理的模拟面试。",
  "auth.featureSecure": "安全且私密",
  "auth.featureSecureDesc": "您的数据归您所有。",
  "auth.featureAi": "AI 驱动分析",
  "auth.featureAiDesc": "深入的简历 vs JD 洞察。",
  "auth.featureTrack": "跟踪您的进度",
  "auth.featureTrackDesc": "7 天路线图和报告。",
  "auth.quote": "三周内从无人回复到获得两个录用通知。模拟面试感觉很真实，路线图也很准确。",
  "auth.quoteAuthor": "Maya R.",
  "auth.quoteRole": "资深后端工程师",

  "login.title": "欢迎回来",
  "login.subtitle": "登录以继续您的职业旅程。",
  "login.email": "邮箱",
  "login.password": "密码",
  "login.remember": "记住我",
  "login.forgot": "忘记密码？",
  "login.submit": "登录",
  "login.submitting": "登录中…",
  "login.demo": "使用演示账户继续",
  "login.noAccount": "还没有账户？",
  "login.signupLink": "注册",
  "login.errors.emailRequired": "请输入您的邮箱。",
  "login.errors.passwordRequired": "请输入您的密码。",

  "signup.title": "创建您的账户",
  "signup.subtitle": "开启您的面试准备之旅。",
  "signup.name": "全名",
  "signup.email": "邮箱",
  "signup.password": "密码",
  "signup.terms": "我同意条款和隐私政策",
  "signup.submit": "创建账户",
  "signup.submitting": "创建中…",
  "signup.demo": "使用演示账户继续",
  "signup.haveAccount": "已经有账户？",
  "signup.loginLink": "登录",
  "signup.passwordStrength.weak": "弱密码",
  "signup.passwordStrength.medium": "中等强度",
  "signup.passwordStrength.strong": "强密码",
  "signup.passwordStrength.tooShort": "太短（至少 6 个字符）",

  "dash.noAnalysisTitle": "暂无分析",
  "dash.noAnalysisDesc": "运行简历 vs JD 分析以查看您的个性化仪表板。",
  "dash.backHome": "返回首页",
  "dash.matchAnalysis": "匹配分析",
  "dash.skillGaps": "技能差距",
  "dash.experienceGaps": "经验差距",
  "dash.roadmap": "7 天学习路线图",
  "dash.startInterview": "开始语音面试",
  "dash.back": "返回",
  "dash.filterAll": "全部",
  "dash.noSkillsAtSeverity": "此严重性下无技能。",
  "dash.noGaps": "没有主要经验差距 — 太棒了！",
  "dash.highSeverityCount": "高严重性差距",
  "dash.noHighGaps": "无高严重性差距 — 您状态良好。",
  "dash.keyConcepts": "关键概念",
  "dash.practicalTask": "实践任务",
  "dash.markComplete": "标记为完成",
  "dash.markIncomplete": "标记为未完成",
  "dash.day": "第",
  "dash.daysCompleted": "天已完成",

  "interview.title": "语音模拟面试",
  "interview.subtitle": "轮次制 · AI 资深工程经理",
  "interview.back": "返回",
  "interview.interviewer": "面试官",
  "interview.question": "问题",
  "interview.thinking": "面试官思考中",
  "interview.record": "录制回答",
  "interview.stop": "停止并提交",
  "interview.recordHint": "点击麦克风并大声回答。面试官将转录您的回答。",
  "interview.replay": "重播音频",
  "interview.typeInstead": "改为输入回答",
  "interview.typeAnswer": "输入您的回答",
  "interview.cancel": "取消",
  "interview.submit": "提交回答",
  "interview.transcript": "实时转录",
  "interview.noAnalysis": "未找到分析",
  "interview.noAnalysisDesc": "请先运行分析。面试官需要缺失技能列表。",
  "interview.backToDashboard": "返回仪表板",
  "interview.recording": "录制中",
  "interview.processing": "处理中…",
  "interview.questionOf": "/",
  "interview.answersSubmitted": "个回答已提交",
  "interview.buildingReport": "正在生成您的评分卡…",
  "interview.buildingReportDesc": "分析您的回答并生成面试反馈。",
  "interview.listening": "聆听中",
  "interview.starting": "启动中…",
  "interview.speaking": "说话中",
  "interview.browserNotSupported": "您的浏览器不支持音频录制。请使用文本输入选项。",

  "report.title": "面试评分卡",
  "report.back": "返回",
  "report.overallVerdict": "总体评判",
  "report.technicalDepth": "技术深度",
  "report.communication": "沟通能力",
  "report.strengths": "优势",
  "report.areasToImprove": "改进方向",
  "report.transcript": "面试转录",
  "report.noReport": "无可用报告",
  "report.startNew": "开始新面试",
  "report.analyzeNew": "分析新简历",
  "report.excellent": "优秀",
  "report.solid": "扎实",
  "report.needsImprovement": "需要改进",

  "footer.source": "源码",
  "footer.builtWith": "用",
};

export const dictionaries: Record<Language, Dictionary> = {
  en,
  es,
  fr,
  de,
  hi,
  zh,
};
