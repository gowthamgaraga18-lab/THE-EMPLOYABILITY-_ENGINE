// ============================================================================
// Global app state (Zustand)
// ============================================================================

import { create } from "zustand";
import type {
  AnalysisResult,
  AppView,
  InterviewMessage,
  InterviewReport,
  JobTrail,
  TrailStatus,
  User,
} from "./types";
import type { Language } from "./i18n";

interface AppState {
  // Navigation
  view: AppView;
  setView: (v: AppView) => void;

  // Language
  language: Language;
  setLanguage: (l: Language) => void;

  // Auth
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  signup: (
    name: string,
    email: string,
    password: string,
  ) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;

  // Analysis
  analysis: AnalysisResult | null;
  isAnalyzing: boolean;
  setAnalysis: (a: AnalysisResult | null) => void;
  setIsAnalyzing: (b: boolean) => void;

  // Job Trails
  trails: JobTrail[];
  currentTrailId: string | null;
  loadTrails: () => Promise<void>;
  saveTrailAfterAnalysis: (a: AnalysisResult) => Promise<void>;
  updateTrailStatus: (status: TrailStatus, verdict?: string, mode?: "voice" | "video") => Promise<void>;

  // Roadmap progress (local, persisted in memory only)
  completedDays: Record<number, boolean>;
  toggleDay: (day: number) => void;

  // Interview
  interviewMessages: InterviewMessage[];
  currentQuestion: string;
  isInterviewActive: boolean;
  isInterviewThinking: boolean;
  interviewTargetRole: string;
  interviewMode: "voice" | "video";
  setInterview: (p: {
    messages?: InterviewMessage[];
    currentQuestion?: string;
    isActive?: boolean;
    isThinking?: boolean;
    targetRole?: string;
    mode?: "voice" | "video";
  }) => void;
  addInterviewMessage: (m: InterviewMessage) => void;
  resetInterview: () => void;

  // Report
  report: InterviewReport | null;
  isBuildingReport: boolean;
  setReport: (r: InterviewReport | null) => void;
  setIsBuildingReport: (b: boolean) => void;

  // Global error
  error: string | null;
  setError: (e: string | null) => void;
}

// Simple in-memory "database" of registered users (mock auth for MVP).
// REMOVED — auth is now backed by Prisma + SQLite via /api/auth/* routes.

function loadSession(): { user: User | null } {
  if (typeof window === "undefined") return { user: null };
  try {
    const raw = window.localStorage.getItem("ee_session");
    if (!raw) return { user: null };
    const u = JSON.parse(raw) as User;
    return { user: u };
  } catch {
    return { user: null };
  }
}

function saveSession(user: User | null) {
  if (typeof window === "undefined") return;
  if (user) {
    window.localStorage.setItem("ee_session", JSON.stringify(user));
  } else {
    window.localStorage.removeItem("ee_session");
  }
}

function loadLanguage(): Language {
  if (typeof window === "undefined") return "en";
  try {
    const stored = window.localStorage.getItem("ee_lang");
    if (stored === "en" || stored === "es" || stored === "fr" || stored === "de" || stored === "hi" || stored === "zh") {
      return stored;
    }
  } catch {
    /* ignore */
  }
  return "en";
}

function saveLanguage(lang: Language) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("ee_lang", lang);
  } catch {
    /* ignore */
  }
}

const initial = loadSession();
const initialLang = loadLanguage();

export const useAppStore = create<AppState>((set, get) => ({
  view: initial.user ? "landing" : "login",
  setView: (v) => set({ view: v }),

  // ----- Language -----
  language: initialLang,
  setLanguage: (l) => {
    saveLanguage(l);
    set({ language: l });
  },

  // ----- Auth -----
  user: initial.user,
  isAuthenticated: !!initial.user,

  login: async (email, password) => {
    const key = email.trim().toLowerCase();
    if (!key || !password) return { ok: false, error: "Email and password are required." };
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: key, password, allowDemo: true }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { ok: false, error: data.error || "Failed to log in." };
      }
      const u: User = {
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        createdAt: data.user.createdAt,
      };
      saveSession(u);
      set({ user: u, isAuthenticated: true, view: "landing" });
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error. Please try again." };
    }
  },

  signup: async (name, email, password) => {
    const key = email.trim().toLowerCase();
    const trimmedName = name.trim();
    if (!trimmedName) return { ok: false, error: "Please enter your name." };
    if (!key || !/.+@.+\..+/.test(key))
      return { ok: false, error: "Please enter a valid email address." };
    if (password.length < 6)
      return { ok: false, error: "Password must be at least 6 characters." };

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: trimmedName, email: key, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { ok: false, error: data.error || "Failed to create account." };
      }
      const u: User = {
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        createdAt: data.user.createdAt,
      };
      saveSession(u);
      set({ user: u, isAuthenticated: true, view: "landing" });
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error. Please try again." };
    }
  },

  logout: () => {
    saveSession(null);
    set({
      user: null,
      isAuthenticated: false,
      view: "login",
      analysis: null,
      interviewMessages: [],
      currentQuestion: "",
      report: null,
      completedDays: {},
      trails: [],
      currentTrailId: null,
    });
  },

  // ----- Analysis -----
  analysis: null,
  isAnalyzing: false,
  setAnalysis: (a) => set({ analysis: a }),
  setIsAnalyzing: (b) => set({ isAnalyzing: b }),

  // ----- Job Trails -----
  trails: [],
  currentTrailId: null,
  loadTrails: async () => {
    const u = useAppStore.getState().user;
    if (!u) return;
    try {
      const res = await fetch("/api/trails", { headers: { "x-user-id": u.id } });
      const data = await res.json();
      if (data.success) set({ trails: data.trails });
    } catch {
      /* ignore */
    }
  },
  saveTrailAfterAnalysis: async (a) => {
    const u = useAppStore.getState().user;
    if (!u) return;
    try {
      const res = await fetch("/api/trails", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-user-id": u.id },
        body: JSON.stringify({
          targetRole: a.target_role,
          matchScore: a.match_score,
        }),
      });
      const data = await res.json();
      if (data.success) {
        set({ currentTrailId: data.trail.id });
        // Refresh the trails list.
        await useAppStore.getState().loadTrails();
      }
    } catch {
      /* ignore */
    }
  },
  updateTrailStatus: async (status, verdict, mode) => {
    const u = useAppStore.getState().user;
    const tid = useAppStore.getState().currentTrailId;
    if (!u || !tid) return;
    try {
      await fetch(`/api/trails/${tid}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "x-user-id": u.id },
        body: JSON.stringify({ status, verdict, interviewMode: mode }),
      });
      await useAppStore.getState().loadTrails();
    } catch {
      /* ignore */
    }
  },

  // ----- Roadmap -----
  completedDays: {},
  toggleDay: (day) =>
    set((s) => ({
      completedDays: { ...s.completedDays, [day]: !s.completedDays[day] },
    })),

  // ----- Interview -----
  interviewMessages: [],
  currentQuestion: "",
  isInterviewActive: false,
  isInterviewThinking: false,
  interviewTargetRole: "",
  interviewMode: "voice",
  setInterview: (p) =>
    set((s) => ({
      interviewMessages: p.messages ?? s.interviewMessages,
      currentQuestion: p.currentQuestion ?? s.currentQuestion,
      isInterviewActive: p.isActive ?? s.isInterviewActive,
      isInterviewThinking: p.isThinking ?? s.isInterviewThinking,
      interviewTargetRole: p.targetRole ?? s.interviewTargetRole,
      interviewMode: p.mode ?? s.interviewMode,
    })),
  addInterviewMessage: (m) =>
    set((s) => ({ interviewMessages: [...s.interviewMessages, m] })),
  resetInterview: () =>
    set({
      interviewMessages: [],
      currentQuestion: "",
      isInterviewActive: false,
      isInterviewThinking: false,
      report: null,
    }),

  // ----- Report -----
  report: null,
  isBuildingReport: false,
  setReport: (r) => set({ report: r }),
  setIsBuildingReport: (b) => set({ isBuildingReport: b }),

  // ----- Error -----
  error: null,
  setError: (e) => set({ error: e }),
}));

// Dev-only: expose the store on window for debugging / E2E testing.
if (typeof window !== "undefined" && process.env.NODE_ENV !== "production") {
  (window as unknown as { __appStore?: typeof useAppStore }).__appStore =
    useAppStore;
}
