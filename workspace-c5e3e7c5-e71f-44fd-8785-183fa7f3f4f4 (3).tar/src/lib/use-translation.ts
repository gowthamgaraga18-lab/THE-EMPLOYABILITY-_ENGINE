"use client";

// ============================================================================
// useTranslation — hook to access translations + current language.
// ----------------------------------------------------------------------------// Reads the language from the app store (which persists to localStorage) and
// returns a `t(key)` translator + the current language info.
// ============================================================================

import { useAppStore } from "@/lib/store";
import { dictionaries, LANGUAGES, type Language, type TranslationKey } from "@/lib/i18n";

export function useTranslation() {
  const language = useAppStore((s) => s.language);
  const setLanguage = useAppStore((s) => s.setLanguage);

  const dict = dictionaries[language] ?? dictionaries.en;

  function t(key: TranslationKey): string {
    return dict[key] ?? dictionaries.en[key] ?? key;
  }

  return {
    language,
    setLanguage,
    t,
    languages: LANGUAGES,
    currentInfo: LANGUAGES.find((l) => l.code === language) ?? LANGUAGES[0],
  };
}
