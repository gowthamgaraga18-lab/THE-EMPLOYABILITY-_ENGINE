// ============================================================================
// Audio utilities — client-side WebM/Opus → WAV conversion
// ----------------------------------------------------------------------------
// The ASR service reliably transcribes WAV but NOT WebM/Opus (which is what
// MediaRecorder produces by default in Chrome/Firefox). These helpers decode
// the recorded blob via AudioContext and re-encode as 16-bit PCM WAV at 16kHz
// mono — ideal for speech recognition.
// ============================================================================

/**
 * Convert any audio Blob (webm/opus, mp4, ogg) to a 16-bit PCM WAV Blob at
 * the given sample rate (mono). Returns a {wav, duration} pair.
 */
export async function audioBlobToWav(
  blob: Blob,
  targetSampleRate = 16000,
): Promise<{ wav: Blob; duration: number }> {
  const arrayBuffer = await blob.arrayBuffer();

  const w = window as unknown as {
    AudioContext?: typeof AudioContext;
    webkitAudioContext?: typeof AudioContext;
  };
  const AudioCtx = w.AudioContext || w.webkitAudioContext;
  if (!AudioCtx) {
    throw new Error("Web Audio API is not supported in this browser.");
  }

  const ctx = new AudioCtx();
  let audioBuffer: AudioBuffer;
  try {
    audioBuffer = await ctx.decodeAudioData(arrayBuffer);
  } finally {
    // Close the context as soon as we have decoded data.
    ctx.close().catch(() => {});
  }

  const duration = audioBuffer.duration;
  const wav = encodeAudioBufferToWav(audioBuffer, targetSampleRate);
  return { wav, duration };
}

/**
 * Encode an AudioBuffer to a 16-bit PCM WAV Blob at the target sample rate
 * (mono, down-mixed if stereo).
 */
function encodeAudioBufferToWav(
  buffer: AudioBuffer,
  targetSampleRate: number,
): Blob {
  const numChannels = 1; // force mono
  const sourceSampleRate = buffer.sampleRate;
  const samples = buffer.getChannelData(0); // first channel

  // Resample to targetSampleRate using linear interpolation.
  const resampled = resampleLinear(
    samples,
    sourceSampleRate,
    targetSampleRate,
  );

  const bytesPerSample = 2; // 16-bit
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = targetSampleRate * blockAlign;
  const dataSize = resampled.length * bytesPerSample;
  const bufferSize = 44 + dataSize;

  const ab = new ArrayBuffer(bufferSize);
  const view = new DataView(ab);

  // RIFF header
  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, "WAVE");

  // fmt sub-chunk
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true); // sub-chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, numChannels, true);
  view.setUint32(24, targetSampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true); // bits per sample

  // data sub-chunk
  writeString(view, 36, "data");
  view.setUint32(40, dataSize, true);

  // PCM samples (clamp + convert to int16)
  let offset = 44;
  for (let i = 0; i < resampled.length; i++) {
    const s = Math.max(-1, Math.min(1, resampled[i]));
    const int16 = s < 0 ? s * 0x8000 : s * 0x7fff;
    view.setInt16(offset, int16, true);
    offset += 2;
  }

  return new Blob([ab], { type: "audio/wav" });
}

function resampleLinear(
  samples: Float32Array,
  fromRate: number,
  toRate: number,
): Float32Array {
  if (fromRate === toRate) return samples;
  const ratio = toRate / fromRate;
  const newLength = Math.round(samples.length * ratio);
  const result = new Float32Array(newLength);
  for (let i = 0; i < newLength; i++) {
    const srcIndex = i / ratio;
    const i0 = Math.floor(srcIndex);
    const i1 = Math.min(i0 + 1, samples.length - 1);
    const frac = srcIndex - i0;
    result[i] = samples[i0] * (1 - frac) + samples[i1] * frac;
  }
  return result;
}

function writeString(view: DataView, offset: number, str: string) {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
}

/**
 * Compute a simple loudness measure (0–100) for a frame of time-domain data,
 * used by the live audio level meter.
 */
export function computeLevel(dataArray: Uint8Array): number {
  let sum = 0;
  for (let i = 0; i < dataArray.length; i++) {
    const v = (dataArray[i] - 128) / 128; // -1..1
    sum += v * v;
  }
  const rms = Math.sqrt(sum / dataArray.length); // 0..1
  // Map to 0–100 with a slight curve so quiet speech is still visible.
  return Math.min(100, Math.round(rms * 180));
}
