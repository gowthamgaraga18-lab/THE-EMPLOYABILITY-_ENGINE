// ============================================================================
// AI Service — server-side wrapper around z-ai-web-dev-sdk
// Provides: structured analysis, interview conversation, TTS, ASR, reports
// ----------------------------------------------------------------------------
// IMPORTANT: This module MUST only be imported from server-side code
// (API routes / server components). Never import in client components.
// ============================================================================

import ZAI from "z-ai-web-dev-sdk";
import type {
  AnalysisResult,
  InterviewMessage,
  InterviewReport,
  MissingSkill,
  Verdict,
} from "./types";

// ---------------------------------------------------------------------------
// Singleton SDK instance
// ---------------------------------------------------------------------------

let _zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!_zai) {
    _zai = await ZAI.create();
  }
  return _zai;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Extract the first JSON object/array from an LLM text response. */
function extractJson<T = unknown>(text: string): T {
  // Try direct parse first
  try {
    return JSON.parse(text) as T;
  } catch {
    /* fall through */
  }

  // Strip markdown code fences
  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch) {
    try {
      return JSON.parse(fenceMatch[1].trim()) as T;
    } catch {
      /* fall through */
    }
  }

  // Find the first { ... } or [ ... ] block
  const objMatch = text.match(/\{[\s\S]*\}/);
  const arrMatch = text.match(/\[[\s\S]*\]/);
  const candidate = objMatch ?? arrMatch;
  if (candidate) {
    try {
      return JSON.parse(candidate[0]) as T;
    } catch {
      /* fall through */
    }
  }

  throw new Error("Could not extract valid JSON from model response.");
}

/** Robust completion call that asks for JSON and parses it. */
async function jsonCompletion<T>(
  systemPrompt: string,
  userPrompt: string,
): Promise<T> {
  const zai = await getZAI();

  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    thinking: { type: "disabled" },
  });

  const content = completion.choices[0]?.message?.content ?? "";
  return extractJson<T>(content);
}

// ---------------------------------------------------------------------------
// Module 1 — Resume & JD Analysis
// ---------------------------------------------------------------------------

interface AnalysisModelOutput {
  match_score: number;
  target_role: string;
  missing_skills: { skill: string; category: string; severity: Severity }[];
  experience_gaps: string[];
  roadmap: {
    day: number;
    topic: string;
    key_concepts: string[];
    practical_task: string;
  }[];
}

type Severity = "High" | "Medium" | "Low";

const ANALYSIS_SYSTEM = `You are "The Employability Engine", an expert technical recruiter and career coach.

You receive a candidate's RESUME and a target JOB DESCRIPTION.

Your job:
1. Compute an overall match_score (0-100) reflecting how well the resume satisfies the JD.
2. Identify missing_skills — concrete, learnable skills present in the JD but absent or weak in the resume. Each must have a category (e.g. "Backend", "Frontend", "Cloud", "Systems", "Data", "Soft Skills") and a severity: "High" (blocking / core requirement), "Medium" (important), "Low" (nice-to-have).
3. Identify experience_gaps — missing project, scale, or domain achievements the candidate should have to be competitive (e.g. "No experience designing distributed systems at scale").
4. Build a focused 7-day learning roadmap that closes the most critical gaps. Each day has a topic, 3-5 key_concepts, and one concrete practical_task.

Return STRICT JSON only — no prose, no markdown fences. Schema:
{
  "match_score": <integer 0-100>,
  "target_role": "<short role title>",
  "missing_skills": [{"skill":"","category":"","severity":"High|Medium|Low"}],
  "experience_gaps": ["<string>", ...],
  "roadmap": [{"day":1,"topic":"","key_concepts":["",""],"practical_task":""}, ... 7 entries]
}`;

export async function analyzeResumeAndJd(
  resumeText: string,
  jdText: string,
): Promise<AnalysisResult> {
  const userPrompt = `JOB DESCRIPTION:
"""
${jdText.slice(0, 8000)}
"""

RESUME:
"""
${resumeText.slice(0, 8000)}
"""

Analyze and return the JSON object.`;

  const model = await jsonCompletion<AnalysisModelOutput>(
    ANALYSIS_SYSTEM,
    userPrompt,
  );

  // Normalise / clamp values so the UI is always safe.
  const matchScore = Math.max(
    0,
    Math.min(100, Math.round(Number(model.match_score) || 0)),
  );

  const missingSkills: MissingSkill[] = (model.missing_skills ?? [])
    .filter((s) => s && s.skill)
    .slice(0, 20)
    .map((s) => ({
      skill: String(s.skill).trim(),
      category: String(s.category ?? "General").trim(),
      severity: normalizeSeverity(s.severity),
    }));

  const experienceGaps: string[] = (model.experience_gaps ?? [])
    .map((g) => String(g).trim())
    .filter(Boolean)
    .slice(0, 10);

  const roadmap = (model.roadmap ?? [])
    .slice(0, 7)
    .map((d, i) => ({
      day: Number(d.day) || i + 1,
      topic: String(d.topic ?? "").trim() || `Day ${i + 1}`,
      key_concepts: Array.isArray(d.key_concepts)
        ? d.key_concepts.map(String).slice(0, 6)
        : [],
      practical_task: String(d.practical_task ?? "").trim(),
      completed: false,
    }));

  // Ensure exactly 7 days
  while (roadmap.length < 7) {
    const idx = roadmap.length + 1;
    roadmap.push({
      day: idx,
      topic: `Day ${idx} — Continued Practice`,
      key_concepts: [],
      practical_task: "Review previous concepts and build a small project.",
      completed: false,
    });
  }

  return {
    match_score: matchScore,
    missing_skills: missingSkills,
    experience_gaps: experienceGaps,
    roadmap,
    resume_text: resumeText.slice(0, 6000),
    jd_text: jdText.slice(0, 6000),
    target_role: String(model.target_role ?? "the target role").trim(),
  };
}

function normalizeSeverity(s: unknown): Severity {
  const v = String(s ?? "")
    .trim()
    .toLowerCase();
  if (v.startsWith("high")) return "High";
  if (v.startsWith("med")) return "Medium";
  if (v.startsWith("low")) return "Low";
  return "Medium";
}

// ---------------------------------------------------------------------------
// Module 3 — Voice Mock Interview (turn-based)
// ---------------------------------------------------------------------------

interface InterviewerResponse {
  question: string;
  isFinal: boolean;
}

/**
 * Generate the interviewer's next question given the transcript so far and
 * the candidate's identified skill gaps.
 */
export async function nextInterviewerTurn(opts: {
  targetRole: string;
  missingSkills: MissingSkill[];
  transcript: InterviewMessage[];
  questionsAsked: number;
  candidateAnswer?: string;
}): Promise<InterviewerResponse> {
  const { targetRole, missingSkills, transcript, questionsAsked } = opts;

  const systemPrompt = `You are a Senior Engineering Manager conducting a technical mock interview for the role of "${targetRole}".

Persona & rules:
- Speak as a real Senior EM: calm, sharp, professional, encouraging but rigorous.
- Focus questions STRICTLY on the candidate's identified skill gaps so the interview is high-signal.
- Ask exactly ONE question at a time. Never list multiple questions.
- Keep each question concise (1-3 sentences).
- After the candidate answers, briefly (one short sentence) acknowledge whether it was strong or weak, then move to the next gap topic.
- Dynamically follow up if an answer is shallow, or switch topics if it is solid.
- Do not reveal any evaluation rubric. Do not use bullet points. Speak naturally.

Identified gaps to probe (in priority order):
${missingSkills.map((s) => `- ${s.skill} (${s.severity} priority — ${s.category})`).join("\n")}

The interview should last ~6-8 questions. When you believe enough signal has been gathered (around question 7 or if the candidate is clearly unprepared on most gaps), set isFinal=true and ask a closing remark instead of a new question.

Return STRICT JSON only:
{"question":"<your single question or closing remark>","isFinal":<boolean>}`;

  const transcriptText = transcript
    .map(
      (m) =>
        `${m.role === "interviewer" ? "Interviewer" : "Candidate"}: ${m.content}`,
    )
    .join("\n");

  const userPrompt = `Conversation so far (${questionsAsked} questions asked):
${transcriptText || "(conversation just started)"}

${opts.candidateAnswer ? `Candidate's latest answer: ${opts.candidateAnswer}` : ""}

Generate your next turn.`;

  const model = await jsonCompletion<InterviewerResponse>(
    systemPrompt,
    userPrompt,
  );

  const question = String(model.question ?? "").trim();
  const isFinal = Boolean(model.isFinal) || questionsAsked >= 8;

  return {
    question: question || "Can you walk me through a recent project you're proud of?",
    isFinal,
  };
}

// ---------------------------------------------------------------------------
// TTS — generate interviewer voice audio (WAV buffer)
// ---------------------------------------------------------------------------

export async function synthesizeSpeech(text: string): Promise<Buffer> {
  const zai = await getZAI();
  // Clamp text length per API constraint (1024 chars).
  const safeText = text.slice(0, 1000);

  const response = await zai.audio.tts.create({
    input: safeText,
    voice: "xiaochen", // 沉稳专业 — fits a Senior EM persona
    speed: 1.0,
    response_format: "wav",
    stream: false,
  });

  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(new Uint8Array(arrayBuffer));
}

// ---------------------------------------------------------------------------
// ASR — transcribe candidate's recorded answer
// ---------------------------------------------------------------------------

export async function transcribeAudio(base64Audio: string): Promise<string> {
  const zai = await getZAI();
  const response = await zai.audio.asr.create({
    file_base64: base64Audio,
  });
  return String(response.text ?? "").trim();
}

// ---------------------------------------------------------------------------
// Module 4 — Interview Evaluation & Scorecard
// ---------------------------------------------------------------------------

interface ReportModelOutput {
  technical_depth_score: number;
  communication_score: number;
  overall_verdict: Verdict;
  key_takeaways: { type: "strength" | "weakness"; text: string }[];
  summary: string;
}

const REPORT_SYSTEM = `You are the evaluation panel for a technical mock interview.

Given the full transcript, the target role, and the candidate's known skill gaps, produce a fair, specific scorecard.

Scoring:
- technical_depth_score: 1-5 (1 = could not answer core questions, 5 = deep, accurate, nuanced answers).
- communication_score: 1-5 (1 = unclear / rambling, 5 = crisp, structured, confident).
- overall_verdict: one of "Strong Hire", "Hire", "Needs Work".
- key_takeaways: 3-6 specific items. Each has type "strength" or "weakness" and a concrete sentence referencing what the candidate said (or failed to say).
- summary: 2-4 sentence executive summary.

Return STRICT JSON only:
{
  "technical_depth_score": <1-5>,
  "communication_score": <1-5>,
  "overall_verdict": "Strong Hire"|"Hire"|"Needs Work",
  "key_takeaways": [{"type":"strength"|"weakness","text":""}],
  "summary": ""
}`;

export async function buildInterviewReport(opts: {
  targetRole: string;
  missingSkills: MissingSkill[];
  transcript: InterviewMessage[];
}): Promise<InterviewReport> {
  const transcriptText = opts.transcript
    .map(
      (m) =>
        `${m.role === "interviewer" ? "Interviewer" : "Candidate"}: ${m.content}`,
    )
    .join("\n");

  const userPrompt = `Target role: ${opts.targetRole}

Known skill gaps being probed:
${opts.missingSkills.map((s) => `- ${s.skill}`).join("\n") || "(none provided)"}

Full interview transcript:
${transcriptText || "(empty transcript)"}

Produce the scorecard JSON.`;

  const model = await jsonCompletion<ReportModelOutput>(
    REPORT_SYSTEM,
    userPrompt,
  );

  const verdicts: Verdict[] = ["Strong Hire", "Hire", "Needs Work"];
  const verdict = verdicts.includes(model.overall_verdict)
    ? model.overall_verdict
    : "Needs Work";

  return {
    technical_depth_score: clamp15(Number(model.technical_depth_score)),
    communication_score: clamp15(Number(model.communication_score)),
    overall_verdict: verdict,
    key_takeaways: (model.key_takeaways ?? [])
      .filter((k) => k && k.text)
      .slice(0, 8)
      .map((k) => ({
        type: k.type === "strength" ? "strength" : "weakness",
        text: String(k.text).trim(),
      })),
    summary: String(model.summary ?? "").trim(),
    transcript: opts.transcript,
  };
}

function clamp15(n: number): number {
  const v = Math.round(n);
  if (Number.isNaN(v)) return 1;
  return Math.max(1, Math.min(5, v));
}
