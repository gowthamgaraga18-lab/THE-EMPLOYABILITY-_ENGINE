// ============================================================================
// The Employability Engine — Shared Type Definitions
// ============================================================================

export type Severity = "High" | "Medium" | "Low";

export interface MissingSkill {
  skill: string;
  category: string;
  severity: Severity;
}

export interface RoadmapDay {
  day: number; // 1-7
  topic: string;
  key_concepts: string[];
  practical_task: string;
  completed?: boolean;
}

export interface AnalysisResult {
  match_score: number; // 0-100
  missing_skills: MissingSkill[];
  experience_gaps: string[];
  roadmap: RoadmapDay[];
  resume_text: string;
  jd_text: string;
  target_role: string;
}

// ---------------------------------------------------------------------------
// Interview
// ---------------------------------------------------------------------------

export type InterviewMessageRole = "interviewer" | "candidate";

export interface InterviewMessage {
  role: InterviewMessageRole;
  content: string;
  timestamp: number;
}

export interface InterviewSession {
  messages: InterviewMessage[];
  currentQuestion: string;
  targetRole: string;
  missingSkills: MissingSkill[];
  startedAt: number;
  questionsAsked: number;
}

// ---------------------------------------------------------------------------
// Report
// ---------------------------------------------------------------------------

export type Verdict = "Strong Hire" | "Hire" | "Needs Work";

export interface InterviewReport {
  technical_depth_score: number; // 1-5
  communication_score: number; // 1-5
  overall_verdict: Verdict;
  key_takeaways: { type: "strength" | "weakness"; text: string }[];
  summary: string;
  transcript: InterviewMessage[];
}

// ---------------------------------------------------------------------------
// App navigation
// ---------------------------------------------------------------------------

export type AppView =
  | "landing"
  | "dashboard"
  | "interview"
  | "video-interview"
  | "report"
  | "history"
  | "login"
  | "signup";

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

export interface User {
  id: string;
  name: string;
  email: string;
  createdAt: number;
}

// ---------------------------------------------------------------------------
// Job Trails — history of analyzed jobs + interview outcomes
// ---------------------------------------------------------------------------

export type TrailStatus = "in_progress" | "cracked" | "failed";

export interface JobTrail {
  id: string;
  userId: string;
  analysisId: string | null;
  targetRole: string;
  matchScore: number;
  status: TrailStatus;
  verdict: Verdict | null;
  interviewMode: "voice" | "video" | null;
  createdAt: number;
  updatedAt: number;
}
