"use client";

// ============================================================================
// useTheme — lightweight dark/light theme hook (no next-themes dependency).
// ----------------------------------------------------------------------------
// Persists choice in localStorage, defaults to the OS preference, and toggles
// the `dark` class on <html> (which the Tailwind `dark:` variant + the
// .dark CSS variables in globals.css respond to).
//
// An inline script in layout.tsx sets the initial class BEFORE hydration to
// prevent a flash. This hook then keeps React state in sync via
// useSyncExternalStore + a tiny external store.
// ============================================================================

import { useCallback, useEffect, useSyncExternalStore } from "react";

export type Theme = "light" | "dark";

const STORAGE_KEY = "ee_theme";

// ----- internal external-store -----
let currentTheme: Theme = "light";
const listeners = new Set<() => void>();

function readTheme(): Theme {
  if (typeof window === "undefined") return "light";
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored === "light" || stored === "dark") return stored;
  } catch {
    /* ignore */
  }
  if (window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
  return "light";
}

function applyThemeClass(theme: Theme) {
  const root = document.documentElement;
  if (theme === "dark") root.classList.add("dark");
  else root.classList.remove("dark");
}

function persist(theme: Theme) {
  try {
    window.localStorage.setItem(STORAGE_KEY, theme);
  } catch {
    /* ignore */
  }
}

function setTheme(theme: Theme) {
  if (theme === currentTheme) return;
  currentTheme = theme;
  applyThemeClass(theme);
  persist(theme);
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot(): Theme {
  return currentTheme;
}

function getServerSnapshot(): Theme {
  return "light";
}

export function useTheme() {
  const theme = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  // On mount, read the actual theme (set by the inline head script) and
  // sync the store. This runs once after hydration.
  useEffect(() => {
    const actual = readTheme();
    if (actual !== currentTheme) {
      currentTheme = actual;
      applyThemeClass(actual);
      listeners.forEach((l) => l());
    }
    // Listen for OS theme changes when the user hasn't chosen explicitly.
    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e: MediaQueryListEvent) => {
      try {
        if (window.localStorage.getItem(STORAGE_KEY)) return;
      } catch {
        /* ignore */
      }
      setTheme(e.matches ? "dark" : "light");
    };
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }, []);

  const setThemeCb = useCallback((t: Theme) => setTheme(t), []);
  const toggleTheme = useCallback(() => {
    setTheme(currentTheme === "dark" ? "light" : "dark");
  }, []);

  return {
    theme,
    setTheme: setThemeCb,
    toggleTheme,
    isDark: theme === "dark",
    mounted: true,
  };
}
