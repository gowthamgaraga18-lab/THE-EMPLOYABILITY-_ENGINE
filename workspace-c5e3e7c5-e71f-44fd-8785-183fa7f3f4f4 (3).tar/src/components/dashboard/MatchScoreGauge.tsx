"use client";

import * as React from "react";
import {
  RadialBar,
  RadialBarChart,
  PolarAngleAxis,
  ResponsiveContainer,
} from "recharts";
import { motion, useMotionValue, animate } from "framer-motion";
import { Target } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useTranslation } from "@/lib/use-translation";

interface MatchScoreGaugeProps {
  score: number; // 0-100
}

function colorFor(score: number): string {
  if (score >= 70) return "oklch(0.55 0.14 162)"; // emerald
  if (score >= 40) return "oklch(0.78 0.15 80)"; // amber
  return "oklch(0.62 0.2 20)"; // rose
}

function labelFor(score: number): string {
  if (score >= 70) return "Strong match";
  if (score >= 40) return "Partial match";
  return "Significant gaps";
}

function labelColorClass(score: number): string {
  if (score >= 70) return "text-emerald-600";
  if (score >= 40) return "text-amber-600";
  return "text-rose-600";
}

export function MatchScoreGauge({ score }: MatchScoreGaugeProps) {
  const { t } = useTranslation();
  const [displayScore, setDisplayScore] = React.useState(0);
  const motionScore = useMotionValue(0);

  React.useEffect(() => {
    const controls = animate(motionScore, score, {
      duration: 1.4,
      ease: "easeOut",
      onUpdate: (v) => setDisplayScore(Math.round(v)),
    });
    return () => controls.stop();
  }, [score, motionScore]);

  const barColor = colorFor(score);
  const label = labelFor(score);
  const labelClass = labelColorClass(score);

  const data = [{ name: "match", value: displayScore, fill: barColor }];

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Target className="size-4 text-primary" />
          {t("dash.matchAnalysis")}
        </CardTitle>
        <CardDescription>
          How well your resume aligns with the target role
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative mx-auto aspect-square w-full max-w-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <RadialBarChart
              innerRadius="72%"
              outerRadius="100%"
              data={data}
              startAngle={220}
              endAngle={-40}
              barSize={18}
            >
              <PolarAngleAxis
                type="number"
                domain={[0, 100]}
                angleAxisId={0}
                tick={false}
              />
              <RadialBar
                background={{ fill: "oklch(0.92 0.005 160)" }}
                dataKey="value"
                cornerRadius={12}
                isAnimationActive={false}
              />
            </RadialBarChart>
          </ResponsiveContainer>

          {/* Center text overlay */}
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <motion.div
              key={displayScore}
              initial={{ opacity: 0.7, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.25 }}
              className="text-5xl font-bold tabular-nums text-foreground"
            >
              {displayScore}
            </motion.div>
            <div className="text-xs font-medium text-muted-foreground">
              /100
            </div>
            <div className="mt-1 text-xs uppercase tracking-wide text-muted-foreground">
              Match Score
            </div>
          </div>
        </div>

        <div className="mt-4 text-center">
          <span
            className={`inline-flex items-center rounded-full border px-3 py-1 text-sm font-medium ${labelClass} ${
              score >= 70
                ? "bg-emerald-50 border-emerald-200"
                : score >= 40
                ? "bg-amber-50 border-amber-200"
                : "bg-rose-50 border-rose-200"
            }`}
          >
            {label}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
