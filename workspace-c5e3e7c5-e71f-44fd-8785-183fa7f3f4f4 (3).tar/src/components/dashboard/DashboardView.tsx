"use client";

import * as React from "react";
import { motion, type Variants } from "framer-motion";
import { ArrowLeft, Briefcase, Mic, Sparkles, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { MatchScoreGauge } from "./MatchScoreGauge";
import { SkillGapTags } from "./SkillGapTags";
import { ExperienceGaps } from "./ExperienceGaps";
import { RoadmapTimeline } from "./RoadmapTimeline";

const container: Variants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.05,
    },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: "easeOut" } },
};

export function DashboardView() {
  const analysis = useAppStore((s) => s.analysis);
  const setView = useAppStore((s) => s.setView);
  const resetInterview = useAppStore((s) => s.resetInterview);
  const setInterview = useAppStore((s) => s.setInterview);
  const { t } = useTranslation();

  const startInterview = React.useCallback(() => {
    if (!analysis) return;
    resetInterview();
    setInterview({
      targetRole: analysis.target_role,
      isActive: true,
      mode: "voice",
    });
    setView("interview");
  }, [analysis, resetInterview, setInterview, setView]);

  const startVideoInterview = React.useCallback(() => {
    if (!analysis) return;
    resetInterview();
    setInterview({
      targetRole: analysis.target_role,
      isActive: true,
      mode: "video",
    });
    setView("video-interview");
  }, [analysis, resetInterview, setInterview, setView]);

  if (!analysis) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 text-center">
        <div className="flex size-14 items-center justify-center rounded-full bg-muted">
          <Sparkles className="size-7 text-muted-foreground" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">{t("dash.noAnalysisTitle")}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("dash.noAnalysisDesc")}
          </p>
        </div>
        <Button
          variant="default"
          size="lg"
          onClick={() => setView("landing")}
          className="gap-2"
        >
          <ArrowLeft className="size-4" />
          {t("dash.backHome")}
        </Button>
      </div>
    );
  }

  const highCount = analysis.missing_skills.filter(
    (s) => s.severity === "High"
  ).length;

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
      {/* Top bar */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setView("landing")}
            className="gap-1.5 text-muted-foreground hover:text-foreground"
            aria-label={t("dash.back")}
          >
            <ArrowLeft className="size-4" />
            {t("dash.back")}
          </Button>
          <div className="hidden h-6 w-px bg-border sm:block" />
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <Briefcase className="size-4 text-primary" />
              <h1 className="text-lg font-semibold tracking-tight sm:text-xl">
                {analysis.target_role}
              </h1>
            </div>
            <p className="text-xs text-muted-foreground">
              {t("nav.dashboard")}
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <Button
            variant="default"
            size="lg"
            onClick={startInterview}
            className="gap-2 bg-primary text-primary-foreground shadow-md hover:bg-primary/90"
          >
            <Mic className="size-4" />
            {t("dash.startInterview")}
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={startVideoInterview}
            className="gap-2 border-primary/30 text-primary hover:bg-primary/10"
          >
            <Video className="size-4" />
            Video Interview
          </Button>
        </div>
      </header>

      {/* Staggered content */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="flex flex-col gap-6"
      >
        {/* Row 1: Gauge (narrower) | Skill Gaps (wider) */}
        <motion.div
          variants={item}
          className="grid grid-cols-1 gap-6 lg:grid-cols-5"
        >
          <div className="lg:col-span-2">
            <MatchScoreGauge score={analysis.match_score} />
          </div>
          <div className="lg:col-span-3">
            <SkillGapTags skills={analysis.missing_skills} />
          </div>
        </motion.div>

        {/* Row 2: Experience gaps (full width) */}
        <motion.div variants={item}>
          <ExperienceGaps gaps={analysis.experience_gaps} />
        </motion.div>

        {/* Row 3: Roadmap timeline (full width) */}
        <motion.div variants={item}>
          <RoadmapTimeline days={analysis.roadmap} />
        </motion.div>
      </motion.div>

      {/* Helper hint footer */}
      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
        <span>
          {highCount > 0 ? (
            <>
              <Badge
                variant="outline"
                className="mr-2 border-rose-200 bg-rose-50 text-rose-700"
              >
                {highCount} {t("dash.highSeverityCount")}
              </Badge>
            </>
          ) : (
            t("dash.noHighGaps")
          )}
        </span>
        <span>{t("nav.brand")}</span>
      </footer>
    </div>
  );
}
