"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, FileWarning } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useTranslation } from "@/lib/use-translation";

interface ExperienceGapsProps {
  gaps: string[];
}

export function ExperienceGaps({ gaps }: ExperienceGapsProps) {
  const { t } = useTranslation();
  const hasGaps = gaps.length > 0;

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileWarning className="size-4 text-primary" />
          {t("dash.experienceGaps")}
        </CardTitle>
        <CardDescription>
          Areas where your track record falls short of the role&rsquo;s
          expectations
        </CardDescription>
      </CardHeader>
      <CardContent>
        {hasGaps ? (
          <ul className="flex flex-col gap-3">
            {gaps.map((gap, idx) => (
              <motion.li
                key={`${idx}-${gap.slice(0, 24)}`}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, delay: idx * 0.05 }}
                className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3"
              >
                <AlertTriangle className="mt-0.5 size-5 shrink-0 text-amber-600" />
                <p className="text-sm leading-relaxed text-amber-900 dark:text-amber-100">
                  {gap}
                </p>
              </motion.li>
            ))}
          </ul>
        ) : (
          <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 p-8 text-center">
            <CheckCircle2 className="size-8 text-emerald-600" />
            <p className="text-sm font-medium text-emerald-800 dark:text-emerald-100">
              {t("dash.noGaps")}
            </p>
            <p className="text-xs text-emerald-700/80 dark:text-emerald-200/70">
              Your track record aligns well with what this role demands.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
