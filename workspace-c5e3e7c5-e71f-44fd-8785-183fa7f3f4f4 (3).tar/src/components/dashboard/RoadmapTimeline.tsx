"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Circle,
  Lightbulb,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import type { RoadmapDay } from "@/lib/types";

interface RoadmapTimelineProps {
  days: RoadmapDay[];
}

export function RoadmapTimeline({ days }: RoadmapTimelineProps) {
  const completedDays = useAppStore((s) => s.completedDays);
  const toggleDay = useAppStore((s) => s.toggleDay);
  const { t } = useTranslation();

  const totalDays = days.length || 7;
  const doneCount = days.filter((d) => completedDays[d.day]).length;
  const pct = totalDays === 0 ? 0 : Math.round((doneCount / totalDays) * 100);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarDays className="size-4 text-primary" />
              {t("dash.roadmap")}
            </CardTitle>
            <CardDescription>
              A focused plan to close the most critical gaps before your
              interview
            </CardDescription>
          </div>
          <Badge variant="secondary" className="tabular-nums">
            {doneCount}/{totalDays} {t("dash.day")}
          </Badge>
        </div>

        <div className="mt-2 flex items-center gap-3">
          <Progress value={pct} className="h-2.5" />
          <motion.span
            key={pct}
            initial={{ opacity: 0.6 }}
            animate={{ opacity: 1 }}
            className="w-12 shrink-0 text-right text-xs font-medium tabular-nums text-muted-foreground"
          >
            {pct}%
          </motion.span>
        </div>
      </CardHeader>

      <CardContent>
        <ol className="relative flex flex-col">
          {days.map((day, idx) => {
            const isDone = !!completedDays[day.day];
            const isLast = idx === days.length - 1;
            return (
              <TimelineRow
                key={day.day}
                day={day}
                isDone={isDone}
                isLast={isLast}
                onToggle={() => toggleDay(day.day)}
              />
            );
          })}
        </ol>
      </CardContent>
    </Card>
  );
}

interface TimelineRowProps {
  day: RoadmapDay;
  isDone: boolean;
  isLast: boolean;
  onToggle: () => void;
}

function TimelineRow({ day, isDone, isLast, onToggle }: TimelineRowProps) {
  const { t } = useTranslation();
  const [open, setOpen] = React.useState(false);

  return (
    <li className="relative flex gap-4 pb-4 last:pb-0">
      {/* Connecting vertical line */}
      {!isLast && (
        <span
          aria-hidden
          className="absolute left-[18px] top-9 bottom-0 w-px bg-border"
        />
      )}

      {/* Clickable circular node */}
      <button
        type="button"
        onClick={onToggle}
        aria-pressed={isDone}
        aria-label={
          isDone
            ? `${t("dash.markIncomplete")} ${day.day}`
            : `${t("dash.markComplete")} ${day.day}`
        }
        className={cn(
          "relative z-10 mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
          isDone
            ? "border-emerald-500 bg-emerald-500 text-white"
            : "border-border bg-card text-muted-foreground hover:border-primary hover:text-primary"
        )}
      >
        {isDone ? (
          <CheckCircle2 className="size-5" />
        ) : (
          <Circle className="size-5" />
        )}
        {!isDone && (
          <span className="absolute inset-0 flex items-center justify-center text-[11px] font-semibold tabular-nums">
            {day.day}
          </span>
        )}
      </button>

      {/* Collapsible content card */}
      <Collapsible
        open={open}
        onOpenChange={setOpen}
        className="min-w-0 flex-1"
      >
        <div
          className={cn(
            "rounded-xl border transition-colors",
            isDone
              ? "border-emerald-200 bg-emerald-50/40"
              : "border-border bg-card"
          )}
        >
          <CollapsibleTrigger asChild>
            <button
              type="button"
              className="flex w-full items-center justify-between gap-2 rounded-xl p-4 text-left transition-colors hover:bg-accent/50"
            >
              <div className="flex min-w-0 flex-col">
                <span className="flex items-center gap-2 text-sm font-semibold">
                  <span
                    className={cn(
                      "inline-flex size-6 items-center justify-center rounded-md text-xs font-bold tabular-nums",
                      isDone
                        ? "bg-emerald-500 text-white"
                        : "bg-muted text-muted-foreground"
                    )}
                  >
                    {day.day}
                  </span>
                  <span className="truncate">{day.topic}</span>
                </span>
                <span className="ml-8 mt-0.5 text-xs text-muted-foreground">
                  {day.key_concepts?.length ?? 0} concepts &middot; 1 practical
                  task
                </span>
              </div>
              <motion.span
                animate={{ rotate: open ? 180 : 0 }}
                transition={{ duration: 0.2 }}
                className="shrink-0 text-muted-foreground"
              >
                <ChevronDown className="size-4" />
              </motion.span>
            </button>
          </CollapsibleTrigger>

          <CollapsibleContent>
            <div className="border-t border-border/60 px-4 py-3">
              {/* Key concepts */}
              <div className="mb-3">
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {t("dash.keyConcepts")}
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {day.key_concepts?.length ? (
                    day.key_concepts.map((c, i) => (
                      <Badge
                        key={`${c}-${i}`}
                        variant="secondary"
                        className="font-normal"
                      >
                        {c}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-xs text-muted-foreground">
                      No concepts listed.
                    </span>
                  )}
                </div>
              </div>

              {/* Practical task */}
              <div>
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {t("dash.practicalTask")}
                </h4>
                <div className="flex items-start gap-2 rounded-lg bg-muted p-3">
                  <Lightbulb className="mt-0.5 size-4 shrink-0 text-amber-500" />
                  <p className="text-sm leading-relaxed text-foreground">
                    {day.practical_task}
                  </p>
                </div>
              </div>
            </div>
          </CollapsibleContent>
        </div>
      </Collapsible>
    </li>
  );
}
