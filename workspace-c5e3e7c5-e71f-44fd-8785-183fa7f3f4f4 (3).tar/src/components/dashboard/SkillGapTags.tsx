"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Tag } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/use-translation";
import type { MissingSkill, Severity } from "@/lib/types";

interface SkillGapTagsProps {
  skills: MissingSkill[];
}

type Filter = "All" | Severity;

const SEVERITY_META: Record<
  Severity,
  {
    chip: string;
    chipActive: string;
    badge: string;
    dot: string;
    text: string;
  }
> = {
  High: {
    chip: "border-rose-200 text-rose-600 bg-rose-50 hover:bg-rose-100",
    chipActive:
      "border-rose-300 bg-rose-600 text-white hover:bg-rose-600/90",
    badge:
      "border-rose-200 bg-rose-50 text-rose-700",
    dot: "bg-rose-500",
    text: "text-rose-600",
  },
  Medium: {
    chip: "border-amber-200 text-amber-600 bg-amber-50 hover:bg-amber-100",
    chipActive:
      "border-amber-300 bg-amber-500 text-white hover:bg-amber-500/90",
    badge:
      "border-amber-200 bg-amber-50 text-amber-700",
    dot: "bg-amber-500",
    text: "text-amber-600",
  },
  Low: {
    chip: "border-slate-300 text-slate-600 bg-slate-100 hover:bg-slate-200",
    chipActive:
      "border-slate-400 bg-slate-600 text-white hover:bg-slate-600/90",
    badge:
      "border-slate-300 bg-slate-100 text-slate-700",
    dot: "bg-slate-500",
    text: "text-slate-600",
  },
};

const FILTERS: Filter[] = ["All", "High", "Medium", "Low"];

export function SkillGapTags({ skills }: SkillGapTagsProps) {
  const { t } = useTranslation();
  const [active, setActive] = React.useState<Filter>("All");

  const filtered = React.useMemo(() => {
    if (active === "All") return skills;
    return skills.filter((s) => s.severity === active);
  }, [skills, active]);

  const counts = React.useMemo(() => {
    const c: Record<Filter, number> = {
      All: skills.length,
      High: 0,
      Medium: 0,
      Low: 0,
    };
    for (const s of skills) c[s.severity]++;
    return c;
  }, [skills]);

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Tag className="size-4 text-primary" />
              {t("dash.skillGaps")}
            </CardTitle>
          </div>
          <Badge variant="secondary" className="tabular-nums">
            {skills.length} total
          </Badge>
        </div>
        <CardDescription>
          Missing or underdeveloped skills surfaced from the JD
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {/* Filter chips */}
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => {
            const isActive = active === f;
            const chipClass =
              f === "All"
                ? isActive
                  ? "border-primary bg-primary text-primary-foreground hover:bg-primary/90"
                  : "border-border bg-background text-muted-foreground hover:bg-accent"
                : isActive
                ? SEVERITY_META[f as Severity].chipActive
                : SEVERITY_META[f as Severity].chip;

            return (
              <button
                key={f}
                type="button"
                onClick={() => setActive(f)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                  chipClass
                )}
              >
                {f === "All" ? t("dash.filterAll") : f}
                <span
                  className={cn(
                    "rounded-full px-1.5 text-[10px] tabular-nums",
                    isActive
                      ? "bg-white/25"
                      : "bg-black/5 dark:bg-white/10"
                  )}
                >
                  {counts[f]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Badge list */}
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {t("dash.noSkillsAtSeverity")}
          </p>
        ) : (
          <motion.ul
            layout
            className="flex flex-wrap gap-2"
          >
            {filtered.map((s) => {
              const meta = SEVERITY_META[s.severity];
              return (
                <motion.li
                  key={`${s.skill}-${s.category}`}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.2 }}
                >
                  <Badge
                    variant="outline"
                    className={cn(
                      "gap-2 px-3 py-1.5 text-sm",
                      meta.badge
                    )}
                  >
                    <span
                      className={cn(
                        "inline-block size-2 rounded-full",
                        meta.dot
                      )}
                    />
                    <span className="font-semibold">{s.skill}</span>
                    <span className="text-[11px] font-normal opacity-70">
                      {s.category}
                    </span>
                  </Badge>
                </motion.li>
              );
            })}
          </motion.ul>
        )}
      </CardContent>
    </Card>
  );
}
