"use client";

import * as React from "react";
import {
  Sparkles,
  ShieldCheck,
  Zap,
  TrendingUp,
  Quote,
  type LucideIcon,
} from "lucide-react";
import { ThemeToggle } from "@/components/shared/ThemeToggle";
import { LanguageToggle } from "@/components/shared/LanguageToggle";
import { useTranslation } from "@/lib/use-translation";

interface FeatureItem {
  icon: LucideIcon;
  titleKey: "auth.featureSecure" | "auth.featureAi" | "auth.featureTrack";
  descKey: "auth.featureSecureDesc" | "auth.featureAiDesc" | "auth.featureTrackDesc";
}

const features: FeatureItem[] = [
  { icon: ShieldCheck, titleKey: "auth.featureSecure", descKey: "auth.featureSecureDesc" },
  { icon: Zap, titleKey: "auth.featureAi", descKey: "auth.featureAiDesc" },
  { icon: TrendingUp, titleKey: "auth.featureTrack", descKey: "auth.featureTrackDesc" },
];

interface AuthLayoutProps {
  title: string;
  subtitle: string;
  footer?: React.ReactNode;
  children: React.ReactNode;
}

/**
 * AuthLayout — shared split-screen layout for the Login and Signup views.
 *
 * - Desktop (lg+): two columns — dark, animated visual panel on the left;
 *   light, centered form card on the right.
 * - Mobile: only the form panel is shown (visual hidden), with a compact
 *   brand header above the form.
 */
export function AuthLayout({ title, subtitle, footer, children }: AuthLayoutProps) {
  const { t } = useTranslation();
  return (
    <div className="min-h-screen w-full lg:grid lg:grid-cols-2">
      {/* ============== Left visual panel ============== */}
      <aside
        className="relative hidden overflow-hidden lg:flex lg:flex-col lg:justify-between p-10 text-white"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.45 0.13 162) 0%, oklch(0.40 0.10 195) 50%, oklch(0.28 0.09 165) 100%)",
        }}
      >
        {/* Floating orbs */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-24 -left-12 h-72 w-72 rounded-full bg-teal-300/30 blur-3xl animate-float-slow" />
          <div className="absolute top-1/3 -right-20 h-80 w-80 rounded-full bg-emerald-200/25 blur-3xl animate-float-medium" />
          <div className="absolute bottom-0 left-1/4 h-64 w-64 rounded-full bg-violet-400/20 blur-3xl animate-float-slow" />
        </div>

        {/* White-tinted grid overlay (the .bg-grid utility is too faint on dark) */}
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.12]"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.6) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />

        {/* Content */}
        <div className="relative z-10 flex h-full flex-col justify-between gap-10">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/15 ring-1 ring-white/30 backdrop-blur-md">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold tracking-tight">
                {t("nav.brand")}
              </div>
              <div className="text-sm text-white/70">{t("nav.tagline")}</div>
            </div>
          </div>

          {/* Hero copy + feature pills */}
          <div className="max-w-md">
            <h2 className="text-3xl font-bold leading-tight tracking-tight xl:text-4xl">
              {t("auth.visualHeadline")}{" "}
              <span className="italic text-white/90">clarity</span>.
            </h2>
            <p className="mt-3 text-white/75">
              {t("auth.visualBody")}
            </p>
            <ul className="mt-7 space-y-3">
              {features.map((f) => (
                <li
                  key={f.titleKey}
                  className="glass flex items-center gap-3 rounded-xl px-4 py-3"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/20 ring-1 ring-white/25">
                    <f.icon className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-sm font-semibold leading-tight">
                      {t(f.titleKey)}
                    </div>
                    <div className="text-xs text-white/70">{t(f.descKey)}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Testimonial */}
          <div className="glass max-w-md rounded-2xl p-4">
            <Quote className="h-5 w-5 text-white/80" />
            <p className="mt-2 text-sm leading-relaxed text-white/90">
              &ldquo;{t("auth.quote")}&rdquo;
            </p>
            <div className="mt-3 flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-white/30 ring-1 ring-white/30" />
              <div>
                <div className="text-xs font-semibold">{t("auth.quoteAuthor")}</div>
                <div className="text-[10px] text-white/60">
                  {t("auth.quoteRole")}
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* ============== Right form panel ============== */}
      <main className="relative flex min-h-screen flex-col items-center justify-start overflow-y-auto bg-background px-4 py-12 sm:justify-center sm:p-6 lg:p-10 scrollbar-thin">
        {/* Subtle dotted texture so glass surfaces read */}
        <div className="pointer-events-none absolute inset-0 bg-dots opacity-40" />

        {/* Desktop theme + language toggle (top-right of the form panel) */}
        <div className="absolute right-6 top-6 z-20 hidden items-center gap-2 lg:flex">
          <ThemeToggle />
          <LanguageToggle />
        </div>

        {/* Mobile brand header + theme/language toggle */}
        <div className="relative z-10 mb-6 flex w-full items-center justify-between lg:hidden">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-md">
              <Sparkles className="h-5 w-5" />
            </div>
            <span className="font-semibold tracking-tight">
              {t("nav.brand")}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle size="sm" />
            <LanguageToggle size="sm" />
          </div>
        </div>

        <div className="relative z-10 w-full max-w-md">
          {/* Gradient-border wrapper + glass form card */}
          <div className="rounded-2xl bg-gradient-to-br from-emerald-500/40 via-teal-400/25 to-violet-400/30 p-px shadow-xl shadow-emerald-900/5">
            <div className="glass-strong rounded-2xl p-6 sm:p-8">
              <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
              <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
              <div className="mt-6">{children}</div>
            </div>
          </div>

          {footer && (
            <div className="mt-4 text-center text-sm text-muted-foreground">
              {footer}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default AuthLayout;
