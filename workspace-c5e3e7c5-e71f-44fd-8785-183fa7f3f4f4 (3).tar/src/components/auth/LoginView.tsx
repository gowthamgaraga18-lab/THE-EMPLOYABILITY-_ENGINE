"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Sparkles,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { AuthLayout } from "./AuthLayout";

const DEMO_EMAIL = "demo@employability.io";
const DEMO_PASSWORD = "demo123";

export function LoginView() {
  const { t } = useTranslation();
  const login = useAppStore((s) => s.login);
  const setView = useAppStore((s) => s.setView);

  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [remember, setRemember] = React.useState(true);
  const [showPassword, setShowPassword] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const validEmail = /.+@.+\..+/.test(email.trim());

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (isLoading) return;
    setError(null);

    if (!email.trim()) {
      setError(t("login.errors.emailRequired"));
      return;
    }
    if (!password) {
      setError(t("login.errors.passwordRequired"));
      return;
    }
    if (!validEmail) {
      setError("Please enter a valid email address.");
      return;
    }

    setIsLoading(true);
    const res = await login(email, password);
    setIsLoading(false);

    if (res.ok) {
      toast.success("Welcome back!");
      // store auto-sets view to "landing"
    } else {
      setError(res.error ?? "Something went wrong.");
      toast.error(res.error ?? "Something went wrong.");
    }
  }

  async function handleDemo() {
    if (isLoading) return;
    setError(null);
    // Auto-fill the fields visually, then submit.
    setEmail(DEMO_EMAIL);
    setPassword(DEMO_PASSWORD);

    setIsLoading(true);
    const res = await login(DEMO_EMAIL, DEMO_PASSWORD);
    setIsLoading(false);

    if (res.ok) {
      toast.success("Welcome back! Demo session started.");
    } else {
      setError(res.error ?? "Demo login failed.");
      toast.error(res.error ?? "Demo login failed.");
    }
  }

  const footer = (
    <span>
      {t("login.noAccount")}{" "}
      <button
        type="button"
        onClick={() => setView("signup")}
        className="font-semibold text-emerald-700 underline-offset-4 hover:underline dark:text-emerald-400"
      >
        {t("login.signupLink")}
      </button>
    </span>
  );

  return (
    <AuthLayout title={t("login.title")} subtitle={t("login.subtitle")} footer={footer}>
      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="space-y-4"
        noValidate
      >
        {error && (
          <div
            role="alert"
            className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/40 dark:text-rose-300"
          >
            {error}
          </div>
        )}

        {/* Email */}
        <div className="space-y-1.5">
          <Label htmlFor="login-email">{t("login.email")}</Label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="login-email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-xl pl-9 pr-3"
              aria-invalid={!!error}
            />
          </div>
        </div>

        {/* Password */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="login-password">{t("login.password")}</Label>
            <button
              type="button"
              className="text-xs text-muted-foreground hover:text-emerald-700 dark:hover:text-emerald-400"
              onClick={() =>
                toast.info("Password reset is not available in demo mode.", {
                  description: "Use the demo account to explore the platform.",
                })
              }
            >
              {t("login.forgot")}
            </button>
          </div>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="login-password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 rounded-xl pl-9 pr-10"
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-emerald-700 dark:hover:text-emerald-400"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>

        {/* Remember me */}
        <div className="flex items-center gap-2">
          <Checkbox
            id="login-remember"
            checked={remember}
            onCheckedChange={(v) => setRemember(v === true)}
          />
          <Label
            htmlFor="login-remember"
            className="cursor-pointer text-sm font-normal text-muted-foreground"
          >
            {t("login.remember")}
          </Label>
        </div>

        {/* Submit */}
        <Button
          type="submit"
          disabled={isLoading}
          className="h-12 w-full rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md transition-all hover:from-emerald-700 hover:to-teal-700 hover:shadow-lg focus-visible:ring-emerald-500/50"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              {t("login.submitting")}
            </>
          ) : (
            <>
              {t("login.submit")}
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>

        {/* Separator */}
        <div className="relative flex items-center gap-3 py-1">
          <Separator className="flex-1" />
          <span className="text-xs text-muted-foreground">or</span>
          <Separator className="flex-1" />
        </div>

        {/* Demo */}
        <Button
          type="button"
          variant="ghost"
          onClick={handleDemo}
          disabled={isLoading}
          className="h-11 w-full rounded-xl border border-border hover:bg-accent"
        >
          <Sparkles className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          {t("login.demo")}
        </Button>
      </motion.form>
    </AuthLayout>
  );
}

export default LoginView;
