"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Sparkles,
  Mail,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  ArrowRight,
  Loader2,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { cn } from "@/lib/utils";
import { AuthLayout } from "./AuthLayout";

const DEMO_EMAIL = "demo@employability.io";
const DEMO_PASSWORD = "demo123";

type PwKind = "empty" | "tooShort" | "weak" | "medium" | "strong";

interface PwStrength {
  level: 0 | 1 | 2 | 3;
  kind: PwKind;
  barClass: string;
  hint: string;
}

function evalPassword(pw: string): PwStrength {
  if (!pw) {
    return {
      level: 0,
      kind: "empty",
      barClass: "bg-muted",
      hint: "Use 6+ characters with a mix of letters, numbers & symbols.",
    };
  }
  if (pw.length < 6) {
    return {
      level: 1,
      kind: "tooShort",
      barClass: "bg-rose-500",
      hint: "Password must be at least 6 characters.",
    };
  }
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  if (score >= 3) {
    return {
      level: 3,
      kind: "strong",
      barClass: "bg-emerald-500",
      hint: "Looks solid — you\u2019re good to go.",
    };
  }
  if (score >= 2) {
    return {
      level: 2,
      kind: "medium",
      barClass: "bg-amber-500",
      hint: "Add another number or symbol for extra strength.",
    };
  }
  return {
    level: 1,
    kind: "weak",
    barClass: "bg-rose-500",
    hint: "Try mixing letters, numbers and symbols.",
  };
}

export function SignupView() {
  const { t } = useTranslation();
  const signup = useAppStore((s) => s.signup);
  const setView = useAppStore((s) => s.setView);

  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [agreed, setAgreed] = React.useState(false);
  const [showPassword, setShowPassword] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const validEmail = /.+@.+\..+/.test(email.trim());
  const pw = evalPassword(password);

  const pwLabel: Record<PwKind, string> = {
    empty: "",
    tooShort: t("signup.passwordStrength.tooShort"),
    weak: t("signup.passwordStrength.weak"),
    medium: t("signup.passwordStrength.medium"),
    strong: t("signup.passwordStrength.strong"),
  };

  const canSubmit =
    name.trim().length > 0 && validEmail && password.length >= 6 && agreed && !isLoading;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (isLoading) return;
    setError(null);

    if (!name.trim()) {
      setError("Please enter your name.");
      return;
    }
    if (!validEmail) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (!agreed) {
      setError("Please agree to the Terms & Privacy Policy to continue.");
      return;
    }

    setIsLoading(true);
    const res = await signup(name, email, password);
    setIsLoading(false);

    if (res.ok) {
      toast.success("Account created! Welcome aboard.");
      // store auto-sets view to "landing"
    } else {
      setError(res.error ?? "Something went wrong.");
      toast.error(res.error ?? "Something went wrong.");
    }
  }

  async function handleDemo() {
    if (isLoading) return;
    setError(null);
    setName("Demo User");
    setEmail(DEMO_EMAIL);
    setPassword(DEMO_PASSWORD);
    setAgreed(true);

    setIsLoading(true);
    // Demo signup — if the demo account already exists, fall back to login.
    const res = await signup("Demo User", DEMO_EMAIL, DEMO_PASSWORD);
    setIsLoading(false);

    if (res.ok) {
      toast.success("Welcome aboard! Demo session started.");
    } else {
      // Demo account already exists → just navigate to login so the user
      // can use the demo button there.
      setError(res.error ?? "Demo signup failed.");
      toast.info("Demo account already exists. Switching to login…");
      setView("login");
    }
  }

  const footer = (
    <span>
      {t("signup.haveAccount")}{" "}
      <button
        type="button"
        onClick={() => setView("login")}
        className="font-semibold text-emerald-700 underline-offset-4 hover:underline dark:text-emerald-400"
      >
        {t("signup.loginLink")}
      </button>
    </span>
  );

  return (
    <AuthLayout title={t("signup.title")} subtitle={t("signup.subtitle")} footer={footer}>
      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="space-y-4"
        noValidate
      >
        {error && (
          <div
            role="alert"
            className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/40 dark:text-rose-300"
          >
            {error}
          </div>
        )}

        {/* Name */}
        <div className="space-y-1.5">
          <Label htmlFor="signup-name">{t("signup.name")}</Label>
          <div className="relative">
            <UserIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="signup-name"
              type="text"
              autoComplete="name"
              placeholder="Jane Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-xl pl-9 pr-3"
            />
          </div>
        </div>

        {/* Email */}
        <div className="space-y-1.5">
          <Label htmlFor="signup-email">{t("signup.email")}</Label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="signup-email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-xl pl-9 pr-3"
            />
          </div>
        </div>

        {/* Password + strength */}
        <div className="space-y-1.5">
          <Label htmlFor="signup-password">{t("signup.password")}</Label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="signup-password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 rounded-xl pl-9 pr-10"
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-emerald-700 dark:hover:text-emerald-400"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>

          {/* Strength bar */}
          {password && (
            <div className="space-y-1 pt-1">
              <div className="flex gap-1.5">
                {[1, 2, 3].map((seg) => (
                  <div
                    key={seg}
                    className={cn(
                      "h-1.5 flex-1 rounded-full transition-colors",
                      seg <= pw.level ? pw.barClass : "bg-muted",
                    )}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">
                  {pwLabel[pw.kind]}
                </span>
                <span className="text-[11px] text-muted-foreground">{pw.hint}</span>
              </div>
            </div>
          )}
        </div>

        {/* Terms */}
        <div className="flex items-start gap-2 pt-1">
          <Checkbox
            id="signup-terms"
            checked={agreed}
            onCheckedChange={(v) => setAgreed(v === true)}
            className="mt-0.5"
          />
          <Label
            htmlFor="signup-terms"
            className="flex flex-wrap items-center gap-1 cursor-pointer text-sm font-normal text-muted-foreground"
          >
            {t("signup.terms")}
            <button
              type="button"
              className="inline-flex size-4 items-center justify-center rounded-full text-muted-foreground hover:text-emerald-700 dark:hover:text-emerald-400"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toast.info("Terms & Privacy Policy", {
                  description:
                    "Demo platform — no real data is collected or shared.",
                });
              }}
              aria-label="View Terms & Privacy Policy"
            >
              <Info className="size-3.5" />
            </button>
          </Label>
        </div>

        {/* Submit */}
        <Button
          type="submit"
          disabled={!canSubmit}
          className="h-12 w-full rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md transition-all hover:from-emerald-700 hover:to-teal-700 hover:shadow-lg focus-visible:ring-emerald-500/50 disabled:opacity-60"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              {t("signup.submitting")}
            </>
          ) : (
            <>
              {t("signup.submit")}
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>

        {/* Separator */}
        <div className="relative flex items-center gap-3 py-1">
          <Separator className="flex-1" />
          <span className="text-xs text-muted-foreground">or</span>
          <Separator className="flex-1" />
        </div>

        {/* Demo */}
        <Button
          type="button"
          variant="ghost"
          onClick={handleDemo}
          disabled={isLoading}
          className="h-11 w-full rounded-xl border border-border hover:bg-accent"
        >
          <Sparkles className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          {t("signup.demo")}
        </Button>
      </motion.form>
    </AuthLayout>
  );
}

export default SignupView;
