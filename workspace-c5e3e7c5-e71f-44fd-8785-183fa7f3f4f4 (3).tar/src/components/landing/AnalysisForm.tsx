"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  FileText,
  Upload,
  X,
  Loader2,
  Sparkles,
  Link as LinkIcon,
  ClipboardPaste,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { useAppStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import type { AnalysisResult } from "@/lib/types";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const ACCEPTED = [".txt", ".md", ".pdf"];

// ---------------------------------------------------------------------------
// PDF text extraction (pdfjs-dist, dynamically imported, client-only)
// ---------------------------------------------------------------------------
async function extractPdfText(arrayBuffer: ArrayBuffer): Promise<string> {
  const pdfjsLib = await import("pdfjs-dist/legacy/build/pdf.mjs");
  // Use a CDN-hosted worker matching the installed pdfjs version.
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/" +
    pdfjsLib.version +
    "/pdf.worker.min.mjs";

  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;

  let fullText = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item) => ("str" in item ? (item as { str: string }).str : ""))
      .join(" ");
    fullText += pageText + "\n";
  }
  return fullText.trim();
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------
export function AnalysisForm() {
  const { toast } = useToast();
  const isAnalyzing = useAppStore((s) => s.isAnalyzing);
  const setIsAnalyzing = useAppStore((s) => s.setIsAnalyzing);
  const setAnalysis = useAppStore((s) => s.setAnalysis);
  const saveTrailAfterAnalysis = useAppStore((s) => s.saveTrailAfterAnalysis);
  const setView = useAppStore((s) => s.setView);
  const setError = useAppStore((s) => s.setError);

  // JD state
  const [jdTab, setJdTab] = React.useState<"paste" | "url">("paste");
  const [jdText, setJdText] = React.useState("");
  const [jdUrl, setJdUrl] = React.useState("");

  // Resume state
  const [resumeText, setResumeText] = React.useState("");
  const [fileName, setFileName] = React.useState<string | null>(null);
  const [isParsing, setIsParsing] = React.useState(false);
  const [isDragging, setIsDragging] = React.useState(false);

  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  // -------------------------------------------------------------------------
  // File handling
  // -------------------------------------------------------------------------
  const acceptedFile = React.useCallback((file: File) => {
    const lower = file.name.toLowerCase();
    if (!ACCEPTED.some((ext) => lower.endsWith(ext))) {
      toast({
        title: "Unsupported file type",
        description: "Please upload a .txt, .md, or .pdf file.",
        variant: "destructive",
      });
      return;
    }
    setFileName(file.name);
    void parseFile(file);
  }, [toast]);

  const parseFile = React.useCallback(
    async (file: File) => {
      setIsParsing(true);
      try {
        let text = "";
        const lower = file.name.toLowerCase();
        if (lower.endsWith(".pdf")) {
          const arrayBuffer = await file.arrayBuffer();
          text = await extractPdfText(arrayBuffer);
        } else {
          text = await file.text();
        }

        if (!text || text.trim().length < 5) {
          toast({
            title: "Couldn't read file content",
            description:
              "We couldn't extract text from this file. Paste your resume manually below.",
            variant: "destructive",
          });
          setFileName(null);
          return;
        }

        setResumeText(text);
        toast({
          title: "Resume parsed",
          description: `${file.name} — ${text.length} characters loaded.`,
        });
      } catch (err) {
        console.error("[parseFile] error:", err);
        toast({
          title: "Failed to parse file",
          description:
            "Please paste your resume text directly into the field below.",
          variant: "destructive",
        });
        setFileName(null);
      } finally {
        setIsParsing(false);
      }
    },
    [toast],
  );

  const onFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) acceptedFile(file);
    // reset so selecting the same file again re-triggers change
    e.target.value = "";
  };

  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) acceptedFile(file);
  };

  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!isDragging) setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const removeFile = () => {
    setFileName(null);
    setResumeText("");
  };

  // -------------------------------------------------------------------------
  // Submit
  // -------------------------------------------------------------------------
  const onSubmit = async () => {
    const activeJdText = jdTab === "paste" ? jdText.trim() : jdUrl.trim();

    if (!activeJdText) {
      toast({
        title: "Missing job description",
        description:
          jdTab === "paste"
            ? "Paste the job description text first."
            : "Enter the job description URL first.",
        variant: "destructive",
      });
      return;
    }
    if (!resumeText.trim()) {
      toast({
        title: "Missing resume",
        description: "Upload a resume file or paste your resume text below.",
        variant: "destructive",
      });
      return;
    }
    if (resumeText.trim().length < 20) {
      toast({
        title: "Resume too short",
        description: "Please provide a longer resume for meaningful analysis.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeText: resumeText.trim(),
          jdText: activeJdText,
        }),
      });

      const data = (await res.json().catch(() => ({}))) as {
        success?: boolean;
        result?: AnalysisResult;
        error?: string;
      };

      if (!res.ok || !data.success || !data.result) {
        throw new Error(data.error || `Request failed (${res.status})`);
      }

      setAnalysis(data.result);
      // Save a job trail to the user's history (non-blocking).
      void saveTrailAfterAnalysis(data.result);
      toast({
        title: "Analysis complete",
        description: `Match score: ${data.result.match_score}% — view your roadmap now.`,
      });
      setView("dashboard");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Something went wrong.";
      console.error("[/api/analyze] error:", err);
      setError(message);
      toast({
        title: "Analysis failed",
        description: message,
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // -------------------------------------------------------------------------
  return (
    <section id="analyze" className="mx-auto w-full max-w-6xl scroll-mt-8 px-4">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.55, ease: "easeOut" }}
      >
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Analyze your fit, instantly
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Drop in a job description and your resume. Our AI returns a match
            score, critical skill gaps, and a focused 7-day learning plan.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* ---------------------------------- JD CARD --------------------------------- */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <span className="flex size-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <FileText className="size-4" />
                </span>
                Job Description
              </CardTitle>
              <CardDescription>
                Paste the JD text, or share a public link to it.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <Tabs
                value={jdTab}
                onValueChange={(v) => setJdTab(v as "paste" | "url")}
                className="w-full"
              >
                <TabsList className="mb-3">
                  <TabsTrigger value="paste" className="gap-1.5">
                    <ClipboardPaste className="size-3.5" />
                    Paste JD
                  </TabsTrigger>
                  <TabsTrigger value="url" className="gap-1.5">
                    <LinkIcon className="size-3.5" />
                    JD URL
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="paste">
                  <Textarea
                    value={jdText}
                    onChange={(e) => setJdText(e.target.value)}
                    placeholder="Paste the full job description here — responsibilities, required skills, qualifications…"
                    className="min-h-[220px] resize-y md:min-h-[260px]"
                    disabled={isAnalyzing}
                  />
                  <p className="mt-2 text-xs text-muted-foreground">
                    {jdText.trim().length.toLocaleString()} characters
                  </p>
                </TabsContent>

                <TabsContent value="url">
                  <div className="space-y-2">
                    <Label htmlFor="jd-url" className="sr-only">
                      Job description URL
                    </Label>
                    <Input
                      id="jd-url"
                      type="url"
                      inputMode="url"
                      value={jdUrl}
                      onChange={(e) => setJdUrl(e.target.value)}
                      placeholder="https://example.com/jobs/senior-engineer"
                      disabled={isAnalyzing}
                    />
                    <p className="text-xs text-muted-foreground">
                      Paste a public link to the job posting. It will be passed
                      as the JD reference text.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* -------------------------------- RESUME CARD ------------------------------- */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <span className="flex size-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <FileText className="size-4" />
                </span>
                Your Resume
              </CardTitle>
              <CardDescription>
                Upload a .txt, .md, or .pdf file — or paste the text directly.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-1 flex-col gap-4">
              {/* Dropzone */}
              <div
                role="button"
                tabIndex={0}
                onClick={() => fileInputRef.current?.click()}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                onDrop={onDrop}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                aria-label="Upload resume file"
                className={cn(
                  "group relative flex min-h-[140px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-6 text-center transition-colors",
                  isDragging
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/60 hover:bg-accent/40",
                  isAnalyzing && "pointer-events-none opacity-60",
                )}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ACCEPTED.join(",")}
                  onChange={onFileInputChange}
                  className="hidden"
                  disabled={isAnalyzing}
                />

                {isParsing ? (
                  <>
                    <Loader2 className="size-7 animate-spin text-primary" />
                    <p className="text-sm font-medium text-foreground">
                      Parsing file…
                    </p>
                  </>
                ) : fileName ? (
                  <>
                    <FileText className="size-7 text-primary" />
                    <p
                      className="max-w-full truncate text-sm font-medium text-foreground"
                      title={fileName}
                    >
                      {fileName}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Click to replace, or use the remove button.
                    </p>
                  </>
                ) : (
                  <>
                    <Upload className="size-7 text-muted-foreground transition-colors group-hover:text-primary" />
                    <p className="text-sm font-medium text-foreground">
                      Drag &amp; drop your resume here
                    </p>
                    <p className="text-xs text-muted-foreground">
                      or click to browse — .txt, .md, .pdf
                    </p>
                  </>
                )}
              </div>

              {/* Selected file chip */}
              {fileName && !isParsing && (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-muted/40 px-3 py-2">
                  <span
                    className="flex min-w-0 items-center gap-2 text-sm text-foreground"
                    title={fileName}
                  >
                    <FileText className="size-4 shrink-0 text-primary" />
                    <span className="truncate">{fileName}</span>
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={removeFile}
                    disabled={isAnalyzing}
                    className="h-7 shrink-0 gap-1 px-2 text-muted-foreground hover:text-destructive"
                  >
                    <X className="size-3.5" />
                    Remove
                  </Button>
                </div>
              )}

              {/* Paste fallback */}
              <div className="flex flex-1 flex-col gap-2">
                <Label
                  htmlFor="resume-text"
                  className="text-xs font-medium text-muted-foreground"
                >
                  Or paste your resume text directly
                </Label>
                <Textarea
                  id="resume-text"
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  placeholder="Paste your resume content here — experience, skills, education, projects…"
                  className="min-h-[160px] flex-1 resize-y md:min-h-[180px]"
                  disabled={isAnalyzing}
                />
                <p className="text-xs text-muted-foreground">
                  {resumeText.trim().length.toLocaleString()} characters
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Submit */}
        <div className="mt-8 flex flex-col items-center gap-3">
          <Button
            type="button"
            size="lg"
            onClick={onSubmit}
            disabled={isAnalyzing || isParsing}
            className="h-12 w-full max-w-sm gap-2 rounded-xl text-base shadow-md sm:w-auto"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="size-5 animate-spin" />
                Analyzing…
              </>
            ) : (
              <>
                <Sparkles className="size-5" />
                Analyze &amp; Build Roadmap
              </>
            )}
          </Button>
          <p className="max-w-md text-center text-xs text-muted-foreground">
            Runs a structured AI analysis on your resume vs the JD. Typical
            response time is 10–20 seconds.
          </p>
        </div>
      </motion.div>
    </section>
  );
}

export default AnalysisForm;
