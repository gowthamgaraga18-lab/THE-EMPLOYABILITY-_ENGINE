"use client";

import { motion } from "framer-motion";
import { FileSearch, Map, Mic, ArrowRight } from "lucide-react";
import { useTranslation } from "@/lib/use-translation";

interface Feature {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  link: string;
  linkLabel: string;
}

export function FeaturesSection() {
  const { t } = useTranslation();

  const features: Feature[] = [
    {
      icon: FileSearch,
      title: t("features.resumeTitle"),
      description: t("features.resumeDesc"),
      link: "#analyze",
      linkLabel: t("features.learnMore"),
    },
    {
      icon: Map,
      title: t("features.roadmapTitle"),
      description: t("features.roadmapDesc"),
      link: "#analyze",
      linkLabel: t("features.learnMore"),
    },
    {
      icon: Mic,
      title: t("features.interviewTitle"),
      description: t("features.interviewDesc"),
      link: "#analyze",
      linkLabel: t("features.learnMore"),
    },
  ];

  return (
    <section id="features" className="mx-auto w-full max-w-6xl px-4 py-8">
      {/* ---------------------------------------------------------------- */}
      {/* Header */}
      {/* ---------------------------------------------------------------- */}
      <div className="mb-10 text-center">
        <span className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-600">
          {t("features.label")}
        </span>
        <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          {t("features.titlePre")}{" "}
          <span className="text-gradient">{t("features.titleHighlight")}</span>
        </h2>
        <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
          {t("features.subtitle")}
        </p>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* Cards */}
      {/* ---------------------------------------------------------------- */}
      <div className="grid gap-6 md:grid-cols-3">
        {features.map(
          ({ icon: Icon, title, description, link, linkLabel }, idx) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{
                duration: 0.45,
                ease: "easeOut",
                delay: idx * 0.08,
              }}
              whileHover={{ y: -6 }}
              className="gradient-border group rounded-2xl"
            >
              <div
                className="glass relative flex h-full flex-col overflow-hidden rounded-2xl p-6 transition-shadow duration-300 group-hover:shadow-xl"
                style={{ border: "none" }}
              >
                {/* Decorative number */}
                <span
                  aria-hidden
                  className="pointer-events-none absolute -right-2 -top-3 select-none font-mono text-6xl font-bold text-foreground/[0.05]"
                >
                  {String(idx + 1).padStart(2, "0")}
                </span>

                {/* Icon */}
                <div className="mb-4 flex size-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
                  <Icon className="size-5" />
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-foreground">{title}</h3>

                {/* Description */}
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {description}
                </p>

                {/* Learn more */}
                <a
                  href={link}
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-emerald-600 transition-colors hover:text-emerald-700"
                >
                  {linkLabel}
                  <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                </a>
              </div>
            </motion.div>
          ),
        )}
      </div>
    </section>
  );
}

export default FeaturesSection;
