"use client";

import { HeroSection } from "./HeroSection";
import { AnalysisForm } from "./AnalysisForm";
import { FeaturesSection } from "./FeaturesSection";

/**
 * LandingView — the entry view of "The Employability Engine".
 * Stacks: Hero → AnalysisForm → Features.
 * The sticky top nav and footer are handled by the parent page.
 */
export function LandingView() {
  return (
    <section className="flex flex-col gap-12 pb-16 sm:gap-16">
      <HeroSection />
      <AnalysisForm />
      <FeaturesSection />
    </section>
  );
}

export default LandingView;
