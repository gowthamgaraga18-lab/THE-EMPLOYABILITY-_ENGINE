"use client";

import { motion } from "framer-motion";
import { ArrowDown, ArrowRight, Play, Sparkles, Map, Mic } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.09, delayChildren: 0.05 },
  },
};

const item = {
  hidden: { opacity: 0, y: 18 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" as const },
  },
};

export function HeroSection() {
  const { t } = useTranslation();
  const isAuthenticated = useAppStore((s) => s.isAuthenticated);
  const setView = useAppStore((s) => s.setView);

  const stats = [
    { label: t("hero.statMatchScore"), icon: Sparkles },
    { label: t("hero.statRoadmap"), icon: Map },
    { label: t("hero.statVoice"), icon: Mic },
  ];

  const handlePrimary = () => {
    if (isAuthenticated) {
      const el = document.getElementById("analyze");
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      setView("login");
    }
  };

  return (
    <section className="relative isolate overflow-hidden">
      {/* Background: emerald grid with radial fade mask */}
      <div
        aria-hidden
        className="bg-grid absolute inset-0 -z-10 opacity-70 [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_75%)]"
      />
      {/* Subtle gradient wash for depth */}
      <div
        aria-hidden
        className="absolute inset-0 -z-10 bg-gradient-to-b from-emerald-50/60 via-transparent to-transparent"
      />

      {/* Floating gradient orbs — higher opacity + z-0 so they're visible above bg-grid */}
      <div
        aria-hidden
        className="animate-float-slow absolute -left-20 top-0 z-0 h-80 w-80 rounded-full bg-emerald-400/40 blur-3xl"
      />
      <div
        aria-hidden
        className="animate-float-medium absolute -right-20 top-10 z-0 h-96 w-96 rounded-full bg-teal-400/35 blur-3xl"
      />
      <div
        aria-hidden
        className="animate-float-slow absolute bottom-10 left-1/3 z-0 h-72 w-72 rounded-full bg-violet-400/25 blur-3xl"
      />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="relative z-10 mx-auto flex max-w-4xl flex-col items-center px-4 py-16 text-center sm:py-24"
      >
        {/* Top badge */}
        <motion.div variants={item}>
          <span className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-medium text-foreground shadow-sm">
            <Sparkles className="size-3.5 text-primary" />
            {t("hero.badge")}
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-700">
              <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />
              {t("hero.badgeNew")}
            </span>
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={item}
          className="mt-6 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl"
        >
          {t("hero.titlePre")}{" "}
          <span
            style={{
              background:
                "linear-gradient(135deg, oklch(0.58 0.16 162) 0%, oklch(0.62 0.12 195) 60%, oklch(0.58 0.18 300) 100%)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              WebkitTextFillColor: "transparent",
              color: "transparent",
            }}
          >
            {t("hero.titleHighlight")}
          </span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          variants={item}
          className="mt-6 max-w-2xl text-pretty text-base text-muted-foreground sm:text-lg"
        >
          {t("hero.subtitle")}
        </motion.p>

        {/* CTA row */}
        <motion.div
          variants={item}
          className="mt-8 flex flex-col items-center gap-3 sm:flex-row"
        >
          <button
            type="button"
            onClick={handlePrimary}
            className="group inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-5 text-sm font-semibold text-white shadow-md transition-all hover:shadow-lg hover:brightness-105"
          >
            {isAuthenticated ? t("hero.ctaStart") : t("hero.ctaGetStarted")}
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </button>
          <a
            href="#features"
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-card/60 px-5 text-sm font-medium text-foreground shadow-sm backdrop-blur-sm transition-colors hover:bg-accent/60"
          >
            <Play className="size-4 text-primary" />
            {t("hero.watchHow")}
          </a>
        </motion.div>

        {/* Stat pills */}
        <motion.div
          variants={item}
          className="mt-8 flex flex-wrap items-center justify-center gap-2 sm:gap-3"
        >
          {stats.map(({ label, icon: Icon }) => (
            <span
              key={label}
              className="glass inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium text-foreground shadow-sm sm:text-sm"
            >
              <Icon className="size-3.5 text-primary" />
              {label}
            </span>
          ))}
        </motion.div>

        {/* Scroll hint */}
        <motion.a
          href="#analyze"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="group mt-12 inline-flex flex-col items-center gap-2 text-xs text-muted-foreground transition-colors hover:text-foreground"
          aria-label={t("hero.scrollHint")}
        >
          <span className="uppercase tracking-widest">{t("hero.scrollHint")}</span>
          <motion.span
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            className="flex size-9 items-center justify-center rounded-full border border-border bg-card shadow-sm"
          >
            <ArrowDown className="size-4 text-primary" />
          </motion.span>
        </motion.a>
      </motion.div>
    </section>
  );
}

export default HeroSection;
