"use client";

// ============================================================================
// ReportView — orchestrator for the post-interview scorecard screen.
// Reads the report from the global store and renders the Scorecard.
// Provides navigation back to the dashboard and onward actions.
// ============================================================================

import { motion } from "framer-motion";
import { ArrowLeft, FileText, RotateCcw, Sparkles, Trophy } from "lucide-react";

import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Scorecard } from "@/components/report/Scorecard";

export function ReportView() {
  const report = useAppStore((s) => s.report);
  const analysis = useAppStore((s) => s.analysis);
  const setView = useAppStore((s) => s.setView);
  const resetInterview = useAppStore((s) => s.resetInterview);
  const { t } = useTranslation();

  function handleStartNew() {
    resetInterview();
    if (analysis) {
      setView("interview");
    } else {
      setView("landing");
    }
  }

  function handleAnalyzeNew() {
    setView("landing");
  }

  // ── Empty state ──────────────────────────────────────────────────────
  if (!report) {
    return (
      <div className="mx-auto flex w-full max-w-3xl flex-col items-center justify-center py-20 text-center">
        <Card className="w-full rounded-2xl p-10">
          <div className="flex flex-col items-center gap-4">
            <div className="flex size-14 items-center justify-center rounded-full bg-muted">
              <Trophy className="size-7 text-muted-foreground" />
            </div>
            <div className="space-y-1">
              <h2 className="text-xl font-semibold">{t("report.noReport")}</h2>
              <p className="text-sm text-muted-foreground">
                Complete a mock interview to generate your personalized scorecard.
              </p>
            </div>
            <Button
              variant="outline"
              onClick={() => setView("dashboard")}
              className="mt-2"
            >
              <ArrowLeft className="size-4" />
              {t("interview.backToDashboard")}
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  // ── Report present ──────────────────────────────────────────────────
  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-6 pb-10">
      {/* Top bar */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setView("dashboard")}
          className="-ml-2 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          <span className="hidden sm:inline">{t("report.back")}</span>
        </Button>
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-emerald-600 dark:text-emerald-400" />
          <h1 className="text-lg font-semibold tracking-tight">
            {t("report.title")}
          </h1>
        </div>
      </div>

      {/* Scorecard body */}
      <Scorecard report={report} />

      {/* Primary actions */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5, ease: "easeOut" }}
        className="flex flex-col gap-3 sm:flex-row sm:justify-center"
      >
        <Button
          size="lg"
          onClick={handleStartNew}
          className="bg-emerald-600 text-white shadow-sm hover:bg-emerald-700 dark:bg-emerald-600 dark:hover:bg-emerald-500"
        >
          <RotateCcw className="size-4" />
          {t("report.startNew")}
        </Button>
        <Button size="lg" variant="outline" onClick={handleAnalyzeNew}>
          <FileText className="size-4" />
          {t("report.analyzeNew")}
        </Button>
      </motion.div>
    </div>
  );
}

export default ReportView;
