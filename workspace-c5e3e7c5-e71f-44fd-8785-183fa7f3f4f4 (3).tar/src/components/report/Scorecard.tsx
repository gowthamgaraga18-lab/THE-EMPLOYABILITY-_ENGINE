"use client";

// ============================================================================
// Scorecard — the visual report card shown after a mock interview completes.
// Sections: verdict hero band · animated score bars · key takeaways · transcript
// ============================================================================

import { motion, type Variants } from "framer-motion";
import {
  AlertTriangle,
  Award,
  Check,
  MessageSquare,
  Plus,
  Star,
  ThumbsUp,
  Trophy,
  User,
} from "lucide-react";

import type { InterviewReport, Verdict } from "@/lib/types";
import type { TranslationKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/use-translation";
import { Badge } from "@/components/ui/badge";
import { Card, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

// ---------------------------------------------------------------------------
// Verdict theming (emerald for both hire verdicts, amber for "Needs Work")
// ---------------------------------------------------------------------------

type VerdictTheme = {
  band: string;
  iconWrap: string;
  iconColor: string;
  titleColor: string;
  icon: typeof Trophy;
  tagline: string;
};

const verdictConfig: Record<Verdict, VerdictTheme> = {
  "Strong Hire": {
    band: "bg-gradient-to-br from-emerald-50 via-emerald-50 to-teal-50 border-emerald-200/70 dark:from-emerald-950/40 dark:via-emerald-950/30 dark:to-teal-950/30 dark:border-emerald-800/40",
    iconWrap: "bg-emerald-100 dark:bg-emerald-900/50",
    iconColor: "text-emerald-600 dark:text-emerald-400",
    titleColor: "text-emerald-700 dark:text-emerald-300",
    icon: Trophy,
    tagline: "Top candidate — outstanding performance",
  },
  Hire: {
    band: "bg-gradient-to-br from-emerald-50/80 to-emerald-50/40 border-emerald-100 dark:from-emerald-950/30 dark:to-emerald-950/10 dark:border-emerald-900/30",
    iconWrap: "bg-emerald-50 dark:bg-emerald-900/40",
    iconColor: "text-emerald-500 dark:text-emerald-400",
    titleColor: "text-emerald-600 dark:text-emerald-300",
    icon: Award,
    tagline: "Solid candidate — recommended for the role",
  },
  "Needs Work": {
    band: "bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200/70 dark:from-amber-950/30 dark:to-orange-950/20 dark:border-amber-900/30",
    iconWrap: "bg-amber-100 dark:bg-amber-900/50",
    iconColor: "text-amber-600 dark:text-amber-400",
    titleColor: "text-amber-700 dark:text-amber-300",
    icon: AlertTriangle,
    tagline: "Not quite there — keep practicing",
  },
};

// ---------------------------------------------------------------------------
// Score helpers
// ---------------------------------------------------------------------------

function qualitativeLabel(score: number, t: (key: TranslationKey) => string): string {
  if (score >= 4) return t("report.excellent");
  if (score === 3) return t("report.solid");
  return t("report.needsImprovement");
}

function qualitativeColor(score: number): string {
  if (score >= 4) return "text-emerald-600 dark:text-emerald-400";
  if (score === 3) return "text-amber-600 dark:text-amber-400";
  return "text-rose-600 dark:text-rose-400";
}

type ScoreAccent = "emerald" | "teal";

const accentBar: Record<ScoreAccent, string> = {
  emerald: "bg-emerald-500 dark:bg-emerald-400",
  teal: "bg-teal-500 dark:bg-teal-400",
};
const accentTrack: Record<ScoreAccent, string> = {
  emerald: "bg-emerald-100 dark:bg-emerald-950/60",
  teal: "bg-teal-100 dark:bg-teal-950/60",
};
const accentStar: Record<ScoreAccent, string> = {
  emerald: "fill-emerald-500 text-emerald-500 dark:fill-emerald-400 dark:text-emerald-400",
  teal: "fill-teal-500 text-teal-500 dark:fill-teal-400 dark:text-teal-400",
};

/** Animated horizontal score bar — framer-motion animates width 0 → value on mount. */
function ScoreBar({ score, accent }: { score: number; accent: ScoreAccent }) {
  const pct = Math.max(0, Math.min(100, score * 20));
  return (
    <div
      className={cn(
        "relative h-2.5 w-full overflow-hidden rounded-full",
        accentTrack[accent]
      )}
    >
      <motion.div
        className={cn("h-full rounded-full", accentBar[accent])}
        initial={{ width: 0 }}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.9, ease: "easeOut", delay: 0.15 }}
      />
    </div>
  );
}

function StarRow({ score, accent }: { score: number; accent: ScoreAccent }) {
  return (
    <div className="flex items-center gap-0.5" aria-hidden="true">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={cn(
            "size-4",
            i < score
              ? accentStar[accent]
              : "text-muted-foreground/25"
          )}
        />
      ))}
    </div>
  );
}

function ScoreCard({
  title,
  icon,
  score,
  accent,
}: {
  title: string;
  icon: React.ReactNode;
  score: number;
  accent: ScoreAccent;
}) {
  const { t } = useTranslation();
  return (
    <Card className="rounded-2xl p-6 gap-0">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            {icon}
            <CardTitle className="text-base">{title}</CardTitle>
          </div>
          <p className={cn("text-sm font-medium", qualitativeColor(score))}>
            {qualitativeLabel(score, t)}
          </p>
        </div>
        <div className="text-right">
          <div className="text-4xl font-bold leading-none tracking-tight">
            {score}
            <span className="text-base font-normal text-muted-foreground">
              {" / 5"}
            </span>
          </div>
        </div>
      </div>
      <div className="mt-5 space-y-2.5">
        <ScoreBar score={score} accent={accent} />
        <StarRow score={score} accent={accent} />
      </div>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Framer-motion stagger orchestration
// ---------------------------------------------------------------------------

const container: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.12, delayChildren: 0.05 },
  },
};

const section: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

// ---------------------------------------------------------------------------
// Scorecard
// ---------------------------------------------------------------------------

export function Scorecard({ report }: { report: InterviewReport }) {
  const { t } = useTranslation();
  const cfg = verdictConfig[report.overall_verdict];
  const VerdictIcon = cfg.icon;

  const strengths = report.key_takeaways.filter((k) => k.type === "strength");
  const weaknesses = report.key_takeaways.filter((k) => k.type === "weakness");
  const transcript = report.transcript ?? [];

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="flex flex-col gap-6"
    >
      {/* ── Verdict hero band ──────────────────────────────────────────── */}
      <motion.div variants={section}>
        <Card className={cn("rounded-2xl overflow-hidden border", cfg.band)}>
          <div className="flex flex-col items-center gap-4 px-6 py-8 text-center sm:py-10">
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{
                type: "spring",
                stiffness: 180,
                damping: 14,
                delay: 0.1,
              }}
              className={cn(
                "flex size-16 items-center justify-center rounded-full shadow-sm",
                cfg.iconWrap
              )}
            >
              <VerdictIcon className={cn("size-9", cfg.iconColor)} />
            </motion.div>

            <div className="space-y-1.5">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
                {t("report.overallVerdict")}
              </p>
              <h2
                className={cn(
                  "text-4xl font-bold tracking-tight md:text-5xl",
                  cfg.titleColor
                )}
              >
                {report.overall_verdict}
              </h2>
              <p className="text-sm text-muted-foreground">{cfg.tagline}</p>
            </div>

            {report.summary ? (
              <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
                {report.summary}
              </p>
            ) : null}
          </div>
        </Card>
      </motion.div>

      {/* ── Score bars ─────────────────────────────────────────────────── */}
      <motion.div
        variants={section}
        className="grid grid-cols-1 gap-6 md:grid-cols-2"
      >
        <ScoreCard
          title={t("report.technicalDepth")}
          icon={<Star className="size-4 text-emerald-600 dark:text-emerald-400" />}
          score={report.technical_depth_score}
          accent="emerald"
        />
        <ScoreCard
          title={t("report.communication")}
          icon={
            <MessageSquare className="size-4 text-emerald-600 dark:text-emerald-400" />
          }
          score={report.communication_score}
          accent="teal"
        />
      </motion.div>

      {/* ── Key takeaways ──────────────────────────────────────────────── */}
      <motion.div
        variants={section}
        className="grid grid-cols-1 gap-6 md:grid-cols-2"
      >
        {/* Strengths */}
        <Card className="rounded-2xl p-6 gap-0">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/40">
              <ThumbsUp className="size-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <CardTitle className="text-base">{t("report.strengths")}</CardTitle>
            <Badge
              variant="secondary"
              className="ml-auto border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-900/40 dark:text-emerald-300"
            >
              {strengths.length}
            </Badge>
          </div>
          {strengths.length === 0 ? (
            <p className="text-sm italic text-muted-foreground">
              No specific takeaways.
            </p>
          ) : (
            <ul className="space-y-3">
              {strengths.map((s, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/40">
                    <Check className="size-3 text-emerald-600 dark:text-emerald-400" />
                  </span>
                  <span className="leading-relaxed">{s.text}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Areas to Improve */}
        <Card className="rounded-2xl p-6 gap-0">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40">
              <AlertTriangle className="size-4 text-amber-600 dark:text-amber-400" />
            </div>
            <CardTitle className="text-base">{t("report.areasToImprove")}</CardTitle>
            <Badge
              variant="secondary"
              className="ml-auto border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-800/40 dark:bg-amber-900/40 dark:text-amber-300"
            >
              {weaknesses.length}
            </Badge>
          </div>
          {weaknesses.length === 0 ? (
            <p className="text-sm italic text-muted-foreground">
              No specific takeaways.
            </p>
          ) : (
            <ul className="space-y-3">
              {weaknesses.map((w, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40">
                    <Plus className="size-3 text-amber-600 dark:text-amber-400" />
                  </span>
                  <span className="leading-relaxed">{w.text}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </motion.div>

      {/* ── Full transcript ───────────────────────────────────────────── */}
      <motion.div variants={section}>
        <Card className="rounded-2xl p-6 gap-0">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-muted">
              <MessageSquare className="size-4 text-muted-foreground" />
            </div>
            <CardTitle className="text-base">{t("report.transcript")}</CardTitle>
            <Badge variant="secondary" className="ml-auto">
              {transcript.length} {transcript.length === 1 ? "message" : "messages"}
            </Badge>
          </div>

          {transcript.length === 0 ? (
            <p className="text-sm italic text-muted-foreground">
              No transcript recorded.
            </p>
          ) : (
            <ScrollArea className="h-96 w-full rounded-lg">
              <div className="flex flex-col gap-3 pr-3">
                {transcript.map((m, i) => {
                  const isInterviewer = m.role === "interviewer";
                  return (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{
                        delay: Math.min(i * 0.035, 0.6),
                        duration: 0.3,
                        ease: "easeOut",
                      }}
                      className={cn(
                        "flex items-end gap-2",
                        isInterviewer ? "justify-start" : "justify-end"
                      )}
                    >
                      {isInterviewer ? (
                        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/40">
                          <User className="size-3.5 text-emerald-600 dark:text-emerald-400" />
                        </div>
                      ) : null}

                      <div
                        className={cn(
                          "max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
                          isInterviewer
                            ? "rounded-bl-md bg-emerald-50 text-emerald-950 dark:bg-emerald-900/30 dark:text-emerald-50"
                            : "rounded-br-md bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-100"
                        )}
                      >
                        <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide opacity-60">
                          {isInterviewer ? "Interviewer" : "You"}
                        </p>
                        <p className="whitespace-pre-wrap">{m.content}</p>
                      </div>

                      {!isInterviewer ? (
                        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800">
                          <User className="size-3.5 text-slate-500 dark:text-slate-300" />
                        </div>
                      ) : null}
                    </motion.div>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </Card>
      </motion.div>
    </motion.div>
  );
}

export default Scorecard;
