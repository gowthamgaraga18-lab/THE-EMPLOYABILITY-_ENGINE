"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Sun, Moon } from "lucide-react";
import { useTheme } from "@/lib/use-theme";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
  size?: "sm" | "md";
}

/**
 * ThemeToggle — animated sun/moon button that switches between day & night.
 */
export function ThemeToggle({ className, size = "md" }: ThemeToggleProps) {
  const { theme, toggleTheme, mounted } = useTheme();
  const isDark = theme === "dark";

  const dim = size === "sm" ? "size-4" : "size-5";
  const box = size === "sm" ? "size-8" : "size-9";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      aria-pressed={isDark}
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className={cn(
        "relative flex items-center justify-center rounded-lg border border-border bg-card/60 text-foreground transition-colors hover:bg-accent/60",
        box,
        className,
      )}
    >
      {/* Render both icons; AnimatePresence swaps them for a smooth morph. */}
      {mounted ? (
        <AnimatePresence mode="wait" initial={false}>
          {isDark ? (
            <motion.span
              key="moon"
              initial={{ rotate: -90, scale: 0, opacity: 0 }}
              animate={{ rotate: 0, scale: 1, opacity: 1 }}
              exit={{ rotate: 90, scale: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="text-amber-400"
            >
              <Moon className={dim} />
            </motion.span>
          ) : (
            <motion.span
              key="sun"
              initial={{ rotate: 90, scale: 0, opacity: 0 }}
              animate={{ rotate: 0, scale: 1, opacity: 1 }}
              exit={{ rotate: -90, scale: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="text-amber-500"
            >
              <Sun className={dim} />
            </motion.span>
          )}
        </AnimatePresence>
      ) : (
        // Placeholder before mount to avoid hydration mismatch.
        <Sun className={cn(dim, "text-amber-500 opacity-0")} />
      )}

      {/* Subtle glow ring on hover */}
      <span
        aria-hidden
        className={cn(
          "pointer-events-none absolute inset-0 rounded-lg transition-opacity",
          isDark
            ? "bg-violet-500/10 opacity-0 hover:opacity-100"
            : "bg-amber-400/10 opacity-0 hover:opacity-100",
        )}
      />
    </button>
  );
}

export default ThemeToggle;
