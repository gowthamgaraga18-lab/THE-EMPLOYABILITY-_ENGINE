"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Globe, Check, ChevronDown } from "lucide-react";
import { useTranslation } from "@/lib/use-translation";
import { cn } from "@/lib/utils";

interface LanguageToggleProps {
  size?: "sm" | "md";
  className?: string;
}

/**
 * LanguageToggle — a dropdown to switch the app language.
 * Shows a globe icon + current language flag; opens a menu of all languages.
 */
export function LanguageToggle({ size = "md", className }: LanguageToggleProps) {
  const { language, setLanguage, languages, currentInfo } = useTranslation();
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Click-outside + Escape handler.
  useEffect(() => {
    if (!open) return;
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, [open]);

  const iconSize = size === "sm" ? "size-4" : "size-4.5";
  const boxSize = size === "sm" ? "size-8 gap-1" : "size-9 gap-1.5";

  return (
    <div className={cn("relative", className)} ref={menuRef}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Change language"
        aria-expanded={open}
        aria-haspopup="listbox"
        title={currentInfo.label}
        className={cn(
          "flex items-center rounded-lg border border-border bg-card/60 text-foreground transition-colors hover:bg-accent/60",
          boxSize,
        )}
      >
        <Globe className={iconSize} />
        <span className="text-sm leading-none">{currentInfo.flag}</span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.96 }}
            transition={{ duration: 0.16, ease: "easeOut" }}
            role="listbox"
            className="glass-strong absolute right-0 top-full z-50 mt-2 w-52 overflow-hidden rounded-xl border border-border shadow-xl"
          >
            <div className="border-b border-border px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Select Language
            </div>
            <div className="max-h-72 overflow-y-auto scrollbar-thin">
              {languages.map((lang) => {
                const active = lang.code === language;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    role="option"
                    aria-selected={active}
                    onClick={() => {
                      setLanguage(lang.code);
                      setOpen(false);
                    }}
                    className={cn(
                      "flex w-full items-center gap-3 px-3 py-2.5 text-sm transition-colors",
                      active
                        ? "bg-primary/10 font-medium text-primary"
                        : "text-foreground hover:bg-accent/60",
                    )}
                  >
                    <span className="text-base leading-none">{lang.flag}</span>
                    <span className="flex-1 text-left">{lang.label}</span>
                    {active && <Check className="size-4 text-primary" />}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default LanguageToggle;
