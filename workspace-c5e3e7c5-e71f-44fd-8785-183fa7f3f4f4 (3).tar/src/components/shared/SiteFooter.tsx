"use client";

import { Sparkles, Github, Heart } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border bg-card/40">
      <div className="mx-auto flex w-full max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6 lg:px-8">
        <div className="flex items-center gap-1.5">
          <Sparkles className="size-3.5 text-primary" />
          <span className="font-medium text-foreground">
            The Employability Engine
          </span>
          <span className="text-muted-foreground/70">
            &middot; AI-powered career copilot
          </span>
        </div>
        <div className="flex items-center gap-4">
          <a
            href="#"
            className="flex items-center gap-1.5 transition-colors hover:text-foreground"
          >
            <Github className="size-3.5" />
            Source
          </a>
          <span className="flex items-center gap-1">
            Built with <Heart className="size-3 fill-rose-500 text-rose-500" /> for
            hackathons
          </span>
        </div>
      </div>
    </footer>
  );
}
