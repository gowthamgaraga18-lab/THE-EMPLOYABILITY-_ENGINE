"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import type { AppView } from "@/lib/types";
import {
  Sparkles,
  Menu,
  X,
  FileSearch,
  LayoutDashboard,
  Mic,
  Award,
  LogOut,
  ChevronDown,
  LayoutGrid,
  History,
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageToggle } from "./LanguageToggle";
import { useTranslation } from "@/lib/use-translation";

const NAV_ITEMS = [
  { id: "landing", labelKey: "nav.analyze", icon: FileSearch },
  { id: "dashboard", labelKey: "nav.dashboard", icon: LayoutDashboard },
  { id: "interview", labelKey: "nav.interview", icon: Mic },
  { id: "history", labelKey: "nav.history", icon: History },
  { id: "report", labelKey: "nav.report", icon: Award },
] as const;

export function TopNav() {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const isAuthenticated = useAppStore((s) => s.isAuthenticated);
  const user = useAppStore((s) => s.user);
  const logout = useAppStore((s) => s.logout);
  const { t } = useTranslation();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Click-outside handler for the user dropdown.
  useEffect(() => {
    if (!menuOpen) return;
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") setMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, [menuOpen]);

  const handleNav = (id: AppView) => {
    setView(id);
    setMobileOpen(false);
  };

  const initial = (user?.name?.trim()?.[0] ?? "?").toUpperCase();

  return (
    <header
      className="glass-strong sticky top-0 z-50 h-16 border-b border-border"
      style={{ borderRadius: 0 }}
    >
      <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* ---------------------------------------------------------------- */}
        {/* Brand */}
        {/* ---------------------------------------------------------------- */}
        <button
          type="button"
          onClick={() => handleNav("landing")}
          className="flex shrink-0 items-center gap-2.5 transition-opacity hover:opacity-90"
          aria-label="Go to home"
        >
          <span className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
            <Sparkles className="size-5" />
          </span>
          <span className="flex flex-col items-start leading-none">
            <span className="text-sm font-bold tracking-tight text-foreground">
              {t("nav.brand")}
            </span>
            <span className="hidden text-[10px] text-muted-foreground sm:block">
              {t("nav.tagline")}
            </span>
          </span>
        </button>

        {/* ---------------------------------------------------------------- */}
        {/* Desktop nav (md+) */}
        {/* ---------------------------------------------------------------- */}
        <nav className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map((item) => {
            const active = view === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={cn(
                  "relative flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  active
                    ? "text-white"
                    : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                {active && (
                  <motion.span
                    layoutId="nav-active-pill"
                    className="absolute inset-0 -z-10 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 shadow-sm"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <Icon className="size-4" />
                {t(item.labelKey)}
              </button>
            );
          })}
        </nav>

        {/* ---------------------------------------------------------------- */}
        {/* Desktop right (md+): theme + auth */}
        {/* ---------------------------------------------------------------- */}
        <div className="hidden items-center gap-2 md:flex">
          <ThemeToggle />
          <LanguageToggle />

          {isAuthenticated && user ? (
            <div className="relative" ref={menuRef}>
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-full border border-border bg-card/60 py-1 pl-1 pr-2 transition-colors hover:bg-accent/60"
                aria-expanded={menuOpen}
                aria-haspopup="menu"
                aria-label="Open user menu"
              >
                <span className="flex size-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-xs font-bold text-white">
                  {initial}
                </span>
                <ChevronDown
                  className={cn(
                    "size-3.5 text-muted-foreground transition-transform",
                    menuOpen && "rotate-180",
                  )}
                />
              </button>

              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -6, scale: 0.96 }}
                    transition={{ duration: 0.16, ease: "easeOut" }}
                    role="menu"
                    className="glass-strong absolute right-0 top-full mt-2 w-64 overflow-hidden rounded-xl border border-border shadow-xl"
                  >
                    <div className="flex items-center gap-3 border-b border-border p-3">
                      <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-sm font-bold text-white">
                        {initial}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-foreground">
                          {user.name}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {user.email}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        setView("dashboard");
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground"
                    >
                      <LayoutGrid className="size-4" />
                      {t("nav.goDashboard")}
                    </button>
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        setView("history");
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground"
                    >
                      <History className="size-4" />
                      Job Trail History
                    </button>
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        logout();
                      }}
                      className="flex w-full items-center gap-2 border-t border-border px-3 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      <LogOut className="size-4" />
                      {t("nav.logout")}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setView("login")}
                className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground"
              >
                {t("nav.login")}
              </button>
              <button
                type="button"
                onClick={() => setView("signup")}
                className="rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm transition-all hover:shadow-md hover:brightness-105"
              >
                {t("nav.signup")}
              </button>
            </>
          )}
        </div>

        {/* ---------------------------------------------------------------- */}
        {/* Mobile toggle */}
        {/* ---------------------------------------------------------------- */}
        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle size="sm" />
          <LanguageToggle size="sm" />
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            className="flex size-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* Mobile menu */}
      {/* ---------------------------------------------------------------- */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="glass-strong overflow-hidden border-t border-border md:hidden"
            style={{ borderRadius: 0 }}
          >
            <div className="mx-auto flex w-full max-w-7xl flex-col gap-1 px-4 py-3">
              {NAV_ITEMS.map((item) => {
                const active = view === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNav(item.id)}
                    className={cn(
                      "flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      active
                        ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-sm"
                        : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                    )}
                  >
                    <Icon className="size-4" />
                    {t(item.labelKey)}
                  </button>
                );
              })}

              <div className="my-2 h-px bg-border" />

              {isAuthenticated && user ? (
                <>
                  <div className="flex items-center gap-3 rounded-lg px-3 py-2">
                    <span className="flex size-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-xs font-bold text-white">
                      {initial}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-foreground">
                        {user.name}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {user.email}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      logout();
                      setMobileOpen(false);
                    }}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  >
                    <LogOut className="size-4" />
                    {t("nav.logout")}
                  </button>
                </>
              ) : (
                <div className="flex flex-col gap-2 px-1">
                  <button
                    type="button"
                    onClick={() => handleNav("login")}
                    className="rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-accent/60"
                  >
                    {t("nav.login")}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNav("signup")}
                    className="rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 px-3 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:shadow-md hover:brightness-105"
                  >
                    {t("nav.signup")}
                  </button>
                </div>
              )}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

export default TopNav;
