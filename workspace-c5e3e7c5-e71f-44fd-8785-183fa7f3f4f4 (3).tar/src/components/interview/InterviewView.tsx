"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  ArrowLeft,
  Mic,
  Square,
  Loader2,
  Volume2,
  Sparkles,
  AlertCircle,
  Radio,
  Keyboard,
  Send,
  X,
  Clock,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { AudioVisualizer } from "./AudioVisualizer";
import { LiveTranscript } from "./LiveTranscript";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { cn } from "@/lib/utils";
import { audioBlobToWav } from "@/lib/audio-utils";

const TTS_MAX_CHARS = 900;
const MAX_QUESTIONS = 8;

export function InterviewView() {
  const analysis = useAppStore((s) => s.analysis);
  const interviewMessages = useAppStore((s) => s.interviewMessages);
  const currentQuestion = useAppStore((s) => s.currentQuestion);
  const isInterviewThinking = useAppStore((s) => s.isInterviewThinking);
  const interviewTargetRole = useAppStore((s) => s.interviewTargetRole);
  const isBuildingReport = useAppStore((s) => s.isBuildingReport);
  const setInterview = useAppStore((s) => s.setInterview);
  const addInterviewMessage = useAppStore((s) => s.addInterviewMessage);
  const resetInterview = useAppStore((s) => s.resetInterview);
  const setView = useAppStore((s) => s.setView);
  const setIsBuildingReport = useAppStore((s) => s.setIsBuildingReport);
  const setReport = useAppStore((s) => s.setReport);
  const setError = useAppStore((s) => s.setError);
  const updateTrailStatus = useAppStore((s) => s.updateTrailStatus);
  const { t } = useTranslation();

  // ----- audio refs -----
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const currentUrlRef = useRef<string | null>(null);
  const rafRef = useRef<number | null>(null);

  const startedRef = useRef(false);

  // ----- local UI state -----
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [showTextInput, setShowTextInput] = useState(false);
  const [textAnswer, setTextAnswer] = useState("");
  const [isConverting, setIsConverting] = useState(false);

  const supported =
    typeof window !== "undefined" &&
    typeof window.MediaRecorder !== "undefined" &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.getUserMedia === "function";

  // ----- recording timer -----
  useEffect(() => {
    if (!isRecording) {
      setRecordSeconds(0);
      return;
    }
    const t = setInterval(() => setRecordSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [isRecording]);

  const formatTime = (s: number) =>
    `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  // -------------------------------------------------------------------------
  // playTts
  // -------------------------------------------------------------------------
  const playTts = useCallback(async (text: string) => {
    if (!text) return;
    const safeText = text.length > TTS_MAX_CHARS ? text.slice(0, TTS_MAX_CHARS) : text;
    const audio = audioElRef.current;
    if (!audio) return;
    try {
      audio.pause();
    } catch {}
    audio.onended = null;
    audio.onerror = null;
    if (currentUrlRef.current) {
      URL.revokeObjectURL(currentUrlRef.current);
      currentUrlRef.current = null;
    }
    setIsPlayingAudio(true);
    try {
      const res = await fetch("/api/interview/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: safeText }),
      });
      if (!res.ok) throw new Error("TTS request failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      currentUrlRef.current = url;
      audio.src = url;
      audio.playbackRate = 1;
      audio.onended = () => {
        setIsPlayingAudio(false);
        if (currentUrlRef.current) {
          URL.revokeObjectURL(currentUrlRef.current);
          currentUrlRef.current = null;
        }
      };
      audio.onerror = () => {
        setIsPlayingAudio(false);
        if (currentUrlRef.current) {
          URL.revokeObjectURL(currentUrlRef.current);
          currentUrlRef.current = null;
        }
      };
      try {
        await audio.play();
      } catch {
        setIsPlayingAudio(false);
      }
    } catch {
      setIsPlayingAudio(false);
    }
  }, []);

  // -------------------------------------------------------------------------
  // finishInterview
  // -------------------------------------------------------------------------
  const finishInterview = async () => {
    setInterview({ isThinking: false, isActive: false });
    setIsBuildingReport(true);
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) {
      setIsBuildingReport(false);
      setError("No analysis found.");
      return;
    }
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    try {
      const res = await fetch("/api/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRole, missingSkills, transcript }),
      });
      if (!res.ok) throw new Error("Failed to build report.");
      const data = await res.json();
      setReport(data.report);
      // Update the job trail status: "cracked" if Strong Hire / Hire, else "failed".
      const verdict = data.report.overall_verdict as string;
      const cracked = verdict === "Strong Hire" || verdict === "Hire";
      const mode = state.interviewMode;
      void updateTrailStatus(cracked ? "cracked" : "failed", verdict, mode);
      setView("report");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to build report.";
      setError(msg);
      toast.error(msg);
    } finally {
      setIsBuildingReport(false);
    }
  };

  // -------------------------------------------------------------------------
  // submitAnswer — now accepts a WAV blob directly.
  // -------------------------------------------------------------------------
  const submitAnswer = async (wavBlob: Blob) => {
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) {
      setError("No analysis found.");
      return;
    }
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    const currentQ = state.currentQuestion;
    const questionsAsked = transcript.filter((m) => m.role === "interviewer").length;

    setInterview({ isThinking: true });
    try {
      const fd = new FormData();
      const file = new File([wavBlob], "answer.wav", { type: "audio/wav" });
      fd.append("audio", file);
      fd.append("meta", JSON.stringify({ targetRole, missingSkills, transcript, questionsAsked, currentQuestion: currentQ }));

      const res = await fetch("/api/interview/respond", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Failed to process your answer.");
      const data = await res.json();

      addInterviewMessage({ role: "candidate", content: data.transcript || "(no speech detected)", timestamp: Date.now() });

      if (data.isFinal) {
        await finishInterview();
      } else {
        setInterview({ currentQuestion: data.question, isThinking: false });
        addInterviewMessage({ role: "interviewer", content: data.question, timestamp: Date.now() });
        void playTts(data.question);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to process your answer.";
      setInterview({ isThinking: false });
      setError(msg);
      toast.error(msg);
    }
  };

  // -------------------------------------------------------------------------
  // submitTextAnswer — fallback for users without a mic.
  // -------------------------------------------------------------------------
  const submitTextAnswer = async () => {
    const answer = textAnswer.trim();
    if (!answer) return;
    setShowTextInput(false);
    setTextAnswer("");
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) return;
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    const currentQ = state.currentQuestion;
    const questionsAsked = transcript.filter((m) => m.role === "interviewer").length;

    setInterview({ isThinking: true });
    try {
      const fd = new FormData();
      fd.append("meta", JSON.stringify({ targetRole, missingSkills, transcript, questionsAsked, currentQuestion: currentQ }));
      // Send an empty 1-sample WAV so the multipart parser is happy, and
      // inject the text answer via a dedicated field.
      const emptyWav = new Blob([makeEmptyWav()], { type: "audio/wav" });
      fd.append("audio", emptyWav, "empty.wav");
      fd.append("textAnswer", answer);

      const res = await fetch("/api/interview/respond", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Failed to process your answer.");
      const data = await res.json();

      addInterviewMessage({ role: "candidate", content: data.transcript || answer, timestamp: Date.now() });

      if (data.isFinal) {
        await finishInterview();
      } else {
        setInterview({ currentQuestion: data.question, isThinking: false });
        addInterviewMessage({ role: "interviewer", content: data.question, timestamp: Date.now() });
        void playTts(data.question);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to process your answer.";
      setInterview({ isThinking: false });
      setError(msg);
      toast.error(msg);
    }
  };

  // -------------------------------------------------------------------------
  // startRecording
  // -------------------------------------------------------------------------
  const startRecording = async () => {
    if (isRecording || isInterviewThinking || isPlayingAudio || isBuildingReport) return;
    if (!supported) {
      setMicError(t("interview.browserNotSupported"));
      return;
    }
    setMicError(null);
    if (audioElRef.current) audioElRef.current.pause();
    setIsPlayingAudio(false);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const w = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
      const AudioCtx = w.AudioContext || w.webkitAudioContext;
      if (!AudioCtx) throw new Error("Web Audio API is not supported in this browser.");
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyserNode = ctx.createAnalyser();
      analyserNode.fftSize = 2048;
      source.connect(analyserNode);
      analyserRef.current = analyserNode;
      setAnalyser(analyserNode);

      let mimeType = "";
      const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"];
      for (const c of candidates) {
        try {
          if (MediaRecorder.isTypeSupported(c)) { mimeType = c; break; }
        } catch {}
      }
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        const chunksBlob = new Blob(audioChunksRef.current, { type: recorder.mimeType || mimeType || "audio/webm" });
        audioChunksRef.current = [];
        setIsRecording(false);

        audioStreamRef.current?.getTracks().forEach((t) => t.stop());
        audioStreamRef.current = null;
        if (audioContextRef.current) {
          audioContextRef.current.close().catch(() => {});
          audioContextRef.current = null;
        }
        analyserRef.current = null;
        setAnalyser(null);

        // ---- KEY FIX: convert webm/opus → WAV before sending to ASR ----
        setIsConverting(true);
        try {
          const { wav } = await audioBlobToWav(chunksBlob, 16000);
          await submitAnswer(wav);
        } catch (convErr) {
          console.error("Audio conversion failed, sending raw webm:", convErr);
          toast.error("Could not process audio. Please try again or use the text input option.");
          setInterview({ isThinking: false });
        } finally {
          setIsConverting(false);
        }
      };
      recorder.onerror = () => {
        setIsRecording(false);
        setMicError("Recording failed. Please try again or use the text input option.");
        audioStreamRef.current?.getTracks().forEach((t) => t.stop());
        audioStreamRef.current = null;
        if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
        analyserRef.current = null;
        setAnalyser(null);
      };

      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      recorder.start();
      setIsRecording(true);
    } catch (err) {
      if (err instanceof DOMException) {
        if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
          setMicError("Microphone permission denied. Please allow mic access, or use the text input option below.");
        } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
          setMicError("No microphone found. Connect a microphone, or use the text input option below.");
        } else if (err.name === "NotReadableError" || err.name === "TrackStartError") {
          setMicError("Microphone is in use by another app. Close it, or use the text input option below.");
        } else {
          setMicError(err.message || "Could not access microphone. Use the text input option below.");
        }
      } else {
        setMicError(err instanceof Error ? err.message : "Could not access microphone. Use the text input option below.");
      }
      audioStreamRef.current?.getTracks().forEach((t) => t.stop());
      audioStreamRef.current = null;
    }
  };

  const stopRecording = () => {
    const rec = mediaRecorderRef.current;
    if (!rec || rec.state === "inactive") return;
    try { rec.stop(); } catch {}
  };

  // -------------------------------------------------------------------------
  // Mount: kick off the interview
  // -------------------------------------------------------------------------
  useEffect(() => {
    if (startedRef.current) return;
    if (!analysis) return;
    startedRef.current = true;
    (async () => {
      setIsStarting(true);
      setInterview({ targetRole: analysis.target_role, isActive: true });
      try {
        const res = await fetch("/api/interview/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ targetRole: analysis.target_role, missingSkills: analysis.missing_skills }),
        });
        if (!res.ok) throw new Error("Failed to start interview.");
        const data = await res.json();
        setInterview({ targetRole: analysis.target_role, currentQuestion: data.question, isActive: true });
        addInterviewMessage({ role: "interviewer", content: data.question, timestamp: Date.now() });
        void playTts(data.question);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed to start interview.";
        setError(msg);
        toast.error(msg);
      } finally {
        setIsStarting(false);
      }
    })();
  }, [analysis, setInterview, addInterviewMessage, setError, playTts]);

  const teardownAudio = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      try { mediaRecorderRef.current.stop(); } catch {}
    }
    audioStreamRef.current?.getTracks().forEach((t) => t.stop());
    audioStreamRef.current = null;
    if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
    if (audioElRef.current) audioElRef.current.pause();
    if (currentUrlRef.current) { URL.revokeObjectURL(currentUrlRef.current); currentUrlRef.current = null; }
    analyserRef.current = null;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
  }, []);

  useEffect(() => () => teardownAudio(), [teardownAudio]);

  const handleBack = () => {
    teardownAudio();
    setIsRecording(false);
    setIsPlayingAudio(false);
    resetInterview();
    setView("dashboard");
  };

  const interviewerCount = interviewMessages.filter((m) => m.role === "interviewer").length;
  const candidateCount = interviewMessages.filter((m) => m.role === "candidate").length;
  const progressPct = Math.min(100, Math.round((interviewerCount / MAX_QUESTIONS) * 100));

  const statusInfo = (() => {
    if (isBuildingReport) return { label: t("interview.buildingReport"), icon: <Loader2 className="size-3 animate-spin" />, cls: "border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300" };
    if (isConverting) return { label: t("interview.processing"), icon: <Loader2 className="size-3 animate-spin" />, cls: "border-sky-200 bg-sky-100 text-sky-700 dark:border-sky-800/40 dark:bg-sky-950/40 dark:text-sky-300" };
    if (isInterviewThinking) return { label: t("interview.thinking"), icon: <Loader2 className="size-3 animate-spin" />, cls: "border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300" };
    if (isRecording) return { label: t("interview.recording"), icon: <span className="size-2 animate-pulse rounded-full bg-rose-500" />, cls: "border-rose-200 bg-rose-100 text-rose-700 dark:border-rose-800/40 dark:bg-rose-950/40 dark:text-rose-300" };
    if (isPlayingAudio) return { label: t("interview.speaking"), icon: <Volume2 className="size-3" />, cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300" };
    if (isStarting) return { label: t("interview.starting"), icon: <Loader2 className="size-3 animate-spin" />, cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300" };
    return { label: t("interview.listening"), icon: <Radio className="size-3" />, cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300" };
  })();

  if (!analysis) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 text-center">
        <Card className="w-full p-8">
          <AlertCircle className="mx-auto size-10 text-rose-500" />
          <p className="mt-3 text-lg font-semibold">{t("interview.noAnalysis")}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("interview.noAnalysisDesc")}
          </p>
          <Button onClick={() => setView("dashboard")} className="mt-4">
            <ArrowLeft className="size-4" /> {t("interview.backToDashboard")}
          </Button>
        </Card>
      </div>
    );
  }

  const micDisabled = isInterviewThinking || isPlayingAudio || isBuildingReport || isStarting || isConverting || isRecording;
  const replayDisabled = isRecording || isPlayingAudio || isInterviewThinking || isBuildingReport || !currentQuestion;

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
      {/* Top bar */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={handleBack} className="gap-1.5 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-4" /> {t("interview.back")}
          </Button>
          <div className="h-6 w-px bg-border" />
          <div className="flex flex-col">
            <h1 className="text-lg font-semibold tracking-tight sm:text-xl">{t("interview.title")}</h1>
            <p className="text-xs text-muted-foreground">{t("interview.subtitle")}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {interviewTargetRole && (
            <Badge variant="secondary" className="hidden max-w-[200px] truncate text-xs sm:inline-flex">
              {interviewTargetRole}
            </Badge>
          )}
          <Badge variant="outline" className={cn("gap-1.5", statusInfo.cls)}>
            {statusInfo.icon}
            <span>{statusInfo.label}</span>
          </Badge>
        </div>
      </header>

      {/* Progress bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{t("interview.question")} {interviewerCount} {t("interview.questionOf")} ~{MAX_QUESTIONS}</span>
          <span>{candidateCount} {t("interview.answersSubmitted")}</span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600"
            initial={{ width: 0 }}
            animate={{ width: `${progressPct}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        </div>
      </div>

      {/* Center interview card */}
      <Card className="relative overflow-hidden rounded-2xl p-6 sm:p-8">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
              <Sparkles className="size-4" />
            </div>
            <span className="text-sm font-medium">{t("interview.interviewer")}</span>
          </div>
          <Badge variant="outline" className="text-xs">Q{interviewerCount}</Badge>
        </div>

        {/* Current question */}
        <div className="mb-6 flex min-h-[130px] items-start gap-3 rounded-xl border border-emerald-200/60 bg-emerald-50/70 p-5 dark:border-emerald-800/40 dark:bg-emerald-950/20">
          {isInterviewThinking ? (
            <div className="flex w-full items-center gap-3 text-emerald-700 dark:text-emerald-400">
              <Loader2 className="size-5 shrink-0 animate-spin" />
              <span className="text-base font-medium sm:text-lg">{t("interview.thinking")}</span>
              <div className="ml-1 flex items-center gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.span key={i} className="size-1.5 rounded-full bg-emerald-500"
                    animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }}
                    transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }}
                  />
                ))}
              </div>
            </div>
          ) : (
            <>
              <Volume2 className={cn("mt-0.5 size-5 shrink-0", isPlayingAudio ? "animate-pulse text-emerald-600" : "text-emerald-500/70")} />
              <p className="text-lg font-medium leading-relaxed sm:text-xl">
                {currentQuestion || (isStarting ? "Preparing your first question…" : "Your question will appear here.")}
              </p>
            </>
          )}
        </div>

        {/* Waveform visualizer + timer */}
        <div className="mb-6 space-y-2">
          <div className="rounded-xl border bg-muted/40 p-3 dark:bg-muted/20">
            <AudioVisualizer analyser={analyser} active={isRecording} />
          </div>
          {isRecording && (
            <div className="flex items-center justify-center gap-2 text-sm font-medium text-rose-600">
              <Clock className="size-4" />
              <span className="tabular-nums">{formatTime(recordSeconds)}</span>
              <span className="text-muted-foreground">· {t("interview.recording")}</span>
            </div>
          )}
          {isConverting && (
            <div className="flex items-center justify-center gap-2 text-sm font-medium text-sky-600">
              <Loader2 className="size-4 animate-spin" />
              <span>Converting audio for transcription…</span>
            </div>
          )}
        </div>

        {/* Mic button + controls */}
        {!showTextInput && (
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={isRecording ? stopRecording : startRecording}
              disabled={micDisabled}
              aria-label={isRecording ? t("interview.stop") : t("interview.record")}
              className={cn(
                "relative flex size-20 items-center justify-center rounded-full shadow-lg transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-500/30 disabled:cursor-not-allowed disabled:opacity-50",
                isRecording ? "bg-rose-500 text-white shadow-rose-500/40 hover:bg-rose-600" : "bg-emerald-600 text-white shadow-emerald-600/40 hover:bg-emerald-700",
              )}
            >
              {isRecording ? <Square className="size-7" fill="currentColor" /> : <Mic className="size-8" />}
              {isRecording && <span className="absolute inset-0 animate-ping rounded-full ring-4 ring-rose-400/40" />}
            </button>
            <p className="text-sm font-semibold">{isRecording ? t("interview.stop") : t("interview.record")}</p>
            <p className="max-w-md text-center text-xs text-muted-foreground">
              {t("interview.recordHint")}
            </p>

            <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
              <Button variant="outline" size="sm" onClick={() => playTts(currentQuestion)} disabled={replayDisabled}>
                <Volume2 className="size-4" /> {t("interview.replay")}
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setShowTextInput(true)} disabled={isInterviewThinking || isBuildingReport || isPlayingAudio}>
                <Keyboard className="size-4" /> {t("interview.typeInstead")}
              </Button>
            </div>

            {micError && (
              <div className="mt-3 flex w-full max-w-md items-start gap-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300">
                <AlertCircle className="mt-0.5 size-4 shrink-0" />
                <span className="flex-1">{micError}</span>
                <Button variant="ghost" size="sm" className="h-7 shrink-0 px-2" onClick={() => { setMicError(null); void startRecording(); }}>
                  Retry
                </Button>
              </div>
            )}
            {!supported && !micError && (
              <p className="mt-2 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-center text-xs text-amber-700 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
                {t("interview.browserNotSupported")}
              </p>
            )}
          </div>
        )}

        {/* Text input fallback */}
        {showTextInput && (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{t("interview.typeAnswer")}</span>
              <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground" onClick={() => { setShowTextInput(false); setTextAnswer(""); }}>
                <X className="size-4" /> {t("interview.cancel")}
              </Button>
            </div>
            <Textarea
              value={textAnswer}
              onChange={(e) => setTextAnswer(e.target.value)}
              placeholder="Type your answer to the interviewer's question here…"
              className="min-h-[120px] resize-y"
              autoFocus
            />
            <Button
              onClick={() => void submitTextAnswer()}
              disabled={!textAnswer.trim() || isInterviewThinking || isBuildingReport}
              className="gap-2"
            >
              <Send className="size-4" /> {t("interview.submit")}
            </Button>
          </div>
        )}

        {/* Building report overlay */}
        <AnimatePresence>
          {isBuildingReport && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-background/85 p-6 backdrop-blur-sm"
            >
              <Loader2 className="size-12 animate-spin text-emerald-600" />
              <p className="text-lg font-semibold">{t("interview.buildingReport")}</p>
              <p className="max-w-xs text-center text-sm text-muted-foreground">
                {t("interview.buildingReportDesc")}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {/* Live transcript */}
      <LiveTranscript messages={interviewMessages} thinking={isInterviewThinking} />

      <audio ref={audioElRef} className="hidden" />
    </div>
  );
}

// Minimal valid WAV (1 sample of silence) for the text-fallback path.
function makeEmptyWav(): ArrayBuffer {
  const ab = new ArrayBuffer(44 + 2);
  const view = new DataView(ab);
  const sr = 16000;
  writeStr(view, 0, "RIFF");
  view.setUint32(4, 36 + 2, true);
  writeStr(view, 8, "WAVE");
  writeStr(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sr, true);
  view.setUint32(28, sr * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(view, 36, "data");
  view.setUint32(40, 2, true);
  view.setInt16(44, 0, true);
  return ab;
}
function writeStr(view: DataView, offset: number, str: string) {
  for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
}
