"use client";

import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface AudioVisualizerProps {
  /** Web Audio analyser node from the live mic stream (null when not recording). */
  analyser: AnalyserNode | null;
  /** True only while actively recording. Drives the rose stroke + glow. */
  active: boolean;
}

/**
 * AudioVisualizer — canvas-based waveform driven by an AnalyserNode.
 *
 * - When `active && analyser`, runs a requestAnimationFrame loop that pulls
 *   `getByteTimeDomainData` and draws a centered waveform in ROSE (recording).
 * - When idle (no analyser / not active), draws a subtle flat emerald line.
 * - A pulsing rose glow is rendered behind the canvas while active.
 * - The canvas is responsive (`w-full h-24`) and uses devicePixelRatio for
 *   crisp rendering on retina displays.
 */
export function AudioVisualizer({ analyser, active }: AudioVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const activeRef = useRef(active);
  const analyserRef = useRef<AnalyserNode | null>(analyser);

  // Keep refs in sync so the RAF loop reads the latest values without
  // needing to be torn down and recreated on every prop change.
  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  useEffect(() => {
    analyserRef.current = analyser;
  }, [analyser]);

  // Resize the canvas backing store to match its displayed size (with DPR).
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(1, Math.floor(rect.width * dpr));
      const h = Math.max(1, Math.floor(rect.height * dpr));
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    return () => ro.disconnect();
  }, []);

  // Drawing loop — runs once for the component's lifetime.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const drawIdle = () => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = "oklch(0.55 0.14 162 / 0.4)";
      ctx.beginPath();
      ctx.moveTo(0, h / 2);
      ctx.lineTo(w, h / 2);
      ctx.stroke();
    };

    const drawWaveform = (data: Uint8Array) => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);
      ctx.lineWidth = 2.5;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      // Rose stroke while actively recording.
      ctx.strokeStyle = "oklch(0.62 0.22 22)";
      ctx.beginPath();
      const sliceWidth = w / data.length;
      let x = 0;
      for (let i = 0; i < data.length; i++) {
        const v = data[i] / 128.0;
        const y = (v * h) / 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.stroke();
    };

    const tick = () => {
      const an = analyserRef.current;
      const isActive = activeRef.current;
      if (an && isActive) {
        const data = new Uint8Array(an.frequencyBinCount);
        an.getByteTimeDomainData(data);
        drawWaveform(data);
      } else {
        drawIdle();
      }
      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, []);

  return (
    <div className="relative w-full">
      <AnimatePresence>
        {active && (
          <motion.div
            key="visualizer-glow"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0.35, 0.7, 0.35] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            className="pointer-events-none absolute -inset-2 rounded-2xl bg-rose-400/30 blur-2xl"
            aria-hidden
          />
        )}
      </AnimatePresence>
      <canvas
        ref={canvasRef}
        className={cn("relative z-10 h-24 w-full")}
        aria-label="Live audio waveform"
      />
    </div>
  );
}
