"use client";

// ============================================================================
// VideoInterviewView — AI Video Interviewer
// ----------------------------------------------------------------------------
// A video-call style mock interview. Reuses the same turn-based interview
// flow as InterviewView.tsx (start → /api/interview/start → display question
// → playTts → record answer → /api/interview/respond → next question →
// /api/report → setView('report')) but presents it as a video call:
//
//   ┌─────────────────────────────────────────────────────┐
//   │  Main "video feed": AI interviewer avatar           │
//   │  (pulses with an emerald ring when speaking)        │
//   │                                                     │
//   │                            ┌──────────────┐         │
//   │                            │ PiP: You     │         │
//   │                            │ (webcam)     │         │
//   │                            └──────────────┘         │
//   │  [Caption bar: current question]                    │
//   └─────────────────────────────────────────────────────┘
//   [ Mic ][ Cam ][ Replay ][ Type instead ]   [ End call ]
//   [ Collapsible live transcript ]
//
// The webcam stream provides BOTH video (for the PiP feed) AND audio (for
// the MediaRecorder — so we never open a second mic). When recording stops,
// only the AudioContext is torn down; the webcam stream keeps running so the
// camera feed stays live for the next turn.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  ArrowLeft,
  Mic,
  Square,
  Loader2,
  Volume2,
  Sparkles,
  AlertCircle,
  Radio,
  Keyboard,
  Send,
  X,
  Clock,
  Video,
  VideoOff,
  Phone,
  ChevronDown,
  ChevronUp,
  MessageSquare,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { AudioVisualizer } from "./AudioVisualizer";
import { LiveTranscript } from "./LiveTranscript";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { cn } from "@/lib/utils";
import { audioBlobToWav } from "@/lib/audio-utils";

const TTS_MAX_CHARS = 900;
const MAX_QUESTIONS = 8;

export function VideoInterviewView() {
  const analysis = useAppStore((s) => s.analysis);
  const interviewMessages = useAppStore((s) => s.interviewMessages);
  const currentQuestion = useAppStore((s) => s.currentQuestion);
  const isInterviewThinking = useAppStore((s) => s.isInterviewThinking);
  const interviewTargetRole = useAppStore((s) => s.interviewTargetRole);
  const isBuildingReport = useAppStore((s) => s.isBuildingReport);
  const setInterview = useAppStore((s) => s.setInterview);
  const addInterviewMessage = useAppStore((s) => s.addInterviewMessage);
  const resetInterview = useAppStore((s) => s.resetInterview);
  const setView = useAppStore((s) => s.setView);
  const setIsBuildingReport = useAppStore((s) => s.setIsBuildingReport);
  const setReport = useAppStore((s) => s.setReport);
  const setError = useAppStore((s) => s.setError);
  const updateTrailStatus = useAppStore((s) => s.updateTrailStatus);
  const { t } = useTranslation();

  // ----- audio refs (same as InterviewView) -----
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null); // audio-only stream for recording
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const currentUrlRef = useRef<string | null>(null);

  // True only when we opened our own getUserMedia for audio (i.e. the webcam
  // stream had no audio track). In that case the onstop handler must stop the
  // tracks; otherwise the tracks belong to the webcam stream and must stay
  // alive for the next turn.
  const ownsAudioStreamRef = useRef(false);

  const startedRef = useRef(false);

  // ----- webcam refs/state -----
  const webcamStreamRef = useRef<MediaStream | null>(null);
  const webcamVideoRef = useRef<HTMLVideoElement | null>(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [webcamError, setWebcamError] = useState<string | null>(null);

  // ----- local UI state -----
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [showTextInput, setShowTextInput] = useState(false);
  const [textAnswer, setTextAnswer] = useState("");
  const [isConverting, setIsConverting] = useState(false);
  const [showTranscript, setShowTranscript] = useState(true);

  const supported =
    typeof window !== "undefined" &&
    typeof window.MediaRecorder !== "undefined" &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.getUserMedia === "function";

  // ----- recording timer -----
  useEffect(() => {
    if (!isRecording) {
      setRecordSeconds(0);
      return;
    }
    const t = setInterval(() => setRecordSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [isRecording]);

  const formatTime = (s: number) =>
    `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  // -------------------------------------------------------------------------
  // playTts — POSTs text to /api/interview/tts, plays returned WAV blob.
  // -------------------------------------------------------------------------
  const playTts = useCallback(async (text: string) => {
    if (!text) return;
    const safeText =
      text.length > TTS_MAX_CHARS ? text.slice(0, TTS_MAX_CHARS) : text;
    const audio = audioElRef.current;
    if (!audio) return;
    try {
      audio.pause();
    } catch {}
    audio.onended = null;
    audio.onerror = null;
    if (currentUrlRef.current) {
      URL.revokeObjectURL(currentUrlRef.current);
      currentUrlRef.current = null;
    }
    setIsPlayingAudio(true);
    try {
      const res = await fetch("/api/interview/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: safeText }),
      });
      if (!res.ok) throw new Error("TTS request failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      currentUrlRef.current = url;
      audio.src = url;
      audio.playbackRate = 1;
      audio.onended = () => {
        setIsPlayingAudio(false);
        if (currentUrlRef.current) {
          URL.revokeObjectURL(currentUrlRef.current);
          currentUrlRef.current = null;
        }
      };
      audio.onerror = () => {
        setIsPlayingAudio(false);
        if (currentUrlRef.current) {
          URL.revokeObjectURL(currentUrlRef.current);
          currentUrlRef.current = null;
        }
      };
      try {
        await audio.play();
      } catch {
        setIsPlayingAudio(false);
      }
    } catch {
      setIsPlayingAudio(false);
    }
  }, []);

  // -------------------------------------------------------------------------
  // finishInterview — POSTs transcript to /api/report, navigates to report.
  // -------------------------------------------------------------------------
  const finishInterview = async () => {
    setInterview({ isThinking: false, isActive: false });
    setIsBuildingReport(true);
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) {
      setIsBuildingReport(false);
      setError("No analysis found.");
      return;
    }
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    try {
      const res = await fetch("/api/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRole, missingSkills, transcript }),
      });
      if (!res.ok) throw new Error("Failed to build report.");
      const data = await res.json();
      setReport(data.report);
      const verdict = data.report.overall_verdict as string;
      const cracked = verdict === "Strong Hire" || verdict === "Hire";
      const mode = state.interviewMode;
      void updateTrailStatus(
        cracked ? "cracked" : "failed",
        verdict,
        mode,
      );
      setView("report");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to build report.";
      setError(msg);
      toast.error(msg);
    } finally {
      setIsBuildingReport(false);
    }
  };

  // -------------------------------------------------------------------------
  // submitAnswer — sends a WAV blob to /api/interview/respond.
  // -------------------------------------------------------------------------
  const submitAnswer = async (wavBlob: Blob) => {
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) {
      setError("No analysis found.");
      return;
    }
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    const currentQ = state.currentQuestion;
    const questionsAsked = transcript.filter(
      (m) => m.role === "interviewer",
    ).length;

    setInterview({ isThinking: true });
    try {
      const fd = new FormData();
      const file = new File([wavBlob], "answer.wav", { type: "audio/wav" });
      fd.append("audio", file);
      fd.append(
        "meta",
        JSON.stringify({
          targetRole,
          missingSkills,
          transcript,
          questionsAsked,
          currentQuestion: currentQ,
        }),
      );

      const res = await fetch("/api/interview/respond", {
        method: "POST",
        body: fd,
      });
      if (!res.ok) throw new Error("Failed to process your answer.");
      const data = await res.json();

      addInterviewMessage({
        role: "candidate",
        content: data.transcript || "(no speech detected)",
        timestamp: Date.now(),
      });

      if (data.isFinal) {
        await finishInterview();
      } else {
        setInterview({
          currentQuestion: data.question,
          isThinking: false,
        });
        addInterviewMessage({
          role: "interviewer",
          content: data.question,
          timestamp: Date.now(),
        });
        void playTts(data.question);
      }
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Failed to process your answer.";
      setInterview({ isThinking: false });
      setError(msg);
      toast.error(msg);
    }
  };

  // -------------------------------------------------------------------------
  // submitTextAnswer — fallback for users without a mic.
  // -------------------------------------------------------------------------
  const submitTextAnswer = async () => {
    const answer = textAnswer.trim();
    if (!answer) return;
    setShowTextInput(false);
    setTextAnswer("");
    const state = useAppStore.getState();
    const a = state.analysis;
    if (!a) return;
    const targetRole = state.interviewTargetRole || a.target_role;
    const missingSkills = a.missing_skills;
    const transcript = state.interviewMessages;
    const currentQ = state.currentQuestion;
    const questionsAsked = transcript.filter(
      (m) => m.role === "interviewer",
    ).length;

    setInterview({ isThinking: true });
    try {
      const fd = new FormData();
      fd.append(
        "meta",
        JSON.stringify({
          targetRole,
          missingSkills,
          transcript,
          questionsAsked,
          currentQuestion: currentQ,
        }),
      );
      const emptyWav = new Blob([makeEmptyWav()], { type: "audio/wav" });
      fd.append("audio", emptyWav, "empty.wav");
      fd.append("textAnswer", answer);

      const res = await fetch("/api/interview/respond", {
        method: "POST",
        body: fd,
      });
      if (!res.ok) throw new Error("Failed to process your answer.");
      const data = await res.json();

      addInterviewMessage({
        role: "candidate",
        content: data.transcript || answer,
        timestamp: Date.now(),
      });

      if (data.isFinal) {
        await finishInterview();
      } else {
        setInterview({
          currentQuestion: data.question,
          isThinking: false,
        });
        addInterviewMessage({
          role: "interviewer",
          content: data.question,
          timestamp: Date.now(),
        });
        void playTts(data.question);
      }
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Failed to process your answer.";
      setInterview({ isThinking: false });
      setError(msg);
      toast.error(msg);
    }
  };

  // -------------------------------------------------------------------------
  // startRecording — reuses webcam's audio track when available.
  // -------------------------------------------------------------------------
  const startRecording = async () => {
    if (isRecording || isInterviewThinking || isPlayingAudio || isBuildingReport)
      return;
    if (!supported) {
      setMicError(t("interview.browserNotSupported"));
      return;
    }
    setMicError(null);
    if (audioElRef.current) audioElRef.current.pause();
    setIsPlayingAudio(false);

    try {
      // Prefer the audio track from the webcam stream so we don't open
      // another mic. If the webcam has no audio track (e.g. user denied
      // audio earlier), fall back to a fresh getUserMedia({ audio: true }).
      let stream: MediaStream | null = null;
      const webcam = webcamStreamRef.current;
      const webcamAudioTracks = webcam?.getAudioTracks() ?? [];
      if (webcamAudioTracks.length > 0) {
        stream = new MediaStream(webcamAudioTracks);
        ownsAudioStreamRef.current = false;
      } else {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        ownsAudioStreamRef.current = true;
      }
      audioStreamRef.current = stream;

      const w = window as unknown as {
        AudioContext?: typeof AudioContext;
        webkitAudioContext?: typeof AudioContext;
      };
      const AudioCtx = w.AudioContext || w.webkitAudioContext;
      if (!AudioCtx)
        throw new Error("Web Audio API is not supported in this browser.");
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyserNode = ctx.createAnalyser();
      analyserNode.fftSize = 2048;
      source.connect(analyserNode);
      analyserRef.current = analyserNode;
      setAnalyser(analyserNode);

      let mimeType = "";
      const candidates = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/ogg;codecs=opus",
        "audio/mp4",
      ];
      for (const c of candidates) {
        try {
          if (MediaRecorder.isTypeSupported(c)) {
            mimeType = c;
            break;
          }
        } catch {}
      }
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        const chunksBlob = new Blob(audioChunksRef.current, {
          type: recorder.mimeType || mimeType || "audio/webm",
        });
        audioChunksRef.current = [];
        setIsRecording(false);

        // IMPORTANT: do NOT stop the audio tracks if they belong to the
        // webcam stream — that would kill the camera feed for the next
        // turn. Only stop them if WE opened them.
        if (ownsAudioStreamRef.current) {
          audioStreamRef.current?.getTracks().forEach((t) => t.stop());
        }
        ownsAudioStreamRef.current = false;
        audioStreamRef.current = null;

        if (audioContextRef.current) {
          audioContextRef.current.close().catch(() => {});
          audioContextRef.current = null;
        }
        analyserRef.current = null;
        setAnalyser(null);

        // Convert webm/opus → WAV before sending to ASR.
        setIsConverting(true);
        try {
          const { wav } = await audioBlobToWav(chunksBlob, 16000);
          await submitAnswer(wav);
        } catch (convErr) {
          console.error("Audio conversion failed:", convErr);
          toast.error(
            "Could not process audio. Please try again or use the text input option.",
          );
          setInterview({ isThinking: false });
        } finally {
          setIsConverting(false);
        }
      };
      recorder.onerror = () => {
        setIsRecording(false);
        setMicError(
          "Recording failed. Please try again or use the text input option.",
        );
        if (ownsAudioStreamRef.current) {
          audioStreamRef.current?.getTracks().forEach((t) => t.stop());
        }
        ownsAudioStreamRef.current = false;
        audioStreamRef.current = null;
        if (audioContextRef.current) {
          audioContextRef.current.close().catch(() => {});
          audioContextRef.current = null;
        }
        analyserRef.current = null;
        setAnalyser(null);
      };

      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      recorder.start();
      setIsRecording(true);
    } catch (err) {
      if (err instanceof DOMException) {
        if (
          err.name === "NotAllowedError" ||
          err.name === "PermissionDeniedError"
        ) {
          setMicError(
            "Microphone permission denied. Please allow mic access, or use the text input option.",
          );
        } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
          setMicError(
            "No microphone found. Connect a microphone, or use the text input option.",
          );
        } else if (err.name === "NotReadableError" || err.name === "TrackStartError") {
          setMicError(
            "Microphone is in use by another app. Close it, or use the text input option.",
          );
        } else {
          setMicError(
            err.message || "Could not access microphone. Use the text input option.",
          );
        }
      } else {
        setMicError(
          err instanceof Error
            ? err.message
            : "Could not access microphone. Use the text input option.",
        );
      }
    }
  };

  const stopRecording = () => {
    const rec = mediaRecorderRef.current;
    if (!rec || rec.state === "inactive") return;
    try {
      rec.stop();
    } catch {}
  };

  // -------------------------------------------------------------------------
  // Mount: start webcam + set interview mode = video
  // -------------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!navigator.mediaDevices?.getUserMedia) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 320 }, height: { ideal: 240 } },
          audio: true,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        webcamStreamRef.current = stream;
        if (webcamVideoRef.current) {
          webcamVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        if (err instanceof DOMException) {
          if (
            err.name === "NotAllowedError" ||
            err.name === "PermissionDeniedError"
          ) {
            setWebcamError(
              "Camera/mic permission denied. You can still do a voice-only interview with the text input option.",
            );
          } else if (err.name === "NotFoundError") {
            setWebcamError(
              "No camera or microphone found on this device. Use the text input option below.",
            );
          } else {
            setWebcamError(
              err.message || "Could not access camera/mic.",
            );
          }
        } else {
          setWebcamError(
            err instanceof Error ? err.message : "Could not access camera/mic.",
          );
        }
      }
    })();

    // Mark this interview session as "video" mode for the trail history.
    setInterview({ mode: "video" });

    return () => {
      cancelled = true;
      webcamStreamRef.current?.getTracks().forEach((t) => t.stop());
      webcamStreamRef.current = null;
    };
  }, []);

  const toggleCamera = () => {
    const stream = webcamStreamRef.current;
    if (!stream) return;
    const newOn = !cameraOn;
    stream.getVideoTracks().forEach((tr) => {
      tr.enabled = newOn;
    });
    setCameraOn(newOn);
  };

  // -------------------------------------------------------------------------
  // Mount: kick off the interview (Strict Mode safe via startedRef).
  // -------------------------------------------------------------------------
  useEffect(() => {
    if (startedRef.current) return;
    if (!analysis) return;
    startedRef.current = true;
    (async () => {
      setIsStarting(true);
      setInterview({
        targetRole: analysis.target_role,
        isActive: true,
        mode: "video",
      });
      try {
        const res = await fetch("/api/interview/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            targetRole: analysis.target_role,
            missingSkills: analysis.missing_skills,
          }),
        });
        if (!res.ok) throw new Error("Failed to start interview.");
        const data = await res.json();
        setInterview({
          targetRole: analysis.target_role,
          currentQuestion: data.question,
          isActive: true,
          mode: "video",
        });
        addInterviewMessage({
          role: "interviewer",
          content: data.question,
          timestamp: Date.now(),
        });
        void playTts(data.question);
      } catch (err) {
        const msg =
          err instanceof Error ? err.message : "Failed to start interview.";
        setError(msg);
        toast.error(msg);
      } finally {
        setIsStarting(false);
      }
    })();
  }, [analysis, setInterview, addInterviewMessage, setError, playTts]);

  // -------------------------------------------------------------------------
  // teardownAudio — stops recorder + audio context, pauses TTS audio,
  // revokes object URL. Does NOT touch the webcam stream.
  // -------------------------------------------------------------------------
  const teardownAudio = useCallback(() => {
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (audioElRef.current) audioElRef.current.pause();
    if (currentUrlRef.current) {
      URL.revokeObjectURL(currentUrlRef.current);
      currentUrlRef.current = null;
    }
    analyserRef.current = null;
  }, []);

  useEffect(
    () => () => {
      teardownAudio();
      webcamStreamRef.current?.getTracks().forEach((t) => t.stop());
      webcamStreamRef.current = null;
    },
    [teardownAudio],
  );

  const handleEndCall = () => {
    teardownAudio();
    webcamStreamRef.current?.getTracks().forEach((t) => t.stop());
    webcamStreamRef.current = null;
    setIsRecording(false);
    setIsPlayingAudio(false);
    resetInterview();
    setView("dashboard");
  };

  const interviewerCount = interviewMessages.filter(
    (m) => m.role === "interviewer",
  ).length;
  const candidateCount = interviewMessages.filter(
    (m) => m.role === "candidate",
  ).length;
  const progressPct = Math.min(
    100,
    Math.round((interviewerCount / MAX_QUESTIONS) * 100),
  );

  const statusInfo = (() => {
    if (isBuildingReport)
      return {
        label: t("interview.buildingReport"),
        icon: <Loader2 className="size-3 animate-spin" />,
        cls: "border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300",
      };
    if (isConverting)
      return {
        label: t("interview.processing"),
        icon: <Loader2 className="size-3 animate-spin" />,
        cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300",
      };
    if (isInterviewThinking)
      return {
        label: t("interview.thinking"),
        icon: <Loader2 className="size-3 animate-spin" />,
        cls: "border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300",
      };
    if (isRecording)
      return {
        label: t("interview.recording"),
        icon: <span className="size-2 animate-pulse rounded-full bg-rose-500" />,
        cls: "border-rose-200 bg-rose-100 text-rose-700 dark:border-rose-800/40 dark:bg-rose-950/40 dark:text-rose-300",
      };
    if (isPlayingAudio)
      return {
        label: t("interview.speaking"),
        icon: <Volume2 className="size-3" />,
        cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300",
      };
    if (isStarting)
      return {
        label: "Connecting…",
        icon: <Loader2 className="size-3 animate-spin" />,
        cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300",
      };
    return {
      label: t("interview.listening"),
      icon: <Radio className="size-3" />,
      cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300",
    };
  })();

  // -----------------------------------------------------------------------
  // No-analysis guard
  // -----------------------------------------------------------------------
  if (!analysis) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
        <Card className="w-full p-8">
          <AlertCircle className="mx-auto size-10 text-rose-500" />
          <p className="mt-3 text-lg font-semibold">{t("interview.noAnalysis")}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("interview.noAnalysisDesc")}
          </p>
          <Button onClick={() => setView("dashboard")} className="mt-4 gap-2">
            <ArrowLeft className="size-4" /> {t("interview.backToDashboard")}
          </Button>
        </Card>
      </div>
    );
  }

  const micDisabled =
    isInterviewThinking ||
    isPlayingAudio ||
    isBuildingReport ||
    isStarting ||
    isConverting ||
    isRecording;
  const replayDisabled =
    isRecording ||
    isPlayingAudio ||
    isInterviewThinking ||
    isBuildingReport ||
    !currentQuestion;

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
      {/* Top bar */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleEndCall}
            className="gap-1.5 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" /> {t("interview.back")}
          </Button>
          <div className="hidden h-6 w-px bg-border sm:block" />
          <div className="flex flex-col">
            <h1 className="flex items-center gap-2 text-base font-semibold tracking-tight sm:text-lg">
              <Video className="size-4 text-emerald-600" />
              AI Video Interview
            </h1>
            <p className="truncate text-xs text-muted-foreground">
              {interviewTargetRole || "Senior Engineering Manager"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className={cn("gap-1.5", statusInfo.cls)}>
            {statusInfo.icon}
            <span>{statusInfo.label}</span>
          </Badge>
        </div>
      </header>

      {/* Progress bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {t("interview.question")} {interviewerCount} {t("interview.questionOf")} ~{MAX_QUESTIONS}
          </span>
          <span>
            {candidateCount} {t("interview.answersSubmitted")}
          </span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600"
            initial={{ width: 0 }}
            animate={{ width: `${progressPct}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        </div>
      </div>

      {/* Main video-call area */}
      <div className="relative overflow-hidden rounded-2xl border border-emerald-200/30 bg-slate-900 shadow-xl">
        {/* Aspect-ratio video feed */}
        <div className="relative aspect-video w-full bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950">
          {/* Subtle radial emerald glow when interviewer is speaking */}
          <AnimatePresence>
            {isPlayingAudio && (
              <motion.div
                key="speaking-glow"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0.5, 0.9, 0.5] }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: 1.4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "radial-gradient(circle at center, rgba(16,185,129,0.30), transparent 60%)",
                }}
                aria-hidden
              />
            )}
          </AnimatePresence>

          {/* Interviewer avatar (main "video feed") */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              animate={
                isPlayingAudio ? { scale: [1, 1.03, 1] } : { scale: 1 }
              }
              transition={{
                duration: 1.4,
                repeat: isPlayingAudio ? Infinity : 0,
                ease: "easeInOut",
              }}
              className="relative"
            >
              <div
                className={cn(
                  "absolute -inset-3 rounded-full bg-emerald-400/40 blur-2xl transition-opacity duration-500",
                  isPlayingAudio ? "opacity-100" : "opacity-30",
                )}
              />
              <img
                src="/avatars/interviewer.png"
                alt="AI Interviewer"
                className={cn(
                  "relative size-32 rounded-full object-cover shadow-2xl ring-4 sm:size-44 md:size-52",
                  isPlayingAudio
                    ? "ring-emerald-400/80"
                    : isInterviewThinking
                      ? "ring-amber-400/60"
                      : "ring-slate-600/60",
                )}
              />
            </motion.div>
          </div>

          {/* "typing…" thinking indicator overlay */}
          <AnimatePresence>
            {isInterviewThinking && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="absolute left-1/2 top-6 -translate-x-1/2"
              >
                <div className="flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-950/70 px-4 py-1.5 backdrop-blur-md">
                  <Loader2 className="size-3.5 animate-spin text-amber-300" />
                  <span className="text-xs font-medium text-amber-100">
                    typing…
                  </span>
                  <div className="flex items-center gap-0.5">
                    {[0, 1, 2].map((i) => (
                      <motion.span
                        key={i}
                        className="size-1 rounded-full bg-amber-300"
                        animate={{
                          y: [0, -3, 0],
                          opacity: [0.4, 1, 0.4],
                        }}
                        transition={{
                          duration: 0.9,
                          repeat: Infinity,
                          delay: i * 0.15,
                          ease: "easeInOut",
                        }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Interviewer name tag (bottom-left) */}
          <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-lg bg-black/40 px-3 py-1.5 backdrop-blur-md">
            <span
              className={cn(
                "size-2 rounded-full",
                isPlayingAudio ? "bg-emerald-400" : "bg-slate-500",
              )}
            />
            <span className="text-xs font-medium text-white">
              AI Interviewer
            </span>
            {isPlayingAudio && (
              <Volume2 className="size-3.5 animate-pulse text-emerald-300" />
            )}
          </div>

          {/* Picture-in-picture candidate webcam (bottom-right) */}
          <div className="absolute bottom-4 right-4 z-10">
            <div className="relative overflow-hidden rounded-xl border-2 border-white/20 bg-slate-800 shadow-xl">
              <video
                ref={webcamVideoRef}
                autoPlay
                muted
                playsInline
                className={cn(
                  "h-[110px] w-[150px] object-cover sm:h-[130px] sm:w-[180px]",
                  !cameraOn && "opacity-0",
                )}
              />
              {!cameraOn && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
                  <VideoOff className="size-6 text-slate-400" />
                </div>
              )}
              <div className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 backdrop-blur-sm">
                <span className="text-[10px] font-medium text-white">You</span>
              </div>
              {isRecording && (
                <div className="absolute right-1 top-1 flex items-center gap-1 rounded bg-rose-600/90 px-1.5 py-0.5">
                  <span className="size-1.5 animate-pulse rounded-full bg-white" />
                  <span className="text-[10px] font-bold text-white">REC</span>
                </div>
              )}
            </div>
          </div>

          {/* Building-report overlay */}
          <AnimatePresence>
            {isBuildingReport && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-slate-950/85 p-6 backdrop-blur-sm"
              >
                <Loader2 className="size-12 animate-spin text-emerald-400" />
                <p className="text-lg font-semibold text-white">
                  {t("interview.buildingReport")}
                </p>
                <p className="max-w-xs text-center text-sm text-slate-300">
                  {t("interview.buildingReportDesc")}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Caption bar — current question */}
        <div className="border-t border-slate-700/50 bg-slate-950/60 px-4 py-3 backdrop-blur-md">
          {isInterviewThinking ? (
            <div className="flex items-center gap-2 text-amber-200">
              <Loader2 className="size-4 shrink-0 animate-spin" />
              <span className="text-sm font-medium">
                {t("interview.thinking")}
              </span>
            </div>
          ) : currentQuestion ? (
            <div className="flex items-start gap-2">
              <Volume2
                className={cn(
                  "mt-0.5 size-4 shrink-0",
                  isPlayingAudio
                    ? "animate-pulse text-emerald-300"
                    : "text-emerald-400/70",
                )}
              />
              <p className="text-sm font-medium leading-relaxed text-slate-100 sm:text-base">
                {currentQuestion}
              </p>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-400">
              <Sparkles className="size-4 shrink-0" />
              <span className="text-sm">
                {isStarting
                  ? "Preparing your first question…"
                  : "Your question will appear here."}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Audio visualizer + recording timer (only while recording) */}
      {(isRecording || isConverting) && (
        <div className="rounded-xl border border-rose-200/40 bg-rose-50/40 p-2 dark:bg-rose-950/20">
          <AudioVisualizer analyser={analyser} active={isRecording} />
          <div className="mt-1 flex items-center justify-center gap-2 text-sm font-medium text-rose-600 dark:text-rose-400">
            {isRecording ? (
              <>
                <Clock className="size-4" />
                <span className="tabular-nums">
                  {formatTime(recordSeconds)}
                </span>
                <span className="text-muted-foreground">
                  · {t("interview.recording")}
                </span>
              </>
            ) : (
              <>
                <Loader2 className="size-4 animate-spin" />
                <span>Converting audio for transcription…</span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Text input fallback — replaces controls bar when active */}
      {showTextInput ? (
        <Card className="glass p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-sm font-medium">
              {t("interview.typeAnswer")}
            </span>
            <Button
              variant="ghost"
              size="sm"
              className="gap-1.5 text-muted-foreground"
              onClick={() => {
                setShowTextInput(false);
                setTextAnswer("");
              }}
            >
              <X className="size-4" /> {t("interview.cancel")}
            </Button>
          </div>
          <Textarea
            value={textAnswer}
            onChange={(e) => setTextAnswer(e.target.value)}
            placeholder="Type your answer to the interviewer's question here…"
            className="min-h-[120px] resize-y"
            autoFocus
          />
          <Button
            onClick={() => void submitTextAnswer()}
            disabled={
              !textAnswer.trim() || isInterviewThinking || isBuildingReport
            }
            className="mt-3 gap-2"
          >
            <Send className="size-4" /> {t("interview.submit")}
          </Button>
        </Card>
      ) : (
        /* Controls bar — Zoom/Meet style */
        <div className="glass-strong flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-border p-3 shadow-md sm:gap-4">
          {/* Mic / Record button */}
          <button
            type="button"
            onClick={isRecording ? stopRecording : startRecording}
            disabled={micDisabled}
            aria-label={isRecording ? t("interview.stop") : t("interview.record")}
            className={cn(
              "relative flex size-14 items-center justify-center rounded-full shadow-lg transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-500/30 disabled:cursor-not-allowed disabled:opacity-40",
              isRecording
                ? "bg-rose-500 text-white shadow-rose-500/40 hover:bg-rose-600"
                : "bg-emerald-600 text-white shadow-emerald-600/40 hover:bg-emerald-700",
            )}
          >
            {isRecording ? (
              <Square className="size-5" fill="currentColor" />
            ) : (
              <Mic className="size-6" />
            )}
            {isRecording && (
              <span className="absolute inset-0 animate-ping rounded-full ring-4 ring-rose-400/40" />
            )}
          </button>

          {/* Camera toggle */}
          <button
            type="button"
            onClick={toggleCamera}
            disabled={!webcamStreamRef.current}
            aria-label={cameraOn ? "Turn camera off" : "Turn camera on"}
            className={cn(
              "flex size-12 items-center justify-center rounded-full transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-500/30 disabled:cursor-not-allowed disabled:opacity-40",
              cameraOn
                ? "bg-slate-700 text-white hover:bg-slate-600"
                : "bg-muted text-muted-foreground hover:bg-accent",
            )}
          >
            {cameraOn ? (
              <Video className="size-5" />
            ) : (
              <VideoOff className="size-5" />
            )}
          </button>

          {/* Replay audio */}
          <button
            type="button"
            onClick={() => playTts(currentQuestion)}
            disabled={replayDisabled}
            aria-label={t("interview.replay")}
            className="flex size-12 items-center justify-center rounded-full bg-muted text-muted-foreground transition-all hover:bg-accent focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-500/30 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Volume2 className="size-5" />
          </button>

          {/* Type instead */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowTextInput(true)}
            disabled={isInterviewThinking || isBuildingReport || isPlayingAudio}
            className="gap-1.5"
          >
            <Keyboard className="size-4" /> {t("interview.typeInstead")}
          </Button>

          {/* Spacer */}
          <div className="hidden flex-1 sm:block" />

          {/* End call */}
          <button
            type="button"
            onClick={handleEndCall}
            aria-label="End call"
            className="flex size-12 items-center justify-center rounded-full bg-rose-600 text-white shadow-lg shadow-rose-600/40 transition-all hover:bg-rose-700 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-rose-500/30"
          >
            <Phone className="size-5 rotate-[135deg]" />
          </button>
        </div>
      )}

      {/* Mic error */}
      {micError && !showTextInput && (
        <div className="flex items-start gap-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300">
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          <span className="flex-1">{micError}</span>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 shrink-0 px-2"
            onClick={() => {
              setMicError(null);
              void startRecording();
            }}
          >
            Retry
          </Button>
        </div>
      )}

      {/* Webcam error */}
      {webcamError && (
        <div className="flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-700 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          <span className="flex-1">{webcamError}</span>
        </div>
      )}

      {/* Collapsible live transcript */}
      <Card className="glass overflow-hidden">
        <button
          type="button"
          onClick={() => setShowTranscript((v) => !v)}
          className="flex w-full items-center justify-between px-4 py-3 text-left transition-colors hover:bg-accent/40"
          aria-expanded={showTranscript}
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            <MessageSquare className="size-4 text-emerald-600" />
            Live Transcript
            <Badge variant="secondary" className="text-xs">
              {interviewMessages.length}
            </Badge>
          </span>
          {showTranscript ? (
            <ChevronUp className="size-4" />
          ) : (
            <ChevronDown className="size-4" />
          )}
        </button>
        <AnimatePresence initial={false}>
          {showTranscript && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.22 }}
              className="overflow-hidden"
            >
              <LiveTranscript
                messages={interviewMessages}
                thinking={isInterviewThinking}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {/* Hidden audio element for TTS playback */}
      <audio ref={audioElRef} className="hidden" />
    </div>
  );
}

// Minimal valid WAV (1 sample of silence) for the text-fallback path.
function makeEmptyWav(): ArrayBuffer {
  const ab = new ArrayBuffer(44 + 2);
  const view = new DataView(ab);
  const sr = 16000;
  writeStr(view, 0, "RIFF");
  view.setUint32(4, 36 + 2, true);
  writeStr(view, 8, "WAVE");
  writeStr(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sr, true);
  view.setUint32(28, sr * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(view, 36, "data");
  view.setUint32(40, 2, true);
  view.setInt16(44, 0, true);
  return ab;
}

function writeStr(view: DataView, offset: number, str: string) {
  for (let i = 0; i < str.length; i++)
    view.setUint8(offset + i, str.charCodeAt(i));
}

export default VideoInterviewView;
