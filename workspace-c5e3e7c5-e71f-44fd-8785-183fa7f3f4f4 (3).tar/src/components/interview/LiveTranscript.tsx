"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Sparkles, User } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/use-translation";
import type { InterviewMessage } from "@/lib/types";

interface LiveTranscriptProps {
  messages: InterviewMessage[];
  /** When true, renders a 3-dot typing indicator at the bottom of the list. */
  thinking?: boolean;
}

/** Three bouncing dots — used for the "interviewer is thinking" affordance. */
function TypingDots() {
  return (
    <div className="flex items-center gap-1" aria-label="Interviewer is typing">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="size-1.5 rounded-full bg-emerald-500"
          animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }}
          transition={{
            duration: 0.9,
            repeat: Infinity,
            delay: i * 0.15,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

/**
 * LiveTranscript — chat-style scrollable list of interview messages.
 *
 * - Interviewer messages: left-aligned, emerald bubble, Sparkles avatar.
 * - Candidate messages: right-aligned, slate bubble, User avatar.
 * - Auto-scrolls to the bottom on new messages or when thinking changes.
 * - Shows a typing indicator while `thinking` is true.
 */
export function LiveTranscript({ messages, thinking = false }: LiveTranscriptProps) {
  const { t } = useTranslation();
  const scrollRootRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to bottom on new messages / thinking toggle.
  useEffect(() => {
    const root = scrollRootRef.current;
    if (!root) return;
    const viewport = root.querySelector<HTMLElement>(
      '[data-slot="scroll-area-viewport"]',
    );
    if (!viewport) return;
    // Defer to next frame so the new DOM is committed before scrolling.
    const raf = requestAnimationFrame(() => {
      viewport.scrollTo({ top: viewport.scrollHeight, behavior: "smooth" });
    });
    return () => cancelAnimationFrame(raf);
  }, [messages.length, thinking]);

  const isEmpty = messages.length === 0 && !thinking;

  return (
    <div className="rounded-2xl border bg-card shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-5 py-3">
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-emerald-600" />
          <h2 className="text-sm font-semibold">{t("interview.transcript")}</h2>
        </div>
        <Badge variant="secondary" className="text-xs">
          {messages.length} {messages.length === 1 ? "message" : "messages"}
        </Badge>
      </div>

      {/* Body */}
      <div ref={scrollRootRef} className="relative">
        <ScrollArea className="h-[320px] scrollbar-thin">
          <div className="space-y-3 px-4 py-4">
            {isEmpty ? (
              <div className="flex h-[260px] flex-col items-center justify-center text-center text-sm text-muted-foreground">
                <Sparkles className="mb-2 size-8 text-emerald-500/40" />
                <p>The interview transcript will appear here.</p>
              </div>
            ) : (
              <>
                {messages.map((m, i) => {
                  const isInterviewer = m.role === "interviewer";
                  return (
                    <motion.div
                      key={`${m.timestamp}-${i}`}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                      className={cn(
                        "flex items-end gap-2",
                        isInterviewer ? "justify-start" : "justify-end",
                      )}
                    >
                      {isInterviewer && (
                        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
                          <Sparkles className="size-3.5" />
                        </div>
                      )}
                      <div
                        className={cn(
                          "max-w-[80%] px-3.5 py-2 text-sm leading-relaxed shadow-sm",
                          isInterviewer
                            ? "rounded-2xl rounded-tl-sm bg-emerald-50 text-emerald-950 dark:bg-emerald-950/40 dark:text-emerald-100"
                            : "rounded-2xl rounded-br-sm bg-muted text-foreground",
                        )}
                      >
                        {m.content || (
                          <span className="italic text-muted-foreground">
                            (no speech detected)
                          </span>
                        )}
                      </div>
                      {!isInterviewer && (
                        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                          <User className="size-3.5" />
                        </div>
                      )}
                    </motion.div>
                  );
                })}

                {thinking && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, ease: "easeOut" }}
                    className="flex items-end justify-start gap-2"
                  >
                    <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
                      <Sparkles className="size-3.5" />
                    </div>
                    <div className="rounded-2xl rounded-tl-sm bg-emerald-50 px-3.5 py-3 dark:bg-emerald-950/40">
                      <TypingDots />
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
