"use client";

// ============================================================================
// HistoryView — Job Trail History
// ----------------------------------------------------------------------------
// Lists every JobTrail the user has created (one per analysis). Shows summary
// stats (total / cracked / failed / avg match score) plus a vertical list of
// trail cards with status badges, match score bars, verdict, interview mode,
// and relative timestamps. Empty + login-guard states included.
// ============================================================================

import { useEffect, useMemo, type ReactNode } from "react";
import { motion, type Variants } from "framer-motion";
import {
  ArrowLeft,
  Briefcase,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Trophy,
  Mic,
  Video,
  Sparkles,
  Clock,
  History as HistoryIcon,
  type LucideIcon,
} from "lucide-react";
import { useAppStore } from "@/lib/store";
import { useTranslation } from "@/lib/use-translation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { JobTrail, TrailStatus, Verdict } from "@/lib/types";

// ---------------------------------------------------------------------------
// Time helpers (no date-fns — just relative formatting from Date.now() - ts)
// ---------------------------------------------------------------------------
function formatRelativeTime(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 0) return "just now";
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} day${days === 1 ? "" : "s"} ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} month${months === 1 ? "" : "s"} ago`;
  const years = Math.floor(months / 12);
  return `${years} year${years === 1 ? "" : "s"} ago`;
}

function formatDate(ts: number): string {
  try {
    return new Date(ts).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "";
  }
}

// ---------------------------------------------------------------------------
// Status config — color + label + optional icon per TrailStatus
// ---------------------------------------------------------------------------
interface StatusCfg {
  label: string;
  cls: string;
  icon?: LucideIcon;
}

const STATUS_CONFIG: Record<TrailStatus, StatusCfg> = {
  in_progress: {
    label: "In Progress",
    cls: "border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300",
  },
  cracked: {
    label: "Cracked",
    cls: "border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300",
    icon: Trophy,
  },
  failed: {
    label: "Failed",
    cls: "border-rose-200 bg-rose-100 text-rose-700 dark:border-rose-800/40 dark:bg-rose-950/40 dark:text-rose-300",
  },
};

const VERDICT_THEME: Record<Verdict, string> = {
  "Strong Hire": "text-emerald-600 dark:text-emerald-400",
  Hire: "text-emerald-600 dark:text-emerald-400",
  "Needs Work": "text-amber-600 dark:text-amber-400",
};

function matchColorClass(score: number): string {
  if (score >= 70) return "text-emerald-600 dark:text-emerald-400";
  if (score >= 40) return "text-amber-600 dark:text-amber-400";
  return "text-rose-600 dark:text-rose-400";
}

function matchBarClass(score: number): string {
  if (score >= 70) return "bg-emerald-500";
  if (score >= 40) return "bg-amber-500";
  return "bg-rose-500";
}

// ---------------------------------------------------------------------------
// Framer Motion variants — staggered entrance for stats + trail list
// ---------------------------------------------------------------------------
const container: Variants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 12 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" },
  },
};

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function StatCard({
  label,
  value,
  icon,
  iconCls,
  iconBg,
}: {
  label: string;
  value: ReactNode;
  icon: LucideIcon;
  iconCls: string;
  iconBg: string;
}) {
  const Icon = icon;
  return (
    <Card className="glass flex items-start justify-between gap-3 p-4 sm:p-5">
      <div className="min-w-0">
        <div className="text-2xl font-bold tracking-tight sm:text-3xl">
          {value}
        </div>
        <div className="mt-1 text-xs text-muted-foreground sm:text-sm">
          {label}
        </div>
      </div>
      <span
        className={cn(
          "flex size-9 shrink-0 items-center justify-center rounded-xl",
          iconBg,
          iconCls,
        )}
      >
        <Icon className="size-5" />
      </span>
    </Card>
  );
}

function TrailCard({ trail }: { trail: JobTrail }) {
  const cfg = STATUS_CONFIG[trail.status];
  const StatusIcon = cfg.icon;

  return (
    <motion.div variants={item}>
      <Card className="glass p-4 transition-all hover:shadow-md sm:p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          {/* Left: role + meta */}
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-bold tracking-tight sm:text-lg">
                {trail.targetRole}
              </h3>
              <Badge
                variant="outline"
                className={cn("gap-1.5 text-xs", cfg.cls)}
              >
                {StatusIcon && <StatusIcon className="size-3" />}
                {cfg.label}
              </Badge>
            </div>

            <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="size-3" />
                {formatRelativeTime(trail.createdAt)}
              </span>
              <span>{formatDate(trail.createdAt)}</span>
              {trail.interviewMode && (
                <span className="flex items-center gap-1 capitalize">
                  {trail.interviewMode === "video" ? (
                    <Video className="size-3" />
                  ) : (
                    <Mic className="size-3" />
                  )}
                  {trail.interviewMode} interview
                </span>
              )}
              {trail.verdict && (
                <span
                  className={cn(
                    "font-semibold",
                    VERDICT_THEME[trail.verdict],
                  )}
                >
                  {trail.verdict}
                </span>
              )}
            </div>
          </div>

          {/* Right: match score + bar */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-end">
              <div
                className={cn(
                  "text-2xl font-bold tabular-nums",
                  matchColorClass(trail.matchScore),
                )}
              >
                {trail.matchScore}%
              </div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                Match
              </div>
            </div>
            <div className="relative hidden h-12 w-2 overflow-hidden rounded-full bg-muted sm:block">
              <div
                className={cn(
                  "absolute bottom-0 left-0 w-full rounded-full",
                  matchBarClass(trail.matchScore),
                )}
                style={{ height: `${Math.max(2, trail.matchScore)}%` }}
                aria-hidden
              />
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// HistoryView (orchestrator)
// ---------------------------------------------------------------------------
export function HistoryView() {
  const trails = useAppStore((s) => s.trails);
  const loadTrails = useAppStore((s) => s.loadTrails);
  const user = useAppStore((s) => s.user);
  const isAuthenticated = useAppStore((s) => s.isAuthenticated);
  const setView = useAppStore((s) => s.setView);
  const { t } = useTranslation();

  useEffect(() => {
    void loadTrails();
  }, [loadTrails]);

  const stats = useMemo(() => {
    const total = trails.length;
    const cracked = trails.filter((tr) => tr.status === "cracked").length;
    const failed = trails.filter((tr) => tr.status === "failed").length;
    const avg =
      total > 0
        ? Math.round(
            trails.reduce((acc, tr) => acc + tr.matchScore, 0) / total,
          )
        : 0;
    return { total, cracked, failed, avg };
  }, [trails]);

  // -----------------------------------------------------------------------
  // Auth guard
  // -----------------------------------------------------------------------
  if (!isAuthenticated || !user) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
        <Card className="w-full p-8">
          <Briefcase className="mx-auto size-10 text-emerald-500" />
          <p className="mt-3 text-lg font-semibold">Please log in</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Sign in to view your job trail history and track every application
            and interview outcome.
          </p>
          <Button onClick={() => setView("login")} className="mt-4">
            {t("nav.login")}
          </Button>
        </Card>
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Empty state
  // -----------------------------------------------------------------------
  if (trails.length === 0) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
        <Card className="w-full p-8">
          <Briefcase className="mx-auto size-12 text-emerald-500" />
          <p className="mt-3 text-lg font-semibold">No job trails yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Run an analysis to start your journey!
          </p>
          <Button onClick={() => setView("landing")} className="mt-4 gap-2">
            <Sparkles className="size-4" /> Start a new analysis
          </Button>
        </Card>
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Main render — header + stats + trail list
  // -----------------------------------------------------------------------
  const statCards: {
    label: string;
    value: ReactNode;
    icon: LucideIcon;
    iconCls: string;
    iconBg: string;
  }[] = [
    {
      label: "Total Applications",
      value: stats.total,
      icon: Briefcase,
      iconCls: "text-emerald-600 dark:text-emerald-400",
      iconBg: "bg-emerald-50 dark:bg-emerald-950/40",
    },
    {
      label: "Cracked",
      value: stats.cracked,
      icon: CheckCircle2,
      iconCls: "text-emerald-600 dark:text-emerald-400",
      iconBg: "bg-emerald-50 dark:bg-emerald-950/40",
    },
    {
      label: "Failed",
      value: stats.failed,
      icon: XCircle,
      iconCls: "text-rose-600 dark:text-rose-400",
      iconBg: "bg-rose-50 dark:bg-rose-950/40",
    },
    {
      label: "Avg Match Score",
      value: `${stats.avg}%`,
      icon: TrendingUp,
      iconCls: "text-amber-600 dark:text-amber-400",
      iconBg: "bg-amber-50 dark:bg-amber-950/40",
    },
  ];

  // Sort trails by createdAt desc (most recent first).
  const sortedTrails = [...trails].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
      {/* Header */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setView("landing")}
            className="gap-1.5 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" /> Back to Home
          </Button>
          <div className="hidden h-6 w-px bg-border sm:block" />
          <div className="flex flex-col">
            <h1 className="flex items-center gap-2 text-xl font-semibold tracking-tight sm:text-2xl">
              <HistoryIcon className="size-5 text-emerald-600" />
              Job Trail History
            </h1>
            <p className="text-xs text-muted-foreground sm:text-sm">
              Track every application and interview outcome
            </p>
          </div>
        </div>
      </header>

      {/* Stats row */}
      <motion.div
        className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {statCards.map((s) => (
          <motion.div key={s.label} variants={item}>
            <StatCard
              label={s.label}
              value={s.value}
              icon={s.icon}
              iconCls={s.iconCls}
              iconBg={s.iconBg}
            />
          </motion.div>
        ))}
      </motion.div>

      {/* Trails list */}
      <motion.div
        className="flex flex-col gap-3"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {sortedTrails.map((trail) => (
          <TrailCard key={trail.id} trail={trail} />
        ))}
      </motion.div>
    </div>
  );
}

export default HistoryView;
