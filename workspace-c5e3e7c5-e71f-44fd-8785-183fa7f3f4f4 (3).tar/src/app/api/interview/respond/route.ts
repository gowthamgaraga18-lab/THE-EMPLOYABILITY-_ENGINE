// ============================================================================
// POST /api/interview/respond
// Module 3 — Transcribe the candidate's recorded audio answer (or accept a
// typed text answer as a fallback) and generate the interviewer's next turn.
// Accepts multipart/form-data:
//   - audio:      Blob (wav/webm) — candidate's recorded answer (optional if textAnswer provided)
//   - textAnswer: string — candidate's typed answer (when provided, ASR is skipped)
//   - meta:       JSON string { targetRole, missingSkills, transcript, questionsAsked, currentQuestion }
// Returns: { transcript: string, question: string, isFinal: boolean }
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { nextInterviewerTurn, transcribeAudio } from "@/lib/ai";
import type { InterviewMessage, MissingSkill } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const audioFile = form.get("audio");
    const metaRaw = form.get("meta");
    const textAnswer = form.get("textAnswer");

    let meta: {
      targetRole: string;
      missingSkills: MissingSkill[];
      transcript: InterviewMessage[];
      questionsAsked: number;
      currentQuestion: string;
    };

    try {
      meta =
        typeof metaRaw === "string" ? JSON.parse(metaRaw) : ({} as typeof meta);
    } catch {
      meta = {
        targetRole: "Software Engineer",
        missingSkills: [],
        transcript: [],
        questionsAsked: 0,
        currentQuestion: "",
      };
    }

    // 1. Determine the candidate's answer text.
    //    - If a non-empty textAnswer was provided, use it directly (skip ASR).
    //    - Else if an audio Blob was provided, transcribe it via ASR.
    //    - Else leave empty (will be normalized below).
    let transcriptText = "";

    if (typeof textAnswer === "string" && textAnswer.trim()) {
      transcriptText = textAnswer.trim();
    } else if (audioFile && audioFile instanceof Blob && audioFile.size > 0) {
      const arrayBuffer = await audioFile.arrayBuffer();
      const buffer = Buffer.from(new Uint8Array(arrayBuffer));
      const base64Audio = buffer.toString("base64");
      try {
        transcriptText = await transcribeAudio(base64Audio);
      } catch (e) {
        console.error("[/api/interview/respond] ASR failed:", e);
        transcriptText = "";
      }
    }

    if (!transcriptText) {
      transcriptText = "(no speech detected)";
    }

    // 2. Build the updated transcript with the candidate's answer
    const updatedTranscript: InterviewMessage[] = [
      ...(meta.transcript ?? []),
      { role: "interviewer", content: meta.currentQuestion ?? "", timestamp: Date.now() },
      { role: "candidate", content: transcriptText, timestamp: Date.now() },
    ];

    // 3. Generate the interviewer's next turn
    const turn = await nextInterviewerTurn({
      targetRole: meta.targetRole || "Software Engineer",
      missingSkills: meta.missingSkills ?? [],
      transcript: updatedTranscript,
      questionsAsked: (meta.questionsAsked ?? 0) + 1,
      candidateAnswer: transcriptText,
    });

    return NextResponse.json({
      success: true,
      transcript: transcriptText,
      question: turn.question,
      isFinal: turn.isFinal,
    });
  } catch (err) {
    console.error("[/api/interview/respond] error:", err);
    const message =
      err instanceof Error ? err.message : "Failed to process response.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
