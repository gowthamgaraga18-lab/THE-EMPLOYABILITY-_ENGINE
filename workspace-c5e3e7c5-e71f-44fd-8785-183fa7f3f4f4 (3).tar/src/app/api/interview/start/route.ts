// ============================================================================
// POST /api/interview/start
// Module 3 — Generate the interviewer's first question for a new session.
// Accepts: { targetRole, missingSkills }
// Returns: { question, isFinal }
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { nextInterviewerTurn } from "@/lib/ai";
import type { MissingSkill } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const targetRole = String(body?.targetRole ?? "").trim() || "Software Engineer";
    const missingSkills: MissingSkill[] = Array.isArray(body?.missingSkills)
      ? body.missingSkills
      : [];

    const transcript: never[] = [];

    const turn = await nextInterviewerTurn({
      targetRole,
      missingSkills,
      transcript,
      questionsAsked: 0,
    });

    return NextResponse.json({ success: true, ...turn });
  } catch (err) {
    console.error("[/api/interview/start] error:", err);
    const message =
      err instanceof Error ? err.message : "Failed to start interview.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
