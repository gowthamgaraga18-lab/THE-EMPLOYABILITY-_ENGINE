// ============================================================================
// POST /api/interview/tts
// Module 3 — Synthesize the interviewer's voice (WAV audio) for a given text.
// Accepts: { text }
// Returns: audio/wav binary
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { synthesizeSpeech } from "@/lib/ai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const text = String(body?.text ?? "").trim();

    if (!text) {
      return NextResponse.json(
        { error: "Text is required for TTS." },
        { status: 400 },
      );
    }

    const wavBuffer = await synthesizeSpeech(text);

    return new NextResponse(new Uint8Array(wavBuffer), {
      status: 200,
      headers: {
        "Content-Type": "audio/wav",
        "Content-Length": wavBuffer.length.toString(),
        "Cache-Control": "no-cache, no-store, must-revalidate",
      },
    });
  } catch (err) {
    console.error("[/api/interview/tts] error:", err);
    const message =
      err instanceof Error ? err.message : "Failed to synthesize speech.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
