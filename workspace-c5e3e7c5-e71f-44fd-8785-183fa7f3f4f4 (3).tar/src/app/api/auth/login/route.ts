// ============================================================================
// POST /api/auth/login
// Verifies credentials against the database and returns the user (no password).
// Accepts: { email, password }
// Returns: { success, user } on success, { error } on failure.
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/password";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const email = String(body?.email ?? "").trim().toLowerCase();
    const password = String(body?.password ?? "");

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required." },
        { status: 400 },
      );
    }

    const user = await db.user.findUnique({ where: { email } });
    if (!user) {
      // Demo mode: if no user exists with this email, auto-create one so the
      // app is usable immediately without an explicit signup. This preserves
      // the previous demo-mode UX.
      if (body?.allowDemo) {
        const { hashPassword } = await import("@/lib/password");
        const newUser = await db.user.create({
          data: {
            email,
            name: email.split("@")[0] || "User",
            passwordHash: hashPassword(password),
          },
          select: { id: true, email: true, name: true, createdAt: true },
        });
        return NextResponse.json({ success: true, user: newUser });
      }
      return NextResponse.json(
        { error: "No account found with this email. Please sign up first." },
        { status: 404 },
      );
    }

    if (!verifyPassword(password, user.passwordHash)) {
      return NextResponse.json(
        { error: "Incorrect password. Please try again." },
        { status: 401 },
      );
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        createdAt: user.createdAt.getTime(),
      },
    });
  } catch (err) {
    console.error("[/api/auth/login] error:", err);
    const message = err instanceof Error ? err.message : "Failed to log in.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
