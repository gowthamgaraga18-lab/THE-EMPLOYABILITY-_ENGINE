// ============================================================================
// POST /api/report
// Module 4 — Interview Evaluation & Scorecard
// Accepts: { targetRole, missingSkills, transcript }
// Returns: InterviewReport
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { buildInterviewReport } from "@/lib/ai";
import type { InterviewMessage, MissingSkill } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));

    const targetRole = String(body?.targetRole ?? "").trim() || "Software Engineer";
    const missingSkills: MissingSkill[] = Array.isArray(body?.missingSkills)
      ? body.missingSkills
      : [];
    const transcript: InterviewMessage[] = Array.isArray(body?.transcript)
      ? body.transcript
      : [];

    if (transcript.length === 0) {
      return NextResponse.json(
        { error: "Interview transcript is empty." },
        { status: 400 },
      );
    }

    const report = await buildInterviewReport({
      targetRole,
      missingSkills,
      transcript,
    });

    return NextResponse.json({ success: true, report });
  } catch (err) {
    console.error("[/api/report] error:", err);
    const message =
      err instanceof Error ? err.message : "Failed to build report.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
