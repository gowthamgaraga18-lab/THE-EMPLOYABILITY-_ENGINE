// ============================================================================
// POST /api/analyze
// Module 1 — Resume & Job Description Parser
// Accepts: { resumeText, jdText }  (PDFs parsed client-side to text)
// Returns: AnalysisResult (match_score, missing_skills, experience_gaps, roadmap)
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { analyzeResumeAndJd } from "@/lib/ai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const resumeText = String(body?.resumeText ?? "").trim();
    const jdText = String(body?.jdText ?? "").trim();

    if (!resumeText) {
      return NextResponse.json(
        { error: "Resume text is required." },
        { status: 400 },
      );
    }
    if (!jdText) {
      return NextResponse.json(
        { error: "Job description is required." },
        { status: 400 },
      );
    }
    if (resumeText.length < 20) {
      return NextResponse.json(
        { error: "Resume text is too short to analyze meaningfully." },
        { status: 400 },
      );
    }
    if (jdText.length < 20) {
      return NextResponse.json(
        { error: "Job description is too short to analyze meaningfully." },
        { status: 400 },
      );
    }

    const result = await analyzeResumeAndJd(resumeText, jdText);

    return NextResponse.json({ success: true, result });
  } catch (err) {
    console.error("[/api/analyze] error:", err);
    const message =
      err instanceof Error ? err.message : "Failed to analyze resume.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
