// ============================================================================
// /api/trails/[id] — update a job trail (e.g. mark cracked/failed after report)
//   PATCH  /api/trails/[id]   → update status / verdict / interviewMode
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function getUserId(req: NextRequest): string | null {
  return req.headers.get("x-user-id");
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json().catch(() => ({}));

    // Only allow updating fields that make sense.
    const data: Record<string, unknown> = {};
    if (body.status) data.status = String(body.status);
    if (body.verdict !== undefined) data.verdict = body.verdict ? String(body.verdict) : null;
    if (body.interviewMode !== undefined) data.interviewMode = body.interviewMode ? String(body.interviewMode) : null;

    // Ensure the trail belongs to the user.
    const existing = await db.jobTrail.findFirst({ where: { id, userId } });
    if (!existing) {
      return NextResponse.json({ error: "Trail not found." }, { status: 404 });
    }

    const updated = await db.jobTrail.update({
      where: { id },
      data,
    });

    return NextResponse.json({
      success: true,
      trail: {
        id: updated.id,
        status: updated.status,
        verdict: updated.verdict,
        interviewMode: updated.interviewMode,
        updatedAt: updated.updatedAt.getTime(),
      },
    });
  } catch (err) {
    console.error("[/api/trails/[id] PATCH] error:", err);
    return NextResponse.json({ error: "Failed to update trail." }, { status: 500 });
  }
}
