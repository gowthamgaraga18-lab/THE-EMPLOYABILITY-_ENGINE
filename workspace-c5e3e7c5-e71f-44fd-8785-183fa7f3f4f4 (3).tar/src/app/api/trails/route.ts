// ============================================================================
// /api/trails — Job Trail history for the authenticated user.
//   GET    /api/trails          → list all trails for the user
//   POST   /api/trails          → create a new trail (after analysis)
// ============================================================================

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { JobTrail } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// The session user is sent in the body/headers for this MVP (no JWT). We trust
// the client-sent userId here since the app is a local demo. In production you
// would verify a session token instead.
function getUserId(req: NextRequest): string | null {
  const auth = req.headers.get("x-user-id");
  if (auth) return auth;
  return null;
}

// ---------------------------------------------------------------------------
// GET — list all job trails for the user
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    }

    const trails = await db.jobTrail.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });

    const result: JobTrail[] = trails.map((t) => ({
      id: t.id,
      userId: t.userId,
      analysisId: t.analysisId,
      targetRole: t.targetRole,
      matchScore: t.matchScore,
      status: t.status as JobTrail["status"],
      verdict: (t.verdict as JobTrail["verdict"]) ?? null,
      interviewMode: (t.interviewMode as JobTrail["interviewMode"]) ?? null,
      createdAt: t.createdAt.getTime(),
      updatedAt: t.updatedAt.getTime(),
    }));

    return NextResponse.json({ success: true, trails: result });
  } catch (err) {
    console.error("[/api/trails GET] error:", err);
    return NextResponse.json({ error: "Failed to load trails." }, { status: 500 });
  }
}

// ---------------------------------------------------------------------------
// POST — create a new job trail (called after analysis completes)
// ---------------------------------------------------------------------------
export async function POST(req: NextRequest) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const targetRole = String(body?.targetRole ?? "").trim();
    const matchScore = Math.max(0, Math.min(100, Number(body?.matchScore) || 0));
    const analysisId = body?.analysisId ? String(body.analysisId) : null;

    if (!targetRole) {
      return NextResponse.json({ error: "targetRole is required." }, { status: 400 });
    }

    const trail = await db.jobTrail.create({
      data: {
        userId,
        analysisId,
        targetRole,
        matchScore,
        status: "in_progress",
      },
    });

    return NextResponse.json({
      success: true,
      trail: {
        id: trail.id,
        userId: trail.userId,
        analysisId: trail.analysisId,
        targetRole: trail.targetRole,
        matchScore: trail.matchScore,
        status: trail.status as JobTrail["status"],
        verdict: null,
        interviewMode: null,
        createdAt: trail.createdAt.getTime(),
        updatedAt: trail.updatedAt.getTime(),
      },
    });
  } catch (err) {
    console.error("[/api/trails POST] error:", err);
    return NextResponse.json({ error: "Failed to save trail." }, { status: 500 });
  }
}
