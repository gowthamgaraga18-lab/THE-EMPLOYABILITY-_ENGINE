"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useAppStore } from "@/lib/store";
import { LandingView } from "@/components/landing/LandingView";
import { DashboardView } from "@/components/dashboard/DashboardView";
import { InterviewView } from "@/components/interview/InterviewView";
import { VideoInterviewView } from "@/components/interview/VideoInterviewView";
import { HistoryView } from "@/components/history/HistoryView";
import { ReportView } from "@/components/report/ReportView";
import { LoginView } from "@/components/auth/LoginView";
import { SignupView } from "@/components/auth/SignupView";
import { TopNav } from "@/components/shared/TopNav";
import { SiteFooter } from "@/components/shared/SiteFooter";

export default function Home() {
  const view = useAppStore((s) => s.view);

  // Auth views are full-screen (split-screen layout) — no TopNav / Footer.
  if (view === "login" || view === "signup") {
    return (
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {view === "login" && <LoginView />}
          {view === "signup" && <SignupView />}
        </motion.div>
      </AnimatePresence>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopNav />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.28 }}
          >
            {view === "landing" && <LandingView />}
            {view === "dashboard" && <DashboardView />}
            {view === "interview" && <InterviewView />}
            {view === "video-interview" && <VideoInterviewView />}
            {view === "history" && <HistoryView />}
            {view === "report" && <ReportView />}
          </motion.div>
        </AnimatePresence>
      </main>
      <SiteFooter />
    </div>
  );
}
